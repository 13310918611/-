#ifndef CHARGEMANAGE_H
#define CHARGEMANAGE_H

#include <QWidget>
#include <QComboBox>
#include <QLineEdit>
#include <QTextEdit>
#include <QPushButton>
#include <QTableWidget>
#include "ownerinfodatabase.h"

class ChargeManage : public QWidget
{
    Q_OBJECT

public:
    explicit ChargeManage(QWidget *parent = nullptr);
    ~ChargeManage() override;
    void refreshTable();

private slots:
    void onSendChargeClicked(); // 发送缴费通知

private:
    OwnerInfoDatabase* db; // 复用业主信息数据库连接（确保连接 smart_upc.db）
    QComboBox* ownerComboBox; // 业主选择下拉框（含“全部业主”）
    QLineEdit* amountEdit; // 金额输入框
    QTextEdit* reasonEdit; // 原因输入框
    QPushButton* sendBtn; // 发送按钮
    QTableWidget* recordTable; // 缴费记录表格

    void loadOwners(); // 加载业主列表到下拉框
};

#endif // CHARGEMANAGE_H
