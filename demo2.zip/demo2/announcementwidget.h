#ifndef ANNOUNCEMENTWIDGET_H
#define ANNOUNCEMENTWIDGET_H

#include <QWidget>
#include <QLineEdit>
#include <QTextEdit>
#include <QPushButton>

class AnnouncementWidget : public QWidget
{
    Q_OBJECT
public:

    explicit AnnouncementWidget(const QString& publisherName, QWidget *parent = nullptr);

private slots:
    void onPublishClicked();

private:
    QString m_publisherName;
    QLineEdit *m_titleEdit;
    QTextEdit *m_contentEdit;
    QPushButton *m_publishBtn;
};

#endif // ANNOUNCEMENTWIDGET_H
