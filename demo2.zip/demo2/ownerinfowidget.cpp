#include "ownerinfowidget.h"


OwnerInfoWidget::OwnerInfoWidget(int userId, const QString& ownerName, QWidget *parent)
    : QWidget(parent), m_userId(userId), m_ownerName(ownerName), m_infoComplete(false)
{
    // 创建表单布局
    QFormLayout *formLayout = new QFormLayout(this);
    formLayout->setLabelAlignment(Qt::AlignRight);

    // 姓名（只读，由主界面传入）
    QLineEdit *nameEdit = new QLineEdit(m_ownerName, this);
    nameEdit->setReadOnly(true);
    nameEdit->setStyleSheet("background-color: #f0f0f0;");

    // 电话号码
    m_phoneEdit = new QLineEdit(this);
    QRegularExpression phoneRegex("^1[3-9]\\d{9}$"); // 简单手机号验证
    QRegularExpressionValidator *phoneValidator = new QRegularExpressionValidator(phoneRegex, m_phoneEdit);
    m_phoneEdit->setValidator(phoneValidator);

    // 车牌号（使用与车位申请相同的验证规则）
    m_licenseEdit = new QLineEdit(this);
    QRegularExpression licenseRegex("^[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼]{1}[A-HJ-NP-Z]{1}[A-HJ-NP-Z0-9]{5,6}$");
    QRegularExpressionValidator *licenseValidator = new QRegularExpressionValidator(licenseRegex, m_licenseEdit);
    m_licenseEdit->setValidator(licenseValidator);

    // 家庭住址
    m_buildingEdit = new QLineEdit(this);
    QRegularExpression buildingRegex("^[1-9]\\d{0,2}$"); // 限制1-999幢
    QRegularExpressionValidator *buildingValidator = new QRegularExpressionValidator(buildingRegex, m_buildingEdit);
    m_buildingEdit->setValidator(buildingValidator);
    m_roomEdit = new QLineEdit(this);
    QRegularExpression roomRegex("^[1-9]\\d{1,4}$"); // 限制10-99999号
    QRegularExpressionValidator *roomValidator = new QRegularExpressionValidator(roomRegex, m_roomEdit);
    m_roomEdit->setValidator(roomValidator);

    // 家庭成员
    m_familyEdit = new QTextEdit(this);
    m_familyEdit->setPlaceholderText("请输入家庭成员信息，每行一位");
    m_familyEdit->setMaximumHeight(100);

    // 保存按钮
    m_saveBtn = new QPushButton("保存信息", this);
    connect(m_saveBtn, &QPushButton::clicked, this, &OwnerInfoWidget::saveInfo);

    // 添加到表单布局
    formLayout->addRow("业主姓名:", nameEdit);
    formLayout->addRow("联系电话:", m_phoneEdit);
    formLayout->addRow("车牌号:", m_licenseEdit);
    formLayout->addRow("所在幢号:", m_buildingEdit);
    formLayout->addRow("房间号:", m_roomEdit);
    formLayout->addRow("家庭成员:", m_familyEdit);
    formLayout->addRow(m_saveBtn);

    // 从数据库加载已有信息（如果存在）
    loadOwnerInfo();
}

// 加载业主信息
void OwnerInfoWidget::loadOwnerInfo()
{
    OwnerInfoDatabase *db = OwnerInfoDatabase::instance();
    QString phone, license, building, room, family;

    if (db->getOwnerInfo(m_userId, phone, license, building, room, family)) {
        m_phoneEdit->setText(phone);
        m_licenseEdit->setText(license);
        m_buildingEdit->setText(building);
        m_roomEdit->setText(room);
        m_familyEdit->setText(family);
        m_infoComplete = db->isOwnerInfoComplete(m_userId);
    }
}

// 保存业主信息
void OwnerInfoWidget::saveInfo()
{
    // 验证必填字段
    if (m_phoneEdit->text().isEmpty()) {
        QMessageBox::warning(this, "信息不完整", "请输入联系电话");
        return;
    }

    if (m_licenseEdit->text().isEmpty()) {
        QMessageBox::warning(this, "信息不完整", "请输入车牌号");
        return;
    }

    if (!m_licenseEdit->hasAcceptableInput()) {
        QMessageBox::warning(this, "格式错误", "请输入正确的车牌格式（如：京A12345）");
        return;
    }

    if (m_buildingEdit->text().isEmpty()) {
        QMessageBox::warning(this, "信息不完整", "请输入所在幢号");
        return;
    }

    if (m_roomEdit->text().isEmpty()) {
        QMessageBox::warning(this, "信息不完整", "请输入房间号");
        return;
    }

    OwnerInfoDatabase *db = OwnerInfoDatabase::instance();
    QString phone = m_phoneEdit->text();
        QString license = m_licenseEdit->text();
        QString building = m_buildingEdit->text();
        QString room = m_roomEdit->text();
        QString family = m_familyEdit->toPlainText();

        if (db->saveOwnerInfo(m_userId, phone, license, building, room, family)) {
            m_infoComplete = true;
            QMessageBox::information(this, "成功", "个人信息已保存");
            emit infoUpdated();
        } else {
            QMessageBox::critical(this, "失败", "保存信息时出错: " + db->lastError());
        }
    }

// 获取个人信息的公共接口
QString OwnerInfoWidget::phoneNumber() const { return m_phoneEdit->text(); }
QString OwnerInfoWidget::licensePlate() const { return m_licenseEdit->text(); }
QString OwnerInfoWidget::building() const { return m_buildingEdit->text(); }
QString OwnerInfoWidget::room() const {return m_roomEdit->text();}
QString OwnerInfoWidget::familyMembers() const { return m_familyEdit->toPlainText(); }

bool OwnerInfoWidget::isInfoComplete() const { return m_infoComplete; }
