#include "databaseaccess.h"
#include "login.h"
#include "adminwindow.h"
#include "staffwindow.h"
#include "ownerwindow.h"
#include "attendancewidget.h"
#include "database_initializer.h"
#include <QApplication>
#include <QMessageBox>
#include <QDebug>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    // 初始化数据库
    DatabaseAccess *dbAccess = DatabaseAccess::instance();
    DatabaseAccess::ConnectionStatus status = dbAccess->initialize();

    // 输出数据库路径和状态
    qDebug() << "Database Path:" << dbAccess->currentDbPath();
    qDebug() << "Connection Status:" << static_cast<int>(status);

    a.setApplicationName("物业人员管理系统");
    a.setApplicationVersion("1.0");

    // 处理数据库初始化结果
    QString dbPath = dbAccess->currentDbPath();

    switch (status) {
    case DatabaseAccess::ConnectionStatus::Connected:
        break;
    case DatabaseAccess::ConnectionStatus::FileNotFound:
        QMessageBox::warning(nullptr, "数据库文件不存在",
            QString("已在以下位置创建新数据库:\n%1\n\n系统将使用默认配置初始化数据库。")
            .arg(dbPath));
        break;
    case DatabaseAccess::ConnectionStatus::DriverNotFound:
        QMessageBox::critical(nullptr, "致命错误",
            "无法加载SQLite数据库驱动。\n请确保Qt SQLite驱动已正确安装。");
        return 1;
    case DatabaseAccess::ConnectionStatus::FileNotWritable:
        QMessageBox::critical(nullptr, "权限错误",
            QString("无法访问数据库文件:\n%1\n\n请确保应用程序有读写权限。")
            .arg(dbPath));
        return 1;
    case DatabaseAccess::ConnectionStatus::Error:
        QMessageBox::critical(nullptr, "数据库错误",
            QString("连接数据库失败:\n%1\n\n错误信息:\n%2")
            .arg(dbPath)
            .arg(dbAccess->lastError()));
        return 1;
    default:
        QMessageBox::critical(nullptr, "未知错误", "初始化数据库时发生未知错误");
        return 1;
    }

    if (!DatabaseInitializer::initialize(dbPath)) {
        QMessageBox::critical(nullptr, "数据库初始化失败", "无法创建所需的数据库表格，请检查数据库文件和权限。");
        return 1;
    }

    // 全局存储管理员窗口指针
    AdminWindow* adminWindow = nullptr;

    // 显示登录界面
    while (true) {
        Login login;

        if (login.exec() != QDialog::Accepted) {
            return 0;
        }

        // 登录成功，获取用户信息
        int role = login.getUserRole();
        int userId = login.getUserId();
        int selectedRole = login.getSelectedRole();

        // 验证角色
        if (role != selectedRole) {
            QString roleNames[] = {"管理员", "工作人员", "业主"};
            QMessageBox::warning(nullptr, "角色不匹配",
                QString("您选择的是%1身份，但账号实际是%2身份！")
                .arg(roleNames[selectedRole])
                .arg(roleNames[role]));
            continue;
        }

        // 创建主窗口
        QWidget *mainWindow = nullptr;

        switch (role) {
        case 0: // 管理员
            adminWindow = new AdminWindow(userId, login.getUsername());
            mainWindow = adminWindow;
            mainWindow->setWindowTitle(QString("管理员系统 - 欢迎你：%1").arg(login.getUsername()));
            break;

        case 1: // 工作人员
            mainWindow = new StaffWindow(userId, login.getUsername());
            mainWindow->setWindowTitle(QString("工作人员系统 - 欢迎你：%1").arg(login.getUsername()));

            // 连接员工打卡信号到管理员界面刷新
            if (adminWindow) {
                StaffWindow* staffWindow = qobject_cast<StaffWindow*>(mainWindow);
                if (staffWindow) {
                    AttendanceWidget* attendanceWidget = adminWindow->getAttendanceWidget();
                    if (attendanceWidget) {
                        QObject::connect(staffWindow, &StaffWindow::attendanceDataUpdated,
                                        attendanceWidget, &AttendanceWidget::forceRefresh);
                    }
                }
            }
            break;

        case 2: // 业主
            mainWindow = new OwnerWindow(userId, login.getUsername());
            mainWindow->setWindowTitle(QString("业主中心 - 欢迎你：%1").arg(login.getUsername()));
            break;

        default:
            QMessageBox::warning(nullptr, "错误", "未知角色，无法进入系统！");
            continue;
        }

        if (mainWindow) {
            mainWindow->resize(800, 600);
            mainWindow->show();

            // 进入主窗口事件循环
            int result = a.exec();

            // 释放资源
            if (role == 0) { // 如果是管理员窗口关闭
                adminWindow = nullptr;
            }
            delete mainWindow;

            // 检查是否需要重新登录
            if (result != 100) { // 100表示需要重新登录
                return result;
            }
        }
    }
}
