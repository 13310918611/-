#include "attendancewidget.h"
#include "ui_attendancewidget.h"
#include "database.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QMessageBox>
#include <QDebug>
#include <QSqlError>
#include <QDate>
#include <QTimer>
#include <QSettings>
#include <QLabel>

AttendanceWidget::AttendanceWidget(QWidget* parent)
    : QWidget(parent),
      ui(new Ui::AttendanceWidget),
      table(nullptr),
      searchEdit(nullptr),
      statusCombo(nullptr),
      btnSearch(nullptr)
{
    ui->setupUi(this);
    setupUI();
    setupConnections();

    // 确保配置表存在
    ensureConfigTableExists();

    if (!database::instance().isOpen()) {
        if (!database::instance().openDB("smart_upc.db")) {
            QMessageBox::critical(this, "错误", "数据库打开失败: " + database::instance().lastError());
            return;
        }
    }

    // 初始化日期检查（每次启动时检查是否需要重置）
    checkAndResetAttendance();

    // 设置每日定时器（每天凌晨1点执行重置检查）
    setupDailyResetTimer();

    refreshTable(); // 调用带默认参数的refreshTable
}

AttendanceWidget::~AttendanceWidget()
{
    delete ui;
}

// 确保配置表存在
void AttendanceWidget::ensureConfigTableExists()
{
    QSqlQuery query(database::instance().getDatabase());
    query.exec(
        "CREATE TABLE IF NOT EXISTS config ("
        "key TEXT PRIMARY KEY,"
        "value TEXT"
        ")"
    );
}

// 改进的定时器设置
void AttendanceWidget::setupDailyResetTimer()
{
    QTimer* timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &AttendanceWidget::checkAndResetAttendance);

    // 设置每天凌晨1点触发
    timer->start(24 * 60 * 60 * 1000); // 24小时

    // 立即检查是否需要重置（处理系统休眠后时间跳跃）
    QTimer::singleShot(1000, this, &AttendanceWidget::checkAndResetAttendance);
}

// 改进的重置逻辑
void AttendanceWidget::checkAndResetAttendance()
{
    QDate currentDate = QDate::currentDate();
    QDate lastDailyReset = getLastDailyResetDate();
    QDate lastMonthlyReset = getLastMonthlyResetDate();

    // 1. 每日重置（如果上次重置日期不是今天）
    if (lastDailyReset != currentDate) {
        if (performDailyReset()) {
            qDebug() << "完成每日出勤状态重置";
            setLastDailyResetDate(currentDate);
        }
    }

    // 2. 每月重置（如果当前月份与上次重置月份不同）
    if (lastMonthlyReset.month() != currentDate.month() ||
        lastMonthlyReset.year() != currentDate.year()) {
        if (performMonthlyReset()) {
            qDebug() << "完成月度出勤次数重置";
            setLastMonthlyResetDate(currentDate);
        }
    }

    // 刷新表格显示最新状态
    refreshTable();
}

// 执行每日重置操作
bool AttendanceWidget::performDailyReset()
{
    QSqlDatabase db = database::instance().getDatabase();
    db.transaction();

    QSqlQuery query(db);
    bool success = query.exec(
        "UPDATE attendance SET today = 1 "
        "WHERE id IN (SELECT id FROM staff WHERE status = 1 AND role = 1)"
    );

    if (success) {
        db.commit();
        return true;
    } else {
        qDebug() << "每日重置失败:" << query.lastError().text();
        db.rollback();
        return false;
    }
}

// 执行每月重置操作
bool AttendanceWidget::performMonthlyReset()
{
    QSqlDatabase db = database::instance().getDatabase();
    db.transaction();

    QSqlQuery query(db);
    bool success = query.exec(
        "UPDATE attendance SET monthly = 0 "
        "WHERE id IN (SELECT id FROM staff WHERE status = 1 AND role = 1)"
    );

    if (success) {
        db.commit();
        return true;
    } else {
        qDebug() << "月度重置失败:" << query.lastError().text();
        db.rollback();
        return false;
    }
}

// 获取上次每日重置日期（使用QSettings作为备选）
QDate AttendanceWidget::getLastDailyResetDate()
{
    QSqlQuery query(database::instance().getDatabase());
    if (query.exec("SELECT value FROM config WHERE key = 'last_daily_reset'")) {
        if (query.next()) {
            return QDate::fromString(query.value(0).toString(), Qt::ISODate);
        }
    }

    // 如果数据库中没有记录，使用QSettings
    QSettings settings;
    return settings.value("last_daily_reset", QDate::currentDate().addDays(-1)).toDate();
}

// 设置上次每日重置日期
void AttendanceWidget::setLastDailyResetDate(const QDate& date)
{
    // 保存到数据库
    QSqlQuery query(database::instance().getDatabase());
    query.prepare(
        "INSERT OR REPLACE INTO config (key, value) "
        "VALUES ('last_daily_reset', :date)"
    );
    query.bindValue(":date", date.toString(Qt::ISODate));
    query.exec();

    // 同时保存到QSettings
    QSettings settings;
    settings.setValue("last_daily_reset", date);
}

// 获取上次月度重置日期
QDate AttendanceWidget::getLastMonthlyResetDate()
{
    QSqlQuery query(database::instance().getDatabase());
    if (query.exec("SELECT value FROM config WHERE key = 'last_monthly_reset'")) {
        if (query.next()) {
            return QDate::fromString(query.value(0).toString(), Qt::ISODate);
        }
    }

    // 如果数据库中没有记录，使用QSettings
    QSettings settings;
    return settings.value("last_monthly_reset", QDate::currentDate().addMonths(-1)).toDate();
}

// 设置上次月度重置日期
void AttendanceWidget::setLastMonthlyResetDate(const QDate& date)
{
    // 保存到数据库
    QSqlQuery query(database::instance().getDatabase());
    query.prepare(
        "INSERT OR REPLACE INTO config (key, value) "
        "VALUES ('last_monthly_reset', :date)"
    );
    query.bindValue(":date", date.toString(Qt::ISODate));
    query.exec();

    // 同时保存到QSettings
    QSettings settings;
    settings.setValue("last_monthly_reset", date);
}

void AttendanceWidget::setupUI()
{
    table = new QTableWidget(this);
    table->setColumnCount(4);
    table->setHorizontalHeaderLabels({"姓名", "电话", "当日出勤", "月度出勤天数"});
    table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    table->setEditTriggers(QAbstractItemView::NoEditTriggers);

    searchEdit = new QLineEdit(this);
    searchEdit->setPlaceholderText("输入姓名查询");

    statusCombo = new QComboBox(this);
    statusCombo->addItem("全部状态", -1);
    statusCombo->addItem("出勤", 0);
    statusCombo->addItem("缺勤", 1);
    statusCombo->addItem("请假", 2);

    btnSearch = new QPushButton("查询", this);

    QHBoxLayout* searchLayout = new QHBoxLayout;
    searchLayout->addWidget(searchEdit);
    searchLayout->addWidget(statusCombo);
    searchLayout->addWidget(btnSearch);

    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    mainLayout->addLayout(searchLayout);
    mainLayout->addWidget(table);
    setLayout(mainLayout);
}

void AttendanceWidget::setupConnections()
{
    connect(btnSearch, &QPushButton::clicked, this, &AttendanceWidget::onSearch);
    connect(searchEdit, &QLineEdit::returnPressed, this, &AttendanceWidget::onSearch);
}

// 统一的刷新表格函数，支持指定日期
void AttendanceWidget::refreshTable()
{
    // 内部默认使用当前日期，不对外暴露参数
    refreshTableWithDate(QDate::currentDate());
}

void AttendanceWidget::refreshTableWithDate(const QDate& date)
{
    table->setRowCount(0);

    // 检查数据库连接
    if (!database::instance().isOpen()) {
        QMessageBox::critical(this, "数据库错误", "无法连接到数据库，请检查配置");
        return;
    }

    QSqlQuery query(database::instance().getDatabase());
    QString sql = "SELECT a.id, s.name, s.phone, a.today, a.monthly "
                  "FROM attendance a "
                  "JOIN staff s ON a.id = s.id "
                  "WHERE s.status = 1 AND s.role = 1";

    // 执行查询
    if (!query.exec(sql)) {
        QMessageBox::critical(this, "查询失败",
            QString("SQL执行错误:\n%1\n\nSQL语句:\n%2")
            .arg(query.lastError().text())
            .arg(sql));
        return;
    }

    // 检查是否有结果
    if (!query.first()) {
        QLabel* emptyLabel = new QLabel("暂无考勤数据", table);
        emptyLabel->setAlignment(Qt::AlignCenter);
        table->setCellWidget(0, 0, emptyLabel);
        table->setSpan(0, 0, 1, table->columnCount());
        return;
    }

    // 重置查询指针到开头
    query.previous();

    // 填充表格（无需日期参数）
    populateTable(query);
}

// 无日期参数的表格填充函数
void AttendanceWidget::populateTable(QSqlQuery& query)
{
    int row = 0;
    while (query.next()) {
        int staffId = query.value("id").toInt();
        QString name = query.value("name").toString();
        QString phone = query.value("phone").toString();
        int todayStatus = query.value("today").toInt();
        int monthlyCount = query.value("monthly").toInt();

        table->insertRow(row);
        table->setItem(row, 0, new QTableWidgetItem(name));
        table->setItem(row, 1, new QTableWidgetItem(phone));

        // 状态文本转换
        QString statusText;
        switch(todayStatus) {
            case 0: statusText = "出勤"; break;
            case 1: statusText = "缺勤或请假，请尽快联系"; break;
            default: statusText = "未知"; break;
        }
        table->setItem(row, 2, new QTableWidgetItem(statusText));
        table->setItem(row, 3, new QTableWidgetItem(QString::number(monthlyCount)));

        row++;
    }
}

bool AttendanceWidget::executePreparedQuery(const QString& sql, const QMap<QString, QVariant>& bindValues, QSqlQuery& query)
{
    query = QSqlQuery(database::instance().getDatabase());

    if (!query.prepare(sql)) {
        QMessageBox::critical(this, "错误", "查询准备失败: " + query.lastError().text());
        return false;
    }

    for (auto it = bindValues.begin(); it != bindValues.end(); ++it) {
        query.bindValue(it.key(), it.value());
    }

    if (!query.exec()) {
        QMessageBox::critical(this, "错误", "查询执行失败: " + query.lastError().text());
        return false;
    }

    return true;
}

void AttendanceWidget::onSearch()
{
    QString keyword = searchEdit->text().trimmed();
    int status = statusCombo->currentData().toInt();

    QString sql = "SELECT a.id, s.name, s.phone, a.today, a.monthly "
                  "FROM attendance a "
                  "JOIN staff s ON a.id = s.id "
                  "WHERE s.status = 1 AND s.role = 1 ";

    QMap<QString, QVariant> bindValues;

    if (!keyword.isEmpty()) {
        sql += "AND s.name LIKE :name ";
        bindValues[":name"] = "%" + keyword + "%";
    }

    if (status != -1) {
        sql += "AND a.today = :status ";
        bindValues[":status"] = status;
    }

    QSqlQuery query;
    if (!executePreparedQuery(sql, bindValues, query)) {
        return;
    }

    table->setRowCount(0);
    // 搜索时使用当前日期作为参数
    populateTable(query);
}

void AttendanceWidget::onReset()
{
    searchEdit->clear();
    statusCombo->setCurrentIndex(0);
    refreshTable();
}

// 强制刷新，用于接收员工打卡信号后更新
void AttendanceWidget::forceRefresh()
{
    refreshTable();
}
