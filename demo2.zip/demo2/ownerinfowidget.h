#ifndef OWNERINFOWIDGET_H
#define OWNERINFOWIDGET_H

#include <QWidget>
#include <QLineEdit>
#include <QTextEdit>
#include <QPushButton>
#include <QFormLayout>
#include <QRegularExpressionValidator>
#include <QMessageBox>
#include "ownerinfodatabase.h"

class OwnerInfoWidget : public QWidget
{
    Q_OBJECT
public:
    explicit OwnerInfoWidget(int userId, const QString& ownerName, QWidget *parent = nullptr);
    ~OwnerInfoWidget() override = default;

    // 获取个人信息的公共接口
    QString phoneNumber() const;
    QString licensePlate() const;
    QString building() const;
    QString room() const;
    QString familyMembers() const;

    // 检查信息是否已完善
    bool isInfoComplete() const;

signals:
    void infoUpdated(); // 信息更新信号

private slots:
    void saveInfo();
    //void validateLicensePlate();
    void loadOwnerInfo();
private:
    int m_userId;
    QString m_ownerName;

    QLineEdit *m_phoneEdit;
    QLineEdit *m_licenseEdit;
    QLineEdit *m_buildingEdit;
    QLineEdit *m_roomEdit;
    QTextEdit *m_familyEdit;
    QPushButton *m_saveBtn;

    bool m_infoComplete;
};

#endif // OWNERINFOWIDGET_H
