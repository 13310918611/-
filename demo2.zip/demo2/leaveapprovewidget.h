#pragma once
#include <QWidget>
#include <QTableWidget>
#include <QPushButton>
#include <QSqlQuery>
#include <QComboBox>
#include "database.h"
#include "dbmanager.h"

class LeaveApproveWidget : public QWidget {
    Q_OBJECT
public:
    explicit LeaveApproveWidget(const QString& adminName, QWidget* parent = nullptr);
    ~LeaveApproveWidget();

    void refreshTable();
//private:
    //int getApproverId() const { return 0; }

private slots:
    void onApprove();
    void onReject();
    void onSearch();
    void onReset();

private:
    DBManager& dbManager;
    QTableWidget* table;
    QPushButton* btnApprove;
    QPushButton* btnReject;
    QLineEdit* searchInput;
    QComboBox* statusCombo;
    QPushButton* btnSearch;
    QPushButton* btnReset;

    bool updateLeaveStatus(int leaveId, int status);
    void setupUI();
    void setupConnections();
    QString m_adminName;
};
