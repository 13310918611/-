#pragma once
#include <QStackedWidget>
#include <QMainWindow>
#include <QStatusBar>
#include "dailycheckin.h"
#include "fixmanage.h"
#include "announcementlistwidget.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class StaffWindow;
}
QT_END_NAMESPACE

class DailyCheckIn;  //出勤打卡
class LeaveApplyWidget;  //请销假
class ParkLotManage;  //车位管理
class OwnerManage;  //业主管理
class ChargeManage;  //缴费管理
class FixManage; //报修管理
class AnnouncementListWidget; //公告查看

class StaffWindow : public QMainWindow
{
    Q_OBJECT

public:
    StaffWindow(int userId, const QString& staffName, QWidget *parent = nullptr);
    ~StaffWindow();

signals:
    void attendanceDataUpdated();

private slots:
    void showDailyCheckIn();
    void showLeaveApply();
    void showParkLotManage();
    void showOwnerManage();
    void showChargeManage();
    void showFixManage();
    void showAnnouncements();

private:
    void setupMenus();
    int m_userID;
    database& db = database::instance();
    Ui::StaffWindow* ui;
    QStackedWidget* stackedWidget;
    DailyCheckIn* dailycheckin;
    LeaveApplyWidget* leaveapplywidget;
    ParkLotManage* parklotmanage;
    OwnerManage* ownermanage;
    ChargeManage* chargemanage;
    FixManage* fixmanage;
    AnnouncementListWidget* announcementWidget;
    QString m_staffName;
};
