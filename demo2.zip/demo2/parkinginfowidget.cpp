#include "parkinginfowidget.h"
#include "parkdatabasehelper.h"
#include "ownerinfodatabase.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QMessageBox>
#include <QDebug>
#include <QLabel>
#include <QComboBox>
#include <QLineEdit>
#include <QPushButton>
#include <QDialog>
#include <QFormLayout>
#include <QDialogButtonBox>

// 构造函数：接收用户ID并初始化
ParkingInfoWidget::ParkingInfoWidget(int userId, QWidget *parent)
    : QWidget(parent), parkingTable(nullptr), refreshBtn(nullptr),
      searchEdit(nullptr), modeCombo(nullptr), m_userId(userId),
      m_shownApplicationIds()
{
    setupUI();
    checkApplicationStatusChanges(); // 检查申请状态变更
    refreshTable();
}

ParkingInfoWidget::~ParkingInfoWidget()
{

}

// 初始化UI
void ParkingInfoWidget::setupUI()
{
    // 标题
    QLabel *titleLabel = new QLabel("车位信息查询", this);
    QFont font = titleLabel->font();
    font.setPointSize(12);
    font.setBold(true);
    titleLabel->setFont(font);
    titleLabel->setAlignment(Qt::AlignCenter);

    // 模式选择
    modeCombo = new QComboBox(this);
    modeCombo->addItem("公示中车位（可申请）", 1);
    modeCombo->addItem("已承租车位", 2);
    connect(modeCombo, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, &ParkingInfoWidget::onModeChanged);

    // 搜索区域
    searchEdit = new QLineEdit(this);
    searchEdit->setPlaceholderText("请输入搜索内容");

    QPushButton *searchBtn = new QPushButton("搜索", this);
    connect(searchBtn, &QPushButton::clicked, this, &ParkingInfoWidget::onSearch);

    refreshBtn = new QPushButton("刷新", this);
    connect(refreshBtn, &QPushButton::clicked, this, &ParkingInfoWidget::refreshTable);

    QHBoxLayout *searchLayout = new QHBoxLayout();
    searchLayout->addWidget(modeCombo);
    searchLayout->addWidget(searchEdit);
    searchLayout->addWidget(searchBtn);
    searchLayout->addWidget(refreshBtn);

    // 车位表格：固定4列
    parkingTable = new QTableWidget(this);
    parkingTable->setColumnCount(4); // 固定4列：编号、状态、车牌、操作
    parkingTable->setHorizontalHeaderLabels({"车位编号", "状态", "车牌号", "操作"});
    parkingTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    parkingTable->horizontalHeader()->setSectionResizeMode(3, QHeaderView::Fixed); // 操作列固定宽度
    parkingTable->setColumnWidth(3, 100); // 操作列宽度足够显示按钮
    parkingTable->setEditTriggers(QAbstractItemView::NoEditTriggers);

    // 主布局
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->addWidget(titleLabel);
    mainLayout->addLayout(searchLayout);
    mainLayout->addWidget(parkingTable);
    setLayout(mainLayout);
}

// 刷新表格：添加公示中车位的申请按钮
void ParkingInfoWidget::refreshTable()
{
    parkingTable->setColumnCount(4);
    parkingTable->setHorizontalHeaderLabels({"车位编号", "状态", "车牌号", "操作"});
    parkingTable->setRowCount(0); // 清空表格内容

    ParkDatabaseHelper *dbHelper = ParkDatabaseHelper::instance();
    if (!dbHelper->openDB("smart_upc.db")) {
        qDebug() << "数据库打开失败，无法刷新表格";
        return;
    }

    // 获取当前用户的车牌号
    QString userLicense = getOwnerLicensePlate();
    qDebug() << "当前用户车牌:" << userLicense;

    int mode = modeCombo->currentData().toInt();
    QString keyword = searchEdit->text().trimmed();

    // 构建查询SQL（已承租模式仅显示当前用户的车位）
    QString sql = "SELECT parklot_id, license_number, status FROM parklot WHERE 1=1";
    if (mode == 1) sql += " AND status = 1"; // 公示中
    if (mode == 2) sql += " AND status = 2 AND license_number = :license"; // 已承租且属于当前用户

    if (!keyword.isEmpty()) {
        if (mode == 1) {
            sql += " AND parklot_id LIKE :keyword"; // 公示中模式搜索车位编号
        } else {
            sql += " AND license_number LIKE :keyword"; // 已承租模式搜索车牌号
        }
    }

    // 执行查询
    QSqlQuery query;
    QString errorMsg;
    QMap<QString, QVariant> bindValues;
    if (mode == 2) bindValues[":license"] = userLicense;
    if (!keyword.isEmpty()) bindValues[":keyword"] = "%" + keyword + "%";

    if (!dbHelper->executePreparedQuery(sql, bindValues, query, errorMsg)) {
        qDebug() << "查询失败:" << errorMsg;
        return;
    }

    // 填充表格
    while (query.next()) {
        int row = parkingTable->rowCount();
        parkingTable->insertRow(row);

        QString parklotId = query.value("parklot_id").toString();
        QString license = query.value("license_number").toString();
        int status = query.value("status").toInt();

        QString statusText = status == 0 ? "未公示" :
                            status == 1 ? "公示中" :
                            "已承租";

        // 设置表格内容（前3列）
        parkingTable->setItem(row, 0, new QTableWidgetItem(parklotId));
        parkingTable->setItem(row, 1, new QTableWidgetItem(statusText));
        parkingTable->setItem(row, 2, new QTableWidgetItem(license));

        // 调试输出：确认状态
        qDebug() << "处理车位:" << parklotId
                 << "状态码:" << status
                 << "状态文本:" << statusText
                 << "是否为公示中:" << (status == 1)
                 << "是否为已承租:" << (status == 2 && license == userLicense);

        // 清空操作列已有控件
        QWidget *oldWidget = parkingTable->cellWidget(row, 3);
        if (oldWidget) delete oldWidget;

        // 1. 公示中车位：添加申请按钮（status == 1）
        if (status == 1) {
            QPushButton *applyBtn = new QPushButton("申请", parkingTable);
            applyBtn->setProperty("parklotId", parklotId);
            applyBtn->setMinimumHeight(30); // 确保按钮高度

            // 设置按钮样式（与取消按钮区分）
            applyBtn->setStyleSheet(
                "QPushButton {"
                "    background-color: #48dbfb;"
                "    color: #2d3436;"
                "    border: none;"
                "    border-radius: 4px;"
                "    padding: 5px 10px;"
                "}"
                "QPushButton:hover {"
                "    background-color: #0abde3;"
                "}"
            );

            // 绑定申请事件
            connect(applyBtn, &QPushButton::clicked, [this, parklotId]() {
                    qDebug() << "申请按钮点击，车位ID:" << parklotId;
                    onApplyParking(parklotId); // 直接传递车位ID
                });

                parkingTable->setCellWidget(row, 3, applyBtn);
                qDebug() << "申请按钮添加成功，车位ID:" << parklotId;
        }
        // 2. 已承租车位取消按钮
        else if (status == 2 && license == userLicense) {
            QPushButton *cancelBtn = new QPushButton("取消承租", parkingTable);
            cancelBtn->setProperty("parklotId", parklotId);
            cancelBtn->setMinimumHeight(30);

            cancelBtn->setStyleSheet(
                "QPushButton {"
                "    background-color: #ff6b6b;"
                "    color: white;"
                "    border: none;"
                "    border-radius: 4px;"
                "    padding: 5px 10px;"
                "}"
                "QPushButton:hover {"
                "    background-color: #ff4757;"
                "}"
            );

            connect(cancelBtn, &QPushButton::clicked, [this, parklotId]() {
                qDebug() << "点击取消按钮，车位ID:" << parklotId;
                onCancelLease(parklotId);
            });

            parkingTable->setCellWidget(row, 3, cancelBtn);
            qDebug() << "已添加取消按钮到已承租车位:" << parklotId;
        }
        // 其他状态：操作列留空
        else {
            parkingTable->setCellWidget(row, 3, new QWidget());
        }
    }

    // 空表格提示
    if (parkingTable->rowCount() == 0) {
        showEmptyTableMessage(mode);
    } else {
        qDebug() << "表格刷新完成，共" << parkingTable->rowCount() << "行数据";
    }
}

// 显示空表格提示信息
void ParkingInfoWidget::showEmptyTableMessage(int mode)
{
    parkingTable->setRowCount(1); // 新增一行显示提示

    QString message = mode == 1 ?
        "当前没有公示中的车位" :
        "您没有承租任何车位";

    QTableWidgetItem *item = new QTableWidgetItem(message);
    item->setTextAlignment(Qt::AlignCenter);
    item->setFlags(item->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
    parkingTable->setItem(0, 0, item);

    // 合并4列显示提示信息
    parkingTable->setSpan(0, 0, 1, 4);
}

// 搜索按钮槽函数
void ParkingInfoWidget::onSearch()
{
    refreshTable();
}

// 模式切换槽函数
void ParkingInfoWidget::onModeChanged(int index)
{
    Q_UNUSED(index);
    searchEdit->clear();
    refreshTable();
}

// 从数据库查询个人信息中的车牌号
QString ParkingInfoWidget::getOwnerLicensePlate()
{
    OwnerInfoDatabase *db = OwnerInfoDatabase::instance();
    QString phone, license, building, room, family;

    if (db->getOwnerInfo(m_userId, phone, license, building, room, family)) {
        return license;
    }
    return "";
}

// 申请车位槽函数
void ParkingInfoWidget::onApplyParking(const QString &parklotId)
{
    // 直接使用传递的车位ID，无需依赖sender()
    if (parklotId.isEmpty()) {
        QMessageBox::warning(this, "参数错误", "未获取到车位信息");
        return;
    }

    // 1. 获取用户车牌号
    QString license = getOwnerLicensePlate();
    if (license.isEmpty()) {
        QMessageBox::warning(this, "信息缺失", "请先完善个人信息中的车牌号！");
        return;
    }

    // 2. 验证车牌号格式
    QRegularExpression regex("^[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼]{1}[A-HJ-NP-Z]{1}[A-HJ-NP-Z0-9]{5,6}$");
    if (!regex.match(license).hasMatch()) {
        QMessageBox::warning(this, "格式错误",
            QString("车牌号 %1 格式不正确，请先在个人信息中修改").arg(license));
        return;
    }

    // 3. 检查是否重复申请（状态为0：待审核）
    ParkDatabaseHelper *dbHelper = ParkDatabaseHelper::instance();
    QString checkSql = "SELECT application_id FROM parking_application "
                      "WHERE parklot_id = :parklot_id "
                      "AND license_plate = :license "
                      "AND status = 0"; // 0=待审核

    QMap<QString, QVariant> checkBind;
    checkBind[":parklot_id"] = parklotId;
    checkBind[":license"] = license;

    QSqlQuery checkQuery;
    QString errorMsg;
    if (!dbHelper->executePreparedQuery(checkSql, checkBind, checkQuery, errorMsg)) {
        QMessageBox::critical(this, "校验失败", "检查重复申请时出错: " + errorMsg);
        return;
    }

    if (checkQuery.next()) {
        QMessageBox::warning(this, "重复申请",
            QString("您的车牌号 %1 已申请过车位 %2，申请正在审核中").arg(license, parklotId));
        return;
    }

    // 4. 提交申请到数据库
    QString sql = "INSERT INTO parking_application (parklot_id, license_plate, apply_time, status) "
                "VALUES (:parklot_id, :license, CURRENT_TIMESTAMP, 0)"; // 0=待审核

    QMap<QString, QVariant> bindValues;
    bindValues[":parklot_id"] = parklotId;
    bindValues[":license"] = license;

    QSqlQuery query;
    QString errorMsg2;
    if (dbHelper->executePreparedQuery(sql, bindValues, query, errorMsg2)) {
        // 记录新申请ID，避免重复提示
        query.exec("SELECT last_insert_rowid()");
        if (query.next()) {
            int newAppId = query.value(0).toInt();
            m_shownApplicationIds.insert(newAppId);
        }

        QMessageBox::information(this, "申请成功",
            QString("已成功申请车位 %1，等待审核").arg(parklotId));
        refreshTable(); // 刷新表格，更新状态
    } else {
        QMessageBox::critical(this, "提交失败", "申请提交失败: " + errorMsg2);
    }
}

// 检查申请状态变更并提示用户
void ParkingInfoWidget::checkApplicationStatusChanges()
{
    QString userLicense = getOwnerLicensePlate();
    if (userLicense.isEmpty()) return;

    ParkDatabaseHelper *dbHelper = ParkDatabaseHelper::instance();
    if (!dbHelper->openDB("smart_upc.db")) return;

    QString messages;

    // 1. 检查待审核申请的车位状态是否变更
    QSqlQuery query;
    QString sql = "SELECT pa.application_id AS app_id, pa.parklot_id, p.status AS park_status "
                 "FROM parking_application pa "
                 "JOIN parklot p ON pa.parklot_id = p.parklot_id "
                 "WHERE pa.license_plate = :license "
                 "AND pa.status = 0";

    QMap<QString, QVariant> bindValues;
    bindValues[":license"] = userLicense;

    QString errorMsg;
    if (!dbHelper->executePreparedQuery(sql, bindValues, query, errorMsg)) {
        qDebug() << "检查申请状态失败:" << errorMsg;
        return;
    }

    QList<int> updatedAppIds;

    while (query.next()) {
        int appId = query.value("app_id").toInt();
        QString parklotId = query.value("parklot_id").toString();
        int parkStatus = query.value("park_status").toInt();

        if (isNotificationViewed(appId, 5)) continue;

        if (parkStatus != 1) {
            QString statusText = parkStatus == 0 ? "未公示" : "已被承租";
            messages += QString("您申请的车位 %1 已变为%2状态，申请自动取消\n").arg(parklotId, statusText);
            updatedAppIds.append(appId);
            recordNotificationViewed(appId, 5);
        }
    }

    // 更新申请状态为已拒绝
    if (!updatedAppIds.isEmpty()) {
        QString placeholders;
        for (int i = 0; i < updatedAppIds.size(); ++i) {
            placeholders += (i > 0 ? ",?" : "?");
        }

        QSqlQuery updateQuery;
        QString updateSql = QString("UPDATE parking_application SET status = 2 WHERE application_id IN (%1)").arg(placeholders);

        dbHelper->getDatabase().transaction();
        updateQuery.prepare(updateSql);

        for (int i = 0; i < updatedAppIds.size(); ++i) {
            updateQuery.bindValue(i, updatedAppIds[i]);
        }

        if (!updateQuery.exec()) {
            dbHelper->getDatabase().rollback();
            qDebug() << "更新申请状态失败:" << updateQuery.lastError().text();
        } else {
            dbHelper->getDatabase().commit();
        }
    }

    // 2. 检查是否有新通过的申请
    sql = "SELECT pa.application_id, pa.parklot_id "
          "FROM parking_application pa "
          "WHERE pa.license_plate = :license "
          "AND pa.status = 1 "
          "AND pa.apply_time >= DATE('now', '-30 days')";

    bindValues.clear();
    bindValues[":license"] = userLicense;

    if (!dbHelper->executePreparedQuery(sql, bindValues, query, errorMsg)) {
        qDebug() << "检查已批准申请失败:" << errorMsg;
        return;
    }

    while (query.next()) {
        int appId = query.value("application_id").toInt();
        QString parklotId = query.value("parklot_id").toString();

        if (isNotificationViewed(appId, 6)) continue;

        messages += QString("恭喜！您申请的车位 %1 已通过审核，成功承租！\n").arg(parklotId);
        recordNotificationViewed(appId, 6);
    }

    if (!messages.isEmpty()) {
        QMessageBox::information(this, "申请状态更新", messages);
    }
}

// 检查通知是否已查看
bool ParkingInfoWidget::isNotificationViewed(int appId, int actionType)
{
    QSqlQuery query;
    query.prepare("SELECT id FROM parking_log "
                 "WHERE parklot_id = :app_id AND action_type = :action_type AND is_notified = 1");
    query.bindValue(":app_id", appId);
    query.bindValue(":action_type", actionType);

    return (query.exec() && query.next());
}

// 记录通知已查看
void ParkingInfoWidget::recordNotificationViewed(int appId, int actionType)
{
    ParkDatabaseHelper *dbHelper = ParkDatabaseHelper::instance();
    if (!dbHelper->openDB("smart_upc.db")) {
        qDebug() << "数据库打开失败，无法记录通知";
        return;
    }

    QSqlDatabase db = dbHelper->getDatabase();
    db.transaction();

    QSqlQuery query(db);
    query.prepare("INSERT INTO parking_log (parklot_id, action_type, is_notified, action_time) "
                 "VALUES (:app_id, :action_type, 1, CURRENT_TIMESTAMP)");
    query.bindValue(":app_id", appId);
    query.bindValue(":action_type", actionType);

    if (!query.exec()) {
        qDebug() << "记录通知失败:" << query.lastError().text();
        db.rollback();
    } else {
        db.commit();
    }
}

// 取消承租逻辑
void ParkingInfoWidget::onCancelLease(const QString &parklotId)
{
    qDebug() << "处理取消承租请求，车位ID:" << parklotId;

    if (QMessageBox::question(this, "确认取消",
        QString("确定要取消车位 %1 的承租权吗？\n此操作将释放该车位并通知管理员。").arg(parklotId),
        QMessageBox::Yes | QMessageBox::No) != QMessageBox::Yes) {
        return;
    }

    QString userLicense = getOwnerLicensePlate();
    if (userLicense.isEmpty()) {
        QMessageBox::warning(this, "操作失败", "无法获取您的车牌号信息");
        return;
    }

    ParkDatabaseHelper *dbHelper = ParkDatabaseHelper::instance();
    if (!dbHelper->openDB("smart_upc.db")) {
        QMessageBox::critical(this, "数据库错误", "无法连接到数据库");
        return;
    }

    QSqlDatabase db = dbHelper->getDatabase();
    db.transaction();

    QSqlQuery query;
    QString sql = "UPDATE parklot "
                 "SET status = 0, license_number = NULL "
                 "WHERE parklot_id = :parklot_id AND license_number = :license AND status = 2";

    QMap<QString, QVariant> bindValues;
    bindValues[":parklot_id"] = parklotId;
    bindValues[":license"] = userLicense;

    QString errorMsg;
    if (!dbHelper->executePreparedQuery(sql, bindValues, query, errorMsg)) {
        db.rollback();
        QMessageBox::critical(this, "操作失败", "更新车位状态失败: " + errorMsg);
        return;
    }

    if (query.numRowsAffected() == 0) {
        db.rollback();
        QMessageBox::warning(this, "操作失败", "该车位不存在或已被释放");
        return;
    }

    // 记录操作日志
    sql = "INSERT INTO parking_log (parklot_id, action_type, action_time, is_notified) "
          "VALUES (:parklot_id, 3, CURRENT_TIMESTAMP, 0)";

    bindValues.clear();
    bindValues[":parklot_id"] = parklotId;
    if (!dbHelper->executePreparedQuery(sql, bindValues, query, errorMsg)) {
        db.rollback();
        QMessageBox::critical(this, "操作失败", "记录操作日志失败: " + errorMsg);
        return;
    }

    db.commit();
    QMessageBox::information(this, "操作成功", "已成功取消承租，该车位现已释放");
    refreshTable();
}
