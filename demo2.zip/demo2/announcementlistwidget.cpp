#include "announcementlistwidget.h"
#include <QHeaderView>
#include <QMessageBox>
#include <QSqlError>
#include <QDateTime>

AnnouncementListWidget::AnnouncementListWidget(QWidget *parent) : QWidget(parent)
{
    m_table = new QTableWidget(this);
    initTable();

    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->addWidget(m_table);
    setLayout(layout);

    connect(m_table, &QTableWidget::cellClicked, this, &AnnouncementListWidget::onItemClicked);
    refreshAnnouncements();  // 初始化时加载公告
}

void AnnouncementListWidget::initTable()
{
    m_table->setColumnCount(3);  // 标题、发布者、时间
    m_table->setHorizontalHeaderLabels({"标题", "发布者", "发布时间"});
    m_table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    m_table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_table->setSelectionBehavior(QAbstractItemView::SelectRows);
}

void AnnouncementListWidget::refreshAnnouncements()
{
    m_table->setRowCount(0);
    QSqlQuery query(database::instance().getDatabase());  // 使用与发布相同的数据库连接

    // 查询公告（确保表名和字段名与发布代码一致）
    QString sql = "SELECT id, title, publisher_name, publish_time "
                  "FROM announcements "
                  "ORDER BY publish_time DESC";

    if (!query.exec(sql)) {
        // 处理查询错误（显示详细错误信息）
        QMessageBox::critical(this, "数据库错误",
            QString("无法加载公告：%1\nSQL：%2")
            .arg(query.lastError().text())
            .arg(sql));
        return;
    }

    // 加载公告到表格
    int row = 0;
    while (query.next()) {
        m_table->insertRow(row);

        int id = query.value("id").toInt();
        QString title = query.value("title").toString();
        QString publisher = query.value("publisher_name").toString();
        QString time = query.value("publish_time").toString();

        m_table->setItem(row, 0, new QTableWidgetItem(title));
        m_table->item(row, 0)->setData(Qt::UserRole, id);  // 存储公告ID
        m_table->setItem(row, 1, new QTableWidgetItem(publisher));
        m_table->setItem(row, 2, new QTableWidgetItem(time));

        row++;
    }

    if (row == 0) {
        QMessageBox::information(this, "公告", "暂无公告");
    }
}

void AnnouncementListWidget::onItemClicked(int row, int column)
{
    Q_UNUSED(column);

    int announcementId = m_table->item(row, 0)->data(Qt::UserRole).toInt();
    QString title = m_table->item(row, 0)->text();
    QString publisher = m_table->item(row, 1)->text();
    QString time = m_table->item(row, 2)->text();

    // 查询公告详情
    QSqlQuery query(database::instance().getDatabase());
    query.prepare("SELECT content FROM announcements WHERE id = :id");
    query.bindValue(":id", announcementId);

    if (query.exec() && query.next()) {
        QString content = query.value("content").toString();

        // 显示公告详情
        QMessageBox::information(this, title,
            QString("发布者：%1\n发布时间：%2\n\n%3")
            .arg(publisher).arg(time).arg(content));
    } else {
        QMessageBox::warning(this, "错误", "无法加载公告详情");
    }
}
