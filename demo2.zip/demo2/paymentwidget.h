#ifndef PAYMENTWIDGET_H
#define PAYMENTWIDGET_H

#include <QWidget>
#include <QTabWidget>
#include <QTableWidget>
#include "ownerinfodatabase.h"

class PaymentWidget : public QWidget
{
    Q_OBJECT

public:
    explicit PaymentWidget(int userId, QWidget *parent = nullptr); // 接收业主user_id
    ~PaymentWidget() override;
    void refreshTable();

private slots:
    void onPayClicked(); // 处理缴费操作

private:
    OwnerInfoDatabase* db; // 复用数据库连接
    int m_userId; // 业主user_id（用于过滤自身记录）
    QTabWidget* tabWidget;
    QTableWidget* unpaidTable; // 未缴费表格
    QTableWidget* paidTable; // 已缴费表格
};

#endif // PAYMENTWIDGET_H
