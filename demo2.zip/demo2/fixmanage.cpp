#include "fixmanage.h"
#include "ui_fixmanage.h"
#include <QMessageBox>
#include <QDebug>
#include <QSizePolicy>
#include <QHeaderView>
#include <QDialog>
#include <QVBoxLayout>
#include <QLabel>

FixManage::FixManage(const QString& staffName, QWidget *parent)
    : QWidget(parent), ui(new Ui::FixManage), m_staffName(staffName) {
    ui->setupUi(this);
    setWindowTitle("维修任务管理 - " + staffName);

    // 初始化数据库模型
    model = new QSqlQueryModel(this);
    ui->taskTableView->setModel(model);

    // 设置表格自适应
    ui->taskTableView->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    ui->taskTableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->taskTableView->verticalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    ui->taskTableView->setMinimumSize(800, 600);
    ui->taskTableView->setEditTriggers(QAbstractItemView::NoEditTriggers);

    // 连接信号槽
    connect(ui->taskTableView, &QTableView::clicked, this, &FixManage::onCellClicked);
    connect(ui->taskTableView, &QTableView::doubleClicked, this, &FixManage::showFeedback);
    connect(ui->refreshBtn, &QPushButton::clicked, this, &FixManage::refreshTasks);
    connect(ui->updateBtn, &QPushButton::clicked, this, &FixManage::updateStatus);

    // 配置进度下拉框
    ui->statusCombo->addItems({"已完成", "维修中", "未维修"});

    // 首次加载任务
    refreshTasks();
}

FixManage::~FixManage() {
    delete ui;
}

QString FixManage::statusToText(int statusCode) {
    switch (statusCode) {
        case 0: return "已完成";
        case 1: return "维修中";
        case 2: return "未维修";
        default: return "未知状态";
    }
}

void FixManage::refreshTasks() {
    // 查询语句包含评价信息
    QString sql = QString(R"(
        SELECT
            t.id,
            t.address,
            t.situation,
            t.reportTime,
            CASE t.finishedOrNot
                WHEN 0 THEN '已完成'
                WHEN 1 THEN '维修中'
                WHEN 2 THEN '未维修'
                ELSE '未知状态'
            END AS status_text,
            t.rating,
            t.feedback
        FROM task t
        JOIN account a ON t.staffFix = a.username
        WHERE a.username = '%1'
    )").arg(m_staffName);

    qDebug() << "执行SQL:" << sql;
    QSqlQuery query = DatabaseHelper::instance().executeQuery(sql);

    if (!query.isActive()) {
        qDebug() << "查询失败:" << query.lastError().text();
        QMessageBox::critical(this, "数据库错误", "查询任务失败：" + query.lastError().text());
        return;
    }

    if (query.size() == 0) {
        qDebug() << "无任务数据";
        model->setQuery("SELECT id, address, situation, reportTime, '无数据' AS status_text, 0 AS rating, '' AS feedback FROM task WHERE 1=0");
        return;
    }
    model->setQuery(query);
    model->setHeaderData(0, Qt::Horizontal, "任务ID");
    model->setHeaderData(1, Qt::Horizontal, "维修地址");
    model->setHeaderData(2, Qt::Horizontal, "故障描述");
    model->setHeaderData(3, Qt::Horizontal, "报修时间");
    model->setHeaderData(4, Qt::Horizontal, "完成状态");
    model->setHeaderData(5, Qt::Horizontal, "评分");
    model->setHeaderData(6, Qt::Horizontal, "评价");
}

void FixManage::onCellClicked(const QModelIndex& index) {
    if (index.isValid()) {
        ui->taskTableView->selectRow(index.row());
    }
}

void FixManage::updateStatus() {
    QModelIndexList selected = ui->taskTableView->selectionModel()->selectedRows();
    if (selected.isEmpty()) {
        QMessageBox::warning(this, "提示", "请选择要更新的任务！");
        return;
    }

    int row = selected.first().row();
    int taskId = model->data(model->index(row, 0)).toInt();
    int newStatus = ui->statusCombo->currentIndex();

    QString sql = QString(R"(
        UPDATE task
        SET finishedOrNot = %1
        WHERE id = %2
    )").arg(newStatus).arg(taskId);

    if (DatabaseHelper::instance().executeUpdate(sql)) {
        QMessageBox::information(this, "成功", "维修进度更新完成！");
        refreshTasks();
    } else {
        QMessageBox::critical(this, "失败", "更新进度时发生错误！");
    }
}

void FixManage::showFeedback() {
    QModelIndexList selected = ui->taskTableView->selectionModel()->selectedRows();
    if (selected.isEmpty()) {
        return;
    }

    int row = selected.first().row();
    int taskId = model->data(model->index(row, 0)).toInt();
    int rating = model->data(model->index(row, 5)).toInt();
    QString feedback = model->data(model->index(row, 6)).toString();

    // 创建评价查看对话框
    QDialog dialog(this);
    dialog.setWindowTitle("报修评价 - 任务ID: " + QString::number(taskId));
    dialog.setMinimumSize(400, 300);

    QVBoxLayout *layout = new QVBoxLayout(&dialog);

    // 评分显示
    QLabel *ratingLabel = new QLabel("评分:", &dialog);
    QLabel *ratingValue = new QLabel(QString::number(rating) + " 星", &dialog);

    // 评价内容显示
    QLabel *feedbackLabel = new QLabel("评价内容:", &dialog);
    QTextEdit *feedbackText = new QTextEdit(&dialog);
    feedbackText->setPlainText(feedback);
    feedbackText->setReadOnly(true);

    QHBoxLayout *ratingLayout = new QHBoxLayout;
    ratingLayout->addWidget(ratingLabel);
    ratingLayout->addWidget(ratingValue);

    layout->addLayout(ratingLayout);
    layout->addWidget(feedbackLabel);
    layout->addWidget(feedbackText);

    // 关闭按钮
    QPushButton *closeButton = new QPushButton("关闭", &dialog);
    connect(closeButton, &QPushButton::clicked, &dialog, &QDialog::accept);
    layout->addWidget(closeButton, 0, Qt::AlignRight);

    dialog.setLayout(layout);
    dialog.exec();
}
