#pragma once
#include <QWidget>
#include <QTableWidget>
#include <QPushButton>
#include <QStatusBar>
#include <QSpinBox>
#include <QLineEdit>
#include <QComboBox>
#include <QDialogButtonBox>
class StaffManageWidget :public QWidget {
  Q_OBJECT
public:
  explicit StaffManageWidget(QWidget* parent = nullptr);
  void refreshTable();
  StaffManageWidget(const QString& currentAdminName, QWidget* parent = nullptr);
  ~StaffManageWidget() override;
private slots:
  void onAdd();
  void onEdit();
  void onDelete();
  void onSearch();
  void createTables();
private:
  QTableWidget* table;
  QPushButton* btnAdd;
  QPushButton* btnEdit;
  QPushButton* btnDelete;
  QPushButton* btnSearch;
  QLineEdit *searchEdit;
  QStatusBar *statusBar;
  QString m_currentAdminName;

void loadstaff();
};
