
#include "leaveapprovewidget.h"
#include <QHeaderView>
#include <QMessageBox>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QDateTime>
#include <QLineEdit>
#include <QSqlError>
#include "database.h"

// 接收审批人姓名
LeaveApproveWidget::LeaveApproveWidget(const QString& adminName, QWidget* parent)
    : QWidget(parent), dbManager(DBManager::instance()), m_adminName(adminName)
{
    setupUI();
    setupConnections();

    if (!dbManager.isOpen()) {
        if (!dbManager.openDB("smart_upc.db")) {
            QMessageBox::critical(this, "错误", "数据库打开失败: " + dbManager.lastError());
        } else {
            refreshTable();
        }
    } else {
        refreshTable();
    }
}

LeaveApproveWidget::~LeaveApproveWidget()
{

}

void LeaveApproveWidget::setupUI()
{
    // 初始化UI组件
    table = new QTableWidget(this);
    btnApprove = new QPushButton("批准", this);
    btnReject = new QPushButton("拒绝", this);
    searchInput = new QLineEdit(this);
    searchInput->setPlaceholderText("输入员工姓名查询");
    statusCombo = new QComboBox(this);
    btnSearch = new QPushButton("查询", this);
    btnReset = new QPushButton("重置", this);

    // 初始化状态筛选框
    statusCombo->addItem("全部状态", -1);
    statusCombo->addItem("待审批", 0);
    statusCombo->addItem("已批准", 1);
    statusCombo->addItem("已拒绝", 2);

    // 设置表格
    table->setColumnCount(7);
    table->setHorizontalHeaderLabels({"员工姓名", "开始日期", "结束日期", "原因", "状态", "审批人", "审批时间"});
    table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    table->setSelectionBehavior(QAbstractItemView::SelectRows);
    table->setEditTriggers(QAbstractItemView::NoEditTriggers);

    // 布局
    QHBoxLayout* searchLayout = new QHBoxLayout;
    searchLayout->addWidget(searchInput);
    searchLayout->addWidget(statusCombo);
    searchLayout->addWidget(btnSearch);
    searchLayout->addWidget(btnReset);

    QHBoxLayout* btnLayout = new QHBoxLayout;
    btnLayout->addWidget(btnApprove);
    btnLayout->addWidget(btnReject);

    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    mainLayout->addLayout(searchLayout);
    mainLayout->addWidget(table);
    mainLayout->addLayout(btnLayout);
}

void LeaveApproveWidget::setupConnections()
{
    connect(btnApprove, &QPushButton::clicked, this, &LeaveApproveWidget::onApprove);
    connect(btnReject, &QPushButton::clicked, this, &LeaveApproveWidget::onReject);
    connect(btnSearch, &QPushButton::clicked, this, &LeaveApproveWidget::onSearch);
    connect(btnReset, &QPushButton::clicked, this, &LeaveApproveWidget::onReset);
}

void LeaveApproveWidget::refreshTable()
{
    table->setRowCount(0);

    QSqlQuery query(dbManager.getDatabase());
    // 关联staff表查询员工姓名（通过staff_id关联）
    QString sql = "SELECT l.staff_id, s.name AS staff_name, l.start_date, l.end_date, "
                 "l.reason, l.status, l.approver_name, l.approve_time, l.id "
                 "FROM leaves l "
                 "LEFT JOIN staff s ON l.staff_id = s.id "
                 "WHERE 1=1";

    // 搜索条件：按员工姓名
    QString keyword = searchInput->text().trimmed();
    int status = statusCombo->currentData().toInt();

    if (!keyword.isEmpty()) {
        sql += " AND s.name LIKE :keyword"; // 按员工姓名模糊查询
    }

    if (status != -1) {
        sql += " AND l.status = :status";
    }

    sql += " ORDER BY l.status ASC, l.id DESC";

    query.prepare(sql);

    if (!keyword.isEmpty()) {
        query.bindValue(":keyword", "%" + keyword + "%");
    }

    if (status != -1) {
        query.bindValue(":status", status);
    }

    if (!query.exec()) {
        QMessageBox::critical(this, "错误", "查询失败: " + query.lastError().text());
        return;
    }

    while (query.next()) {
        int row = table->rowCount();
        table->insertRow(row);

        QTableWidgetItem* staffNameItem = new QTableWidgetItem(query.value("staff_name").toString());
        table->setItem(row, 0, staffNameItem); // 先将item添加到表格

        int leaveId = query.value("id").toInt();
        staffNameItem->setData(Qt::UserRole, leaveId); // 安全设置数据

        // 开始日期
        table->setItem(row, 1, new QTableWidgetItem(query.value("start_date").toString()));
        // 结束日期
        table->setItem(row, 2, new QTableWidgetItem(query.value("end_date").toString()));
        // 原因
        table->setItem(row, 3, new QTableWidgetItem(query.value("reason").toString()));
        // 状态
        int status = query.value("status").toInt();
        QString statusText;
        switch (status) {
            case 0: statusText = "待审批"; break;
            case 1: statusText = "已批准"; break;
            case 2: statusText = "已拒绝"; break;
            default: statusText = "未知";
        }
        table->setItem(row, 4, new QTableWidgetItem(statusText));
        // 审批人姓名
        table->setItem(row, 5, new QTableWidgetItem(query.value("approver_name").toString()));
        // 审批时间
        table->setItem(row, 6, new QTableWidgetItem(query.value("approve_time").toString()));
    }
}

bool LeaveApproveWidget::updateLeaveStatus(int leaveId, int status)
{
    QSqlQuery query(dbManager.getDatabase());
    query.prepare("UPDATE leaves SET status = :status, "
                 "approve_time = :time, "
                 "approver_name = :approver " // 记录审批人姓名
                 "WHERE id = :id AND status = 0");

    query.bindValue(":status", status);
    query.bindValue(":time", QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss"));
    query.bindValue(":approver", m_adminName); // 审批人姓名（当前管理员）
    query.bindValue(":id", leaveId);

    if (!query.exec()) {
        QMessageBox::critical(this, "错误", "更新失败: " + query.lastError().text());
        return false;
    }

    return query.numRowsAffected() > 0;
}

void LeaveApproveWidget::onApprove()
{
    int row = table->currentRow();
    if (row < 0) {
        QMessageBox::warning(this, "提示", "请选择要审批的记录!");
        return;
    }

    // 获取隐藏的请假ID（从UserRole中获取）
    int leaveId = table->item(row, 0)->data(Qt::UserRole).toInt();

    if (updateLeaveStatus(leaveId, 1)) {
        QMessageBox::information(this, "成功", "已批准该请假申请!");
        refreshTable();
    }
}

void LeaveApproveWidget::onReject()
{
    int row = table->currentRow();
    if (row < 0) {
        QMessageBox::warning(this, "提示", "请选择要审批的记录!");
        return;
    }

    // 获取隐藏的请假ID
    int leaveId = table->item(row, 0)->data(Qt::UserRole).toInt();

    if (updateLeaveStatus(leaveId, 2)) {
        QMessageBox::information(this, "成功", "已拒绝该请假申请!");
        refreshTable();
    }
}

void LeaveApproveWidget::onSearch()
{
    refreshTable();
}

void LeaveApproveWidget::onReset()
{
    searchInput->clear();
    statusCombo->setCurrentIndex(0);
    refreshTable();
}
