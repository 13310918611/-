#include "repairrequestwidget.h"
#include <QVBoxLayout>
#include <QSqlQuery>
#include <QDateTime>
#include <QMessageBox>
#include <QLabel>
#include "ownerinfowidget.h"

RepairRequestWidget::RepairRequestWidget(int userId, database& db, OwnerInfoWidget* ownerInfoWidget, QWidget *parent)
    : QWidget(parent), m_userId(userId), db(db), m_ownerInfoWidget(ownerInfoWidget)
{
    // 确保数据库驱动已加载
    if (!QSqlDatabase::isDriverAvailable("QSQLITE")) {
        QMessageBox::critical(this, "错误", "SQLite驱动不可用！");
        return;
    }

    // 初始化UI
    QVBoxLayout *layout = new QVBoxLayout(this);

    // 故障描述
    layout->addWidget(new QLabel("故障描述："));
    descEdit = new QTextEdit();
    layout->addWidget(descEdit);

    // 提交按钮
    submitBtn = new QPushButton("提交报修");
    layout->addWidget(submitBtn);
    connect(submitBtn, &QPushButton::clicked, this, &RepairRequestWidget::onSubmit);

    setLayout(layout);

    // 尝试删除address字段的唯一约束（如果存在）
    dropAddressUniqueConstraint();
}

RepairRequestWidget::~RepairRequestWidget()
{
    // 析构函数会自动处理成员指针的释放
}

void RepairRequestWidget::dropAddressUniqueConstraint()
{
    QSqlQuery query(db.getDatabase());

    // 检查是否存在address唯一约束
    bool hasAddressConstraint = false;
    if (query.exec("PRAGMA index_list(task)")) {
        while (query.next()) {
            QString indexName = query.value("name").toString();
            if (indexName.contains("address") && indexName.contains("unique")) {
                hasAddressConstraint = true;

                // 尝试删除唯一约束
                if (query.exec(QString("DROP INDEX %1").arg(indexName))) {
                    qDebug() << "成功删除address唯一约束:" << indexName;
                } else {
                    qDebug() << "删除address唯一约束失败:" << query.lastError().text();
                    QMessageBox::warning(this, "警告", "无法删除address唯一约束，请确保数据库可写");
                }
                break;
            }
        }
    }

    if (!hasAddressConstraint) {
        qDebug() << "未发现address唯一约束";
    }
}

void RepairRequestWidget::onSubmit()
{
    QString desc = descEdit->toPlainText();
    QString address = m_ownerInfoWidget->building() + "幢" + m_ownerInfoWidget->room() + "号";

    if (desc.isEmpty() || address.isEmpty()) {
        QMessageBox::warning(this, "提示", "请填写故障描述并确保个人信息完整！");
        return;
    }

    // 开始事务确保id自增
    QSqlQuery transactionQuery;
    if (!db.query("BEGIN TRANSACTION", transactionQuery)) {
        QMessageBox::critical(this, "失败", "无法开始事务");
        return;
    }

    // 插入报修请求（不指定id，依赖数据库自增）
    QString sql = QString(
        "INSERT INTO task(situation, address, reportTime, finishedOrNot) "
        "VALUES ('%1', '%2', '%3', 2)")
        .arg(desc.replace("'", "''"))  // 转义单引号
        .arg(address.replace("'", "''"))
        .arg(QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss"));

    QSqlQuery query;
    if (db.query(sql, query)) {
        qint64 newId = query.lastInsertId().toLongLong();
        if (newId > 0) {
            // 提交事务
            if (db.query("COMMIT", transactionQuery)) {
                QMessageBox::information(this, "成功",
                    QString("报修请求已提交（ID:%1），工作人员将尽快处理！").arg(newId));
                descEdit->clear();
            } else {
                db.query("ROLLBACK", transactionQuery);
                QMessageBox::critical(this, "失败", "无法提交事务");
            }
        } else {
            db.query("ROLLBACK", transactionQuery);
            QMessageBox::critical(this, "失败", "获取新生成的ID失败");
        }
    } else {
        db.query("ROLLBACK", transactionQuery);

        // 特别处理唯一约束错误
        QString errorMsg = db.lastError();
        if (errorMsg.contains("UNIQUE constraint failed")) {
            errorMsg = "同一地址的报修请求已存在！\n\n"
                       "若需提交新请求，请检查：\n"
                       "- 确认业主信息中的楼号和房间号正确\n"
                       "- 联系管理员删除重复的报修记录";
        }

        QMessageBox::critical(this, "失败", "数据库错误：" + errorMsg);
    }
}

void RepairRequestWidget::refreshTable()
{
    descEdit->clear();
}
