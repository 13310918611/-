#include "staffwindow.h"
#include "ui_staffwindow.h"
#include "dailycheckin.h"
#include "leaveapplywidget.h"
#include "parklotmanage.h"
#include "ownermanage.h"
#include "chargemanage.h"
#include "fixmanage.h"
#include <QMainWindow>
#include <QMenuBar>
#include <QMenu>
#include <QAction>
#include <QStackedWidget>
#include <QStatusBar>

StaffWindow::StaffWindow(int userId, const QString& staffName, QWidget *parent) :
    QMainWindow(parent), m_userID(userId), m_staffName(staffName), ui(new Ui::StaffWindow)
{
    ui->setupUi(this);
    stackedWidget = new QStackedWidget(this);
    dailycheckin = new DailyCheckIn(m_staffName, this);
    leaveapplywidget = new LeaveApplyWidget(m_userID, m_staffName, this);
    parklotmanage = new ParkLotManage(this);
    ownermanage = new OwnerManage(this);
    chargemanage = new ChargeManage(this);
    fixmanage = new FixManage(m_staffName, this);
    announcementWidget = new AnnouncementListWidget(this);


    stackedWidget->addWidget(dailycheckin);
    stackedWidget->addWidget(leaveapplywidget);
    stackedWidget->addWidget(parklotmanage);
    stackedWidget->addWidget(ownermanage);
    stackedWidget->addWidget(chargemanage);
    stackedWidget->addWidget(fixmanage);
    stackedWidget->addWidget(announcementWidget);

    setWindowTitle(QString("工作人员系统 - 欢迎你：%1").arg(m_staffName));

    // 设置centralWidget为stackedWidget
    ui->centralwidget->deleteLater(); // 先删除UI文件中默认的centralWidget
    setCentralWidget(stackedWidget);
    setupMenus();
    stackedWidget->setCurrentWidget(dailycheckin);
}

StaffWindow::~StaffWindow()
{
    delete ui;
}
void StaffWindow::setupMenus(){
    QMenuBar*menuBar=ui->menubar;
    menuBar->clear();
    QMenu* Dailycheckin=menuBar->addMenu("每日出勤打卡");
    QMenu* leaveapplywidget=menuBar->addMenu("请销假申请");
    QMenu* Parklotmanage=menuBar->addMenu("车位管理");
    QMenu* Ownermanage=menuBar->addMenu("业主管理");
    QMenu* Chargemanage=menuBar->addMenu("缴费管理");
    QMenu* Fixmanage=menuBar->addMenu("报修请求");
    QMenu* Announcement = menuBar->addMenu("公告");

    QAction *checkinAction = Dailycheckin->addAction("每日出勤打卡");
    QAction *leaveapplyAction = leaveapplywidget->addAction("请销假申请");
    QAction *parklotmanageAction = Parklotmanage->addAction("车位管理");
    QAction *ownermanageAction = Ownermanage->addAction("业主管理");
    QAction *chargemanageAction = Chargemanage->addAction("缴费管理");
    QAction *fixmanageAction = Fixmanage->addAction("报修请求");
    QAction *announceAction = Announcement->addAction("查看公告");

    connect(checkinAction, &QAction::triggered, this, &StaffWindow::showDailyCheckIn);
    connect(leaveapplyAction, &QAction::triggered, this, &StaffWindow::showLeaveApply);
    connect(parklotmanageAction, &QAction::triggered, this, &StaffWindow::showParkLotManage);
    connect(ownermanageAction, &QAction::triggered, this, &StaffWindow::showOwnerManage);
    connect(chargemanageAction, &QAction::triggered, this, &StaffWindow::showChargeManage);
    connect(fixmanageAction, &QAction::triggered, this, &StaffWindow::showFixManage);
    connect(announceAction, &QAction::triggered, this, &StaffWindow::showAnnouncements);
}

void StaffWindow::showDailyCheckIn() {
    stackedWidget->setCurrentWidget(dailycheckin);
    dailycheckin->refreshTable(); //此处报错则在对应的.h头文件中，在public中声明void refreshTable();
}
void StaffWindow::showLeaveApply() {
    stackedWidget->setCurrentWidget(leaveapplywidget);
    leaveapplywidget->refreshTable(); //此处报错则在对应的.h头文件中，在public中声明void refreshTable();
}
void StaffWindow::showParkLotManage() {
    stackedWidget->setCurrentWidget(parklotmanage);
    parklotmanage->refreshTable(); //此处报错则在对应的.h头文件中，在public中声明void refreshTable();
}
void StaffWindow::showOwnerManage() {
    stackedWidget->setCurrentWidget(ownermanage);
    ownermanage->refreshTable(); //此处报错则在对应的.h头文件中，在public中声明void refreshTable();
}
void StaffWindow::showChargeManage() {
    stackedWidget->setCurrentWidget(chargemanage);
    chargemanage->refreshTable(); //此处报错则在对应的.h头文件中，在public中声明void refreshTable();
}
void StaffWindow::showFixManage() {
    stackedWidget->setCurrentWidget(fixmanage);
    fixmanage->refreshTasks(); //此处报错则在对应的.h头文件中，在public中声明void refreshTable();
}
void StaffWindow::showAnnouncements()
{
    stackedWidget->setCurrentWidget(announcementWidget);
    announcementWidget->refreshAnnouncements(); // 刷新列表
}
