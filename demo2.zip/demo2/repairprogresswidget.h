#ifndef REPAIRPROGRESSWIDGET_H
#define REPAIRPROGRESSWIDGET_H

#include <QWidget>
#include <QTableWidget>
#include <QDialog>
#include <QComboBox>
#include <QTextEdit>
#include "database.h"

class OwnerInfoWidget;

class RepairProgressWidget : public QWidget
{
    Q_OBJECT

public:
    RepairProgressWidget(int userId, database& db, OwnerInfoWidget* ownerInfoWidget, QWidget *parent = nullptr);
    ~RepairProgressWidget();
    void refreshTable();

private slots:
    void onFeedbackClicked();

private:
    QTableWidget *progressTable;
    int m_userId;
    database& db;
    OwnerInfoWidget* m_ownerInfoWidget;

    void showFeedbackDialog(int taskId);
};

#endif // REPAIRPROGRESSWIDGET_H
