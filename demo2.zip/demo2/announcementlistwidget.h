#ifndef ANNOUNCEMENTLISTWIDGET_H
#define ANNOUNCEMENTLISTWIDGET_H

#include <QWidget>
#include <QTableWidget>
#include <QVBoxLayout>
#include <QSqlQuery>
#include "database.h"

class AnnouncementListWidget : public QWidget
{
    Q_OBJECT
public:
    explicit AnnouncementListWidget(QWidget *parent = nullptr);
    void refreshAnnouncements();

private slots:
    void onItemClicked(int row, int column);

private:
    QTableWidget *m_table;
    void initTable();
};

#endif // ANNOUNCEMENTLISTWIDGET_H
