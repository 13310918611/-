#ifndef FIXMANAGE_H
#define FIXMANAGE_H

#include <QWidget>
#include <QSqlQueryModel>
#include <QTableView>
#include <QComboBox>
#include <QLineEdit>
#include <QPushButton>
#include <QTextEdit>
#include "databasehelper.h"

namespace Ui {
class FixManage;
}

class FixManage : public QWidget {
    Q_OBJECT

public:
    explicit FixManage(const QString& staffName, QWidget *parent = nullptr);
    ~FixManage();
    void refreshTasks();

private slots:
    void updateStatus();
    void onCellClicked(const QModelIndex& index);
    void showFeedback();

private:
    Ui::FixManage *ui;
    QString m_staffName;
    QSqlQueryModel *model;
    // 辅助方法：将数字状态转换为文字
    QString statusToText(int statusCode);
};

#endif // FIXMANAGE_H
