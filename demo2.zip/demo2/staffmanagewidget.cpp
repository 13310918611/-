#include "staffmanagewidget.h"
#include "database.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QMessageBox>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QHeaderView>
#include <QStatusBar>
#include <QLineEdit>
#include <QComboBox>
#include <QDialogButtonBox>
#include <QTableWidgetItem>
#include <QDialog>
#include <QFormLayout>
#include <QDebug>


// 构造函数：接收当前管理员姓名
StaffManageWidget::StaffManageWidget(const QString& currentAdminName, QWidget* parent)
    : QWidget(parent), m_currentAdminName(currentAdminName) {
    // 初始化UI组件
    table = new QTableWidget(this);
    table->setColumnCount(4);
    table->setHorizontalHeaderLabels({"姓名", "职位", "电话", "在职情况"});
    table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    btnAdd = new QPushButton("添加", this);
    btnEdit = new QPushButton("编辑", this);
    btnDelete = new QPushButton("删除", this);

    searchEdit = new QLineEdit(this);
    searchEdit->setPlaceholderText("输入姓名查询");
    btnSearch = new QPushButton("查询", this);

    statusBar = new QStatusBar(this);

    // 布局
    QHBoxLayout* btnLayout = new QHBoxLayout;
    btnLayout->addWidget(btnAdd);
    btnLayout->addWidget(btnEdit);
    btnLayout->addWidget(btnDelete);

    QHBoxLayout* searchLayout = new QHBoxLayout;
    searchLayout->addWidget(searchEdit);
    searchLayout->addWidget(btnSearch);

    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    mainLayout->addLayout(searchLayout);
    mainLayout->addWidget(table);
    mainLayout->addLayout(btnLayout);
    mainLayout->addWidget(statusBar);

    // 连接信号
    connect(btnAdd, &QPushButton::clicked, this, &StaffManageWidget::onAdd);
    connect(btnEdit, &QPushButton::clicked, this, &StaffManageWidget::onEdit);
    connect(btnDelete, &QPushButton::clicked, this, &StaffManageWidget::onDelete);
    connect(btnSearch, &QPushButton::clicked, this, &StaffManageWidget::onSearch);
    connect(searchEdit, &QLineEdit::returnPressed, this, &StaffManageWidget::onSearch);

    // 数据库初始化
    if (!database::instance().isOpen()) {
        if (!database::instance().openDB("smart_upc.db")) {
            QMessageBox::critical(this, "数据库错误", "无法连接到数据库: " + database::instance().lastError());
            return;
        }
    }
    createTables();
    refreshTable();
    table->setEditTriggers(QAbstractItemView::NoEditTriggers);
}

StaffManageWidget::~StaffManageWidget() {}


// 点击添加时弹窗，用户填写信息
void StaffManageWidget::onAdd() {
    QDialog dialog(this);
    dialog.setWindowTitle("添加员工");
    dialog.setMinimumWidth(300);

    // 弹窗内容
    QFormLayout* form = new QFormLayout(&dialog);

    QLineEdit* nameEdit = new QLineEdit(&dialog);
    form->addRow("姓名*", nameEdit);

    QComboBox* roleCombo = new QComboBox(&dialog);
    roleCombo->addItem("物业工作人员", 1);
    roleCombo->addItem("物业管理员", 0);
    form->addRow("职位*", roleCombo);

    QLineEdit* phoneEdit = new QLineEdit(&dialog);
    form->addRow("电话*", phoneEdit);

    QComboBox* statusCombo = new QComboBox(&dialog);
    statusCombo->addItem("在职", 1);
    statusCombo->addItem("离职", 0);
    form->addRow("在职情况", statusCombo);

    // 按钮
    QDialogButtonBox* btnBox = new QDialogButtonBox(
        QDialogButtonBox::Ok | QDialogButtonBox::Cancel, &dialog
    );
    form->addRow(btnBox);
    connect(btnBox, &QDialogButtonBox::accepted, &dialog, &QDialog::accept);
    connect(btnBox, &QDialogButtonBox::rejected, &dialog, &QDialog::reject);

    // 显示弹窗
    if (dialog.exec() != QDialog::Accepted) return;

    // 验证输入
    QString name = nameEdit->text().trimmed();
    QString phone = phoneEdit->text().trimmed();
    int role = roleCombo->currentData().toInt();
    int status = statusCombo->currentData().toInt();

    if (name.isEmpty() || phone.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "姓名和电话为必填项！");
        return;
    }

    // 插入数据库
    QSqlDatabase db = database::instance().getDatabase();
    db.transaction();

    QSqlQuery query(db);
    query.prepare("INSERT INTO staff (name, role, phone, status) "
                 "VALUES (:name, :role, :phone, :status)");
    query.bindValue(":name", name);
    query.bindValue(":role", role);
    query.bindValue(":phone", phone);
    query.bindValue(":status", status);

    if (!query.exec()) {
        db.rollback();
        QMessageBox::critical(this, "失败", "添加失败: " + query.lastError().text());
        return;
    }

    // 获取自动生成的id
    int newId = query.lastInsertId().toInt();

    // 同步插入attendance表
    QSqlQuery attQuery(db);
    if (role == 1) {
        attQuery.prepare("INSERT INTO attendance (id, name, phone, today, monthly) "
                           "VALUES (:id, :name, :phone, 0, 1)"); // monthly=1（默认出勤1天）
        attQuery.bindValue(":id", newId);
        attQuery.bindValue(":name", name);
        attQuery.bindValue(":phone", phone);

        if (attQuery.exec()) {
            db.commit();
            QMessageBox::information(this, "成功", "工作人员添加成功！");
            refreshTable();
        } else {
            db.rollback();
            QMessageBox::critical(this, "失败", "同步考勤记录失败: " + attQuery.lastError().text());
        }
    } else {
        // 管理员不插入出勤表
        db.commit();
        QMessageBox::information(this, "成功", "管理员添加成功！");
        refreshTable();
    }
}


// 编辑功能：允许管理员编辑自己的记录
void StaffManageWidget::onEdit() {
    QList<QTableWidgetItem*> selected = table->selectedItems();
    if (selected.isEmpty()) {
        QMessageBox::warning(this, "提示", "请选择要编辑的记录");
        return;
    }

    int row = selected.first()->row();
    QString name = table->item(row, 0)->text();       // 姓名
    QString roleText = table->item(row, 1)->text();   // 职位
    QString phone = table->item(row, 2)->text();      // 电话
    QString statusText = table->item(row, 3)->text(); // 在职情况

    // 1. 获取被编辑记录的role和id
    int targetRole = (roleText == "物业管理员") ? 0 : 1;
    int targetId = -1;
    QSqlQuery idQuery(database::instance().getDatabase());
    idQuery.prepare("SELECT id FROM staff WHERE name = :name AND phone = :phone");
    idQuery.bindValue(":name", name);
    idQuery.bindValue(":phone", phone);
    if (!idQuery.exec() || !idQuery.next()) {
        QMessageBox::warning(this, "错误", "无法获取记录信息，编辑失败");
        return;
    }
    targetId = idQuery.value("id").toInt();

    // 2. 权限判断：通过姓名判断是否为当前管理员
    bool isSelf = (name == m_currentAdminName);

    if (targetRole == 0 && !isSelf) { // 其他管理员记录
        QMessageBox::critical(this, "无权限", "不可编辑其他管理员的记录！");
        return;
    }

    // 3. 弹窗编辑信息
    QDialog dialog(this);
    dialog.setWindowTitle("编辑员工");
    QFormLayout* form = new QFormLayout(&dialog);

    QLineEdit* nameEdit = new QLineEdit(name, &dialog);
    form->addRow("姓名*", nameEdit);

    QComboBox* roleCombo = new QComboBox(&dialog);
    roleCombo->addItem("物业工作人员", 1);
    roleCombo->addItem("物业管理员", 0);
    roleCombo->setCurrentIndex(targetRole == 0 ? 1 : 0);
    form->addRow("职位*", roleCombo);

    QLineEdit* phoneEdit = new QLineEdit(phone, &dialog);
    form->addRow("电话*", phoneEdit);

    QComboBox* statusCombo = new QComboBox(&dialog);
    statusCombo->addItem("在职", 1);
    statusCombo->addItem("离职", 0);
    statusCombo->setCurrentIndex(statusText == "在职" ? 0 : 1);
    form->addRow("在职情况", statusCombo);

    QDialogButtonBox* btnBox = new QDialogButtonBox(
        QDialogButtonBox::Ok | QDialogButtonBox::Cancel, &dialog
    );
    form->addRow(btnBox);
    connect(btnBox, &QDialogButtonBox::accepted, &dialog, &QDialog::accept);
    connect(btnBox, &QDialogButtonBox::rejected, &dialog, &QDialog::reject);

    if (dialog.exec() != QDialog::Accepted) return;

    // 4. 验证并更新数据库
    QString newName = nameEdit->text().trimmed();
    QString newPhone = phoneEdit->text().trimmed();
    int newRole = roleCombo->currentData().toInt();
    int newStatus = statusCombo->currentData().toInt();

    if (newName.isEmpty() || newPhone.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "姓名和电话为必填项！");
        return;
    }

    // 检查是否修改了自己的姓名（避免权限丢失）
    bool isChangingName = (name != newName);
    if (isSelf && isChangingName) {
        if (QMessageBox::question(this, "警告", "修改管理员姓名将影响权限判断，确定要修改吗？") != QMessageBox::Yes) {
            return;
        }
    }

    QSqlDatabase db = database::instance().getDatabase();
    db.transaction();

    QSqlQuery query(db);
    query.prepare("UPDATE staff SET name=:name, role=:role, phone=:phone, status=:status "
                 "WHERE id=:id");
    query.bindValue(":name", newName);
    query.bindValue(":role", newRole);
    query.bindValue(":phone", newPhone);
    query.bindValue(":status", newStatus);
    query.bindValue(":id", targetId);

    bool success = query.exec();

    // 同步更新考勤表
    if (success) {
        QSqlQuery attQuery(db);
        attQuery.prepare("UPDATE attendance SET name=:name, phone=:phone WHERE id=:id");
        attQuery.bindValue(":name", newName);
        attQuery.bindValue(":phone", newPhone);
        attQuery.bindValue(":id", targetId);
        attQuery.exec();
    }

    if (success) {
        db.commit();
        QMessageBox::information(this, "成功", "记录已更新！");
        refreshTable();

        // 如果修改了自己的姓名，更新当前管理员姓名
        if (isSelf && isChangingName) {
            m_currentAdminName = newName;
            statusBar->showMessage("已更新管理员姓名为：" + newName, 3000);
        }
    } else {
        db.rollback();
        QMessageBox::critical(this, "失败", "更新失败: " + query.lastError().text());
    }
}


// 删除功能
void StaffManageWidget::onDelete() {
    QList<QTableWidgetItem*> selected = table->selectedItems();
    if (selected.isEmpty()) {
        QMessageBox::warning(this, "提示", "请选择要删除的记录");
        return;
    }

    int row = selected.first()->row();
    QString name = table->item(row, 0)->text();
    QString phone = table->item(row, 2)->text();
    QString roleText = table->item(row, 1)->text();
    int targetRole = (roleText == "物业管理员") ? 0 : 1;

    // 获取被删除记录的id
    int targetId = -1;
    QSqlQuery idQuery(database::instance().getDatabase());
    idQuery.prepare("SELECT id FROM staff WHERE name=:name AND phone=:phone");
    idQuery.bindValue(":name", name);
    idQuery.bindValue(":phone", phone);
    if (!idQuery.exec() || !idQuery.next()) {
        QMessageBox::warning(this, "错误", "无法获取记录信息，删除失败");
        return;
    }
    targetId = idQuery.value("id").toInt();

    // 权限判断：管理员只能删除自己
    bool isSelf = (name == m_currentAdminName);
    if (targetRole == 0 && !isSelf) {
        QMessageBox::critical(this, "无权限", "不可删除其他管理员的记录！");
        return;
    }

    if (QMessageBox::question(this, "确认删除", "确定要删除 " + name + " 的记录吗？") != QMessageBox::Yes) {
        return;
    }

    QSqlDatabase db = database::instance().getDatabase();
    db.transaction();

    // 先删除考勤表
    QSqlQuery attQuery(db);
    attQuery.prepare("DELETE FROM attendance WHERE id=:id");
    attQuery.bindValue(":id", targetId);
    bool success = attQuery.exec();

    // 再删除staff表
    if (success) {
        QSqlQuery query(db);
        query.prepare("DELETE FROM staff WHERE id=:id");
        query.bindValue(":id", targetId);
        success = query.exec();
    }

    if (success) {
        db.commit();
        QMessageBox::information(this, "成功", "记录已删除！");
        refreshTable();
    } else {
        db.rollback();
        QMessageBox::critical(this, "失败", "删除失败: " + db.lastError().text());
    }
}


// 搜索功能
void StaffManageWidget::onSearch() {
    QString keyword = searchEdit->text().trimmed();
    table->clearContents();
    table->setRowCount(0);

    QSqlQuery query(database::instance().getDatabase());

    if (keyword.isEmpty()) {
        if (!query.exec("SELECT * FROM staff")) {
            qCritical() << "查询失败:" << query.lastError().text();
            return;
        }
    } else {
        query.prepare("SELECT * FROM staff WHERE name LIKE :name");
        query.bindValue(":name", "%" + keyword + "%");
        if (!query.exec()) {
            qCritical() << "搜索查询失败:" << query.lastError().text();
            return;
        }
    }

    int row = 0;
    while (query.next()) {
        table->insertRow(row);
        table->setItem(row, 0, new QTableWidgetItem(query.value("name").toString()));

        int role = query.value("role").toInt();
        table->setItem(row, 1, new QTableWidgetItem(role == 0 ? "物业管理员" : "物业工作人员"));

        table->setItem(row, 2, new QTableWidgetItem(query.value("phone").toString()));
        table->setItem(row, 3, new QTableWidgetItem(query.value("status").toInt() == 1 ? "在职" : "离职"));
        row++;
    }
}


// 刷新表格
void StaffManageWidget::refreshTable() {
    table->clearContents();
    table->setRowCount(0);

    QSqlQuery query(database::instance().getDatabase());
    if (!query.exec("SELECT * FROM staff")) {
        qCritical() << "查询staff表失败:" << query.lastError().text();
        return;
    }

    int row = 0;
    while (query.next()) {
        table->insertRow(row);
        table->setItem(row, 0, new QTableWidgetItem(query.value("name").toString()));

        int role = query.value("role").toInt();
        table->setItem(row, 1, new QTableWidgetItem(role == 0 ? "物业管理员" : "物业工作人员"));

        table->setItem(row, 2, new QTableWidgetItem(query.value("phone").toString()));
        table->setItem(row, 3, new QTableWidgetItem(query.value("status").toInt() == 1 ? "在职" : "离职"));

        // 高亮显示当前管理员的记录
        if (query.value("name").toString() == m_currentAdminName) {
            for (int col = 0; col < table->columnCount(); ++col) {
                table->item(row, col)->setBackground(QBrush(QColor(220, 255, 220)));
            }
        }

        row++;
    }
}


// 创建表
void StaffManageWidget::createTables() {
    QSqlQuery query(database::instance().getDatabase());

    if (!query.exec("CREATE TABLE IF NOT EXISTS staff ("
                   "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                   "name TEXT NOT NULL,"
                   "role INTEGER NOT NULL,"
                   "phone TEXT,"
                   "status INTEGER)")) {
        qCritical() << "创建staff表失败:" << query.lastError().text();
    }

    if (!query.exec("CREATE TABLE IF NOT EXISTS attendance ("
                   "id INTEGER PRIMARY KEY,"
                   "name TEXT,"
                   "phone TEXT,"
                   "today INTEGER DEFAULT 0,"
                   "monthly INTEGER DEFAULT 0)")) {
        qCritical() << "创建attendance表失败:" << query.lastError().text();
    }
}
