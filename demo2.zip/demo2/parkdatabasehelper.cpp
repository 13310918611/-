
#include "parkdatabasehelper.h"
#include <QSqlError>
#include <QDebug>

// 静态实例初始化
ParkDatabaseHelper* ParkDatabaseHelper::m_instance = nullptr;

// 获取单例实例
ParkDatabaseHelper* ParkDatabaseHelper::instance()
{
    if (!m_instance) {
        m_instance = new ParkDatabaseHelper();
    }
    return m_instance;
}

// 构造函数
ParkDatabaseHelper::ParkDatabaseHelper(QObject *parent) : QObject(parent)
{
    // 使用唯一连接名，避免与DatabaseAccess冲突
    m_db = QSqlDatabase::addDatabase("QSQLITE", "ParkDatabaseConnection");
}

// 打开指定数据库文件
bool ParkDatabaseHelper::openDB(const QString &dbName)
{
    m_dbName = dbName;

    if (m_db.isOpen()) {
        if (m_db.databaseName() == dbName) {
            return true; // 已连接到目标数据库
        }
        m_db.close(); // 关闭现有连接
    }

    m_db.setDatabaseName(dbName);
    if (!m_db.open()) {
        qDebug() << "ParkDatabaseHelper: 数据库打开失败:" << m_db.lastError().text();
        return false;
    }

    qDebug() << "ParkDatabaseHelper: 成功连接到数据库:" << dbName;
    return true;
}

// 检查数据库是否已连接
bool ParkDatabaseHelper::isConnected() const
{
    return m_db.isOpen();
}

// 获取最后一个错误信息
QString ParkDatabaseHelper::lastError() const
{
    return m_db.lastError().text();
}

// 获取数据库实例
QSqlDatabase ParkDatabaseHelper::getDatabase()
{
    return m_db;
}

// 执行SQL查询
bool ParkDatabaseHelper::executeQuery(const QString &sql, QSqlQuery &query, QString &errorMsg)
{
    if (!m_db.isOpen()) {
        if (!openDB(m_dbName)) {
            errorMsg = "数据库未连接: " + lastError();
            return false;
        }
    }

    query = QSqlQuery(m_db);
    if (!query.exec(sql)) {
        errorMsg = "SQL执行失败: " + query.lastError().text();
        qDebug() << errorMsg << "\nSQL:" << sql;
        return false;
    }
    return true;
}
bool ParkDatabaseHelper::executePreparedQuery(const QString &sql,
                                              const QMap<QString, QVariant> &bindValues,
                                              QSqlQuery &query,
                                              QString &errorMsg)
{
    if (!m_db.isOpen()) {
        if (!openDB(m_dbName)) {
            errorMsg = "数据库未连接: " + lastError();
            return false;
        }
    }

    query = QSqlQuery(m_db);
    if (!query.prepare(sql)) {
        errorMsg = "SQL准备失败: " + query.lastError().text();
        qDebug() << errorMsg << "\nSQL:" << sql;
        return false;
    }

    // 绑定参数
    QMapIterator<QString, QVariant> it(bindValues);
    while (it.hasNext()) {
        it.next();
        query.bindValue(it.key(), it.value());
    }

    if (!query.exec()) {
        errorMsg = "SQL执行失败: " + query.lastError().text();
        qDebug() << errorMsg << "\nSQL:" << sql;
        return false;
    }

    return true;
}
