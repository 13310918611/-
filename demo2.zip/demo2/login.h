#ifndef LOGIN_H
#define LOGIN_H

#include <QDialog>
#include <QLineEdit>
#include <QPushButton>
#include <QComboBox>
#include "ui_login.h"
#include "database.h"

class Login : public QDialog
{
    Q_OBJECT

public:
    explicit Login(QWidget *parent = nullptr);
    ~Login();
    int getUserRole() const;
    int getUserId() const;
    int getSelectedRole() const;
    QString getUsername() const;
private slots:
    void onLoginClicked();
    void onRegisterClicked();
    void onExitClicked();

signals:
    void loginSuccess(int userId, int role);

private:
    Ui::Login *ui;
    database db;
    int m_currentRole;
    int m_currentId;
    bool validateUser(const QString& username, const QString& password, int& outUserId, int& outRole);
    QString m_currentUsername;

};

#endif // LOGIN_H
