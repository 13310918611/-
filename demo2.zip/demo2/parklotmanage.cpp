#include "parklotmanage.h"
#include "database.h"
#include "parkdatabasehelper.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QMessageBox>
#include <QSqlQuery>
#include <QPushButton>
#include <QDialog>
#include <QTableWidget>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QComboBox>
#include <QLabel>
#include <QLineEdit>
#include <QDebug>

ParkLotManage::ParkLotManage(QWidget *parent) : QWidget(parent) {
    setupUI();
    checkCancelLeaseNotifications();
    refreshTable();
}

ParkLotManage::~ParkLotManage() = default;

void ParkLotManage::setupUI() {
    table = new QTableWidget(this);
    table->setColumnCount(4);
    table->setHorizontalHeaderLabels({"车位编号", "业主车牌", "处理状态", "管理"});
    table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    table->setEditTriggers(QAbstractItemView::NoEditTriggers);

    // 搜索区域
    searchEdit = new QLineEdit(this);
    searchEdit->setPlaceholderText("输入车位编号或车牌查询");
    statusCombo = new QComboBox(this);
    statusCombo->addItem("全部状态", -1);
    statusCombo->addItem("未承租", 0);
    statusCombo->addItem("公示中", 1);
    statusCombo->addItem("已承租", 2);

    btnSearch = new QPushButton("查询", this);
    btnReset = new QPushButton("重置", this);
    connect(btnSearch, &QPushButton::clicked, this, &ParkLotManage::onSearch);
    connect(btnReset, &QPushButton::clicked, this, &ParkLotManage::onReset);

    QHBoxLayout *operateLayout = new QHBoxLayout;
    QPushButton *btnAddParkLot = new QPushButton("录入车位", this);
    connect(btnAddParkLot, &QPushButton::clicked, this, &ParkLotManage::onAddParkLot);
    operateLayout->addWidget(btnAddParkLot);
    operateLayout->addStretch(); // 右对齐

    // 主布局
    QHBoxLayout *searchLayout = new QHBoxLayout;
    searchLayout->addWidget(searchEdit);
    searchLayout->addWidget(statusCombo);
    searchLayout->addWidget(btnSearch);
    searchLayout->addWidget(btnReset);

    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->addLayout(operateLayout);    // 新增操作按钮
    mainLayout->addLayout(searchLayout);
    mainLayout->addWidget(table);
    setLayout(mainLayout);
}

void ParkLotManage::refreshTable() {
    table->setRowCount(0);

    QSqlDatabase db = database::instance().getDatabase();
    if (!db.isOpen()) {
        if (!database::instance().openDB("smart_upc.db")) {
            QMessageBox::critical(this, "连接失败", "数据库无法打开：" + database::instance().lastError());
            return;
        }
        db = database::instance().getDatabase();
    }

    // 主查询：获取车位信息
    QSqlQuery query(db);
    QString sql = "SELECT parklot_id, license_number, status FROM parklot WHERE 1=1";
    QString keyword = searchEdit->text().trimmed();
    int status = statusCombo->currentData().toInt();

    if (!keyword.isEmpty()) {
        sql += " AND (parklot_id LIKE :keyword OR license_number LIKE :keyword)";
    }
    if (status != -1) {
        sql += " AND status = :status";
    }

    if (!query.prepare(sql)) {
        QMessageBox::critical(this, "准备失败", "SQL语句错误：" + query.lastError().text());
        return;
    }

    if (!keyword.isEmpty()) {
        query.bindValue(":keyword", "%" + keyword + "%");
    }
    if (status != -1) {
        query.bindValue(":status", status);
    }

    if (!query.exec()) {
        QMessageBox::critical(this, "执行失败", "查询错误：" + query.lastError().text());
        return;
    }

    // 填充表格
    while (query.next()) {
        int row = table->rowCount();
        table->insertRow(row);
        QString parklotId = query.value("parklot_id").toString();
        QString license = query.value("license_number").toString();
        int status = query.value("status").toInt();

        QString statusText = status == 0 ? "未承租" :
                            status == 1 ? "公示中" :
                            "已承租";

        int applicationCount = 0;
        if (status == 1) { // 只对公示中车位查询申请
            QSqlQuery appQuery(db);
            appQuery.prepare("SELECT COUNT(*) FROM parking_application "
                            "WHERE parklot_id = :id AND status = 0"); // 0=待审核
            appQuery.bindValue(":id", parklotId);
            if (appQuery.exec() && appQuery.next()) {
                applicationCount = appQuery.value(0).toInt();
            }
        }

        // 创建表格项并设置文本
        QTableWidgetItem *idItem = new QTableWidgetItem(parklotId);
        QTableWidgetItem *licenseItem = new QTableWidgetItem(license.isEmpty() ? "无" : license);
        QTableWidgetItem *statusItem = new QTableWidgetItem(statusText);

        if (applicationCount > 0) {
            // 设置背景色为浅黄色，作出区分
            QBrush highlightBrush(QColor(255, 255, 200));
            idItem->setBackground(highlightBrush);
            licenseItem->setBackground(highlightBrush);
            statusItem->setBackground(highlightBrush);

            // 在状态文本后添加申请数量提示
            statusItem->setText(statusText + QString(" (%1个申请)").arg(applicationCount));
        }

        table->setItem(row, 0, idItem);
        table->setItem(row, 1, licenseItem);
        table->setItem(row, 2, statusItem);

        QPushButton *btn = new QPushButton(this);
        btn->setProperty("parklotId", parklotId);
        btn->setProperty("status", status);

        if (status == 0) {
            btn->setText("管理");
            connect(btn, &QPushButton::clicked, this, &ParkLotManage::onManageUnpublished);
        } else if (status == 1) {
            btn->setText("管理公示");
            connect(btn, &QPushButton::clicked, this, &ParkLotManage::onManagePublicize);
        } else if (status == 2) {
            // 已承租状态：不显示"取消承租"按钮，改为禁用的提示按钮
            btn->setText("已承租");
            btn->setEnabled(false);
            btn->setStyleSheet("background-color: #f0f0f0; color: #888;");
        }

        table->setCellWidget(row, 3, btn);
    }
}

void ParkLotManage::onAddParkLot() {
    QDialog dialog(this);
    dialog.setWindowTitle("录入新车位");
    dialog.setMinimumWidth(300);

    QFormLayout *formLayout = new QFormLayout(&dialog);
    QLineEdit *parklotIdEdit = new QLineEdit(&dialog);
    parklotIdEdit->setPlaceholderText("请输入唯一车位编号");
    formLayout->addRow("车位编号*", parklotIdEdit);

    QDialogButtonBox *buttonBox = new QDialogButtonBox(
        QDialogButtonBox::Ok | QDialogButtonBox::Cancel, &dialog
    );
    formLayout->addRow(buttonBox);
    connect(buttonBox, &QDialogButtonBox::accepted, &dialog, &QDialog::accept);
    connect(buttonBox, &QDialogButtonBox::rejected, &dialog, &QDialog::reject);

    if (dialog.exec() != QDialog::Accepted) return;

    QString parklotId = parklotIdEdit->text().trimmed();
    if (parklotId.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "车位编号不能为空！");
        return;
    }

    // 检查车位编号是否已存在
    QSqlQuery query(database::instance().getDatabase());
    query.prepare("SELECT parklot_id FROM parklot WHERE parklot_id = :id");
    query.bindValue(":id", parklotId);
    if (query.exec() && query.next()) {
        QMessageBox::warning(this, "错误", "该车位编号已存在！");
        return;
    }

    // 插入新车位（默认状态：未承租）
    query.prepare("INSERT INTO parklot (parklot_id, license_number, status) "
                 "VALUES (:id, NULL, 0)");
    query.bindValue(":id", parklotId);

    if (query.exec()) {
        QMessageBox::information(this, "成功", "车位录入成功！");
        refreshTable();
    } else {
        QMessageBox::critical(this, "失败", "录入失败：" + query.lastError().text());
    }
}

void ParkLotManage::onManageUnpublished() {
    QPushButton *btn = qobject_cast<QPushButton*>(sender());
    if (!btn) return;

    QString parklotId = btn->property("parklotId").toString();
    if (parklotId.isEmpty()) return;

    QDialog dialog(this);
    dialog.setWindowTitle("管理未公示车位");
    dialog.setMinimumWidth(300);

    QVBoxLayout *layout = new QVBoxLayout(&dialog);
    layout->addWidget(new QLabel(QString("车位 %1 操作选择：").arg(parklotId)));

    QDialogButtonBox *buttonBox = new QDialogButtonBox(QDialogButtonBox::Cancel, &dialog);
    QPushButton *setPublicBtn = new QPushButton("设为公示", &dialog);
    QPushButton *deleteBtn = new QPushButton("删除车位", &dialog);
    buttonBox->addButton(setPublicBtn, QDialogButtonBox::ActionRole);
    buttonBox->addButton(deleteBtn, QDialogButtonBox::ActionRole);
    layout->addWidget(buttonBox);

    // 设为公示
    connect(setPublicBtn, &QPushButton::clicked, [&, parklotId]() {
        QSqlQuery query(database::instance().getDatabase());
        query.prepare("UPDATE parklot SET status = 1 WHERE parklot_id = :id");
        query.bindValue(":id", parklotId);
        if (query.exec()) {
            QMessageBox::information(&dialog, "成功", "车位已设为公示中");
            dialog.accept();
            refreshTable();
        } else {
            QMessageBox::critical(&dialog, "失败", "操作失败：" + query.lastError().text());
        }
    });

    // 删除未公示车位
    connect(deleteBtn, &QPushButton::clicked, [&, parklotId]() {
        if (QMessageBox::question(&dialog, "确认删除",
            QString("确定要删除车位 %1 吗？\n（仅未公示车位可删除）").arg(parklotId),
            QMessageBox::Yes | QMessageBox::No) != QMessageBox::Yes) {
            return;
        }

        QSqlQuery query(database::instance().getDatabase());
        query.prepare("DELETE FROM parklot WHERE parklot_id = :id AND status = 0");
        query.bindValue(":id", parklotId);

        if (query.exec()) {
            if (query.numRowsAffected() > 0) {
                QMessageBox::information(&dialog, "成功", "车位已删除");
                dialog.accept();
                refreshTable();
            } else {
                QMessageBox::warning(&dialog, "失败", "删除失败（仅未公示车位可删除）");
            }
        } else {
            QMessageBox::critical(&dialog, "失败", "删除失败：" + query.lastError().text());
        }
    });

    connect(buttonBox, &QDialogButtonBox::rejected, &dialog, &QDialog::reject);
    dialog.exec();
}

void ParkLotManage::onSetPublic() {

}

void ParkLotManage::onCancelPublic() {
    QMessageBox::information(this, "提示", "此功能已整合到“管理公示”中");
}

void ParkLotManage::onManagePublicize() {
    QPushButton *btn = qobject_cast<QPushButton*>(sender());
    if (!btn) return;

    QString parklotId = btn->property("parklotId").toString();

    QDialog dialog(this);
    dialog.setWindowTitle("管理公示 - 车位 " + parklotId);
    dialog.setMinimumWidth(500);

    QVBoxLayout *mainLayout = new QVBoxLayout(&dialog);

    // 显示申请列表
    QTableWidget *applicantTable = new QTableWidget(&dialog);
    applicantTable->setColumnCount(3);
    applicantTable->setHorizontalHeaderLabels({"申请车牌号", "申请时间", "状态"});
    applicantTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    QSqlDatabase db = database::instance().getDatabase();
    QSqlQuery query(db);
    query.prepare("SELECT license_plate, apply_time, status FROM parking_application "
                 "WHERE parklot_id = :id AND status = 0");
    query.bindValue(":id", parklotId);

    if (query.exec()) {
        int row = 0;
        while (query.next()) {
            applicantTable->insertRow(row);
            applicantTable->setItem(row, 0, new QTableWidgetItem(query.value("license_plate").toString()));
            applicantTable->setItem(row, 1, new QTableWidgetItem(query.value("apply_time").toString()));
            applicantTable->setItem(row, 2, new QTableWidgetItem("待审核"));
            row++;
        }
    } else {
        QMessageBox::warning(&dialog, "查询失败", "获取申请记录失败: " + query.lastError().text());
    }
    mainLayout->addWidget(applicantTable);

    // 选择车牌号的下拉框
    QFormLayout *formLayout = new QFormLayout();
    QComboBox *licenseCombo = new QComboBox(&dialog);
    licenseCombo->addItem("请选择车牌号...", "");

    QSqlQuery licenseQuery(db);
    licenseQuery.prepare("SELECT DISTINCT license_plate FROM parking_application "
                        "WHERE parklot_id = :id AND status = 0");
    licenseQuery.bindValue(":id", parklotId);

    if (licenseQuery.exec()) {
        while (licenseQuery.next()) {
            QString license = licenseQuery.value("license_plate").toString();
            licenseCombo->addItem(license, license);
        }
    }
    formLayout->addRow("选择车牌号:", licenseCombo);
    mainLayout->addLayout(formLayout);

    // 按钮区域
    QDialogButtonBox *buttonBox = new QDialogButtonBox(
        QDialogButtonBox::Ok | QDialogButtonBox::Cancel, Qt::Horizontal, &dialog
    );
    QPushButton *cancelPublicizeBtn = new QPushButton("取消公示", &dialog);
    buttonBox->addButton(cancelPublicizeBtn, QDialogButtonBox::ActionRole);
    mainLayout->addWidget(buttonBox);

    // 连接信号
    connect(buttonBox, &QDialogButtonBox::accepted, &dialog, &QDialog::accept);
    connect(buttonBox, &QDialogButtonBox::rejected, &dialog, &QDialog::reject);

    connect(cancelPublicizeBtn, &QPushButton::clicked, [&]() {
        if (QMessageBox::question(&dialog, "确认取消", "确定要取消公示吗？",
            QMessageBox::Yes | QMessageBox::No) == QMessageBox::Yes) {
            QSqlQuery updateQuery(db);
            updateQuery.prepare("UPDATE parklot SET status = 0 WHERE parklot_id = :id");
            updateQuery.bindValue(":id", parklotId);
            if (updateQuery.exec()) {
                QMessageBox::information(&dialog, "成功", "公示已取消");
                dialog.reject(); // 替换 dialog.accept()
                refreshTable(); // 手动刷新表格（因为对话框已关闭）
            } else {
                QMessageBox::critical(&dialog, "错误", "操作失败: " + updateQuery.lastError().text());
            }
        }
    });

    // 处理审核结果
    if (dialog.exec() == QDialog::Accepted) {
        QString licenseNumber = licenseCombo->currentData().toString();
        if (licenseNumber.isEmpty()) {
            QMessageBox::warning(this, "提示", "请选择车牌号");
            return;
        }

        db.transaction();

        // 更新车位状态
        QSqlQuery leaseQuery(db);
        leaseQuery.prepare("UPDATE parklot SET status = 2, license_number = :license WHERE parklot_id = :id");
        leaseQuery.bindValue(":license", licenseNumber);
        leaseQuery.bindValue(":id", parklotId);

        // 批准选中申请
        QSqlQuery updateAppQuery(db);
        updateAppQuery.prepare("UPDATE parking_application SET status = 1 "
                             "WHERE parklot_id = :id AND license_plate = :license");
        updateAppQuery.bindValue(":id", parklotId);
        updateAppQuery.bindValue(":license", licenseNumber);

        // 拒绝其他申请
        QSqlQuery rejectAppQuery(db);
        rejectAppQuery.prepare("UPDATE parking_application SET status = 2 "
                             "WHERE parklot_id = :id AND license_plate != :license");
        rejectAppQuery.bindValue(":id", parklotId);
        rejectAppQuery.bindValue(":license", licenseNumber);

        bool success = leaseQuery.exec() && updateAppQuery.exec() && rejectAppQuery.exec();
        if (success) {
            db.commit();
            QMessageBox::information(this, "成功", "车位已出租");
        } else {
            db.rollback();
            QMessageBox::critical(this, "错误", "操作失败: " + db.lastError().text());
        }
        refreshTable();
    }
}

void ParkLotManage::onSearch() { refreshTable(); }
void ParkLotManage::onReset() {
    searchEdit->clear();
    statusCombo->setCurrentIndex(0);
    refreshTable();
}

// 检查业主取消承租的通知
void ParkLotManage::checkCancelLeaseNotifications()
{
    ParkDatabaseHelper *dbHelper = ParkDatabaseHelper::instance();
    if (!dbHelper->openDB("smart_upc.db")) return;

    // 查询未通知的业主取消承租记录（action_type=3，is_notified=0）
    QString sql = "SELECT id, parklot_id FROM parking_log "
                 "WHERE action_type = 3 AND is_notified = 0";

    QSqlQuery query;
    QString errorMsg;
    if (!dbHelper->executeQuery(sql, query, errorMsg)) {
        qDebug() << "查询取消承租通知失败:" << errorMsg;
        return;
    }

    QString messages;
    QList<int> logIds; // 记录需要标记为已通知的日志ID

    while (query.next()) {
        int logId = query.value("id").toInt();
        QString parklotId = query.value("parklot_id").toString();

        // 检查是否已通知过（避免重复弹窗）
        if (isStaffNotified(logId)) continue;

        messages += QString("业主已取消车位 %1 的承租权，请及时处理\n").arg(parklotId);
        logIds.append(logId);
    }

    // 显示通知
    if (!messages.isEmpty()) {
        QMessageBox::information(this, "新通知", messages);
        // 标记为已通知
        foreach(int logId, logIds) {
            markStaffNotified(logId);
        }
    }
}

// 检查工作人员是否已查看该通知
bool ParkLotManage::isStaffNotified(int logId)
{
    ParkDatabaseHelper *dbHelper = ParkDatabaseHelper::instance();
    QString sql = QString("SELECT id FROM parking_log WHERE id = %1 AND is_notified = 1").arg(logId);
    QSqlQuery query;
    QString errorMsg;
    if (dbHelper->executeQuery(sql, query, errorMsg) && query.next()) {
        return true; // 已查看
    }
    return false; // 未查看
}

// 标记通知为已查看（更新is_notified=1）
void ParkLotManage::markStaffNotified(int logId)
{
    ParkDatabaseHelper *dbHelper = ParkDatabaseHelper::instance();
    QString sql = QString("UPDATE parking_log SET is_notified = 1 WHERE id = %1").arg(logId);
    QSqlQuery query;
    QString errorMsg;
    dbHelper->executeQuery(sql, query, errorMsg);
}

// 在切换标签页或刷新时重新检查
void ParkLotManage::onTabChanged(int index)
{
    if (index == 0) { // 假设0是车位管理标签页
        checkCancelLeaseNotifications();
    }
}
