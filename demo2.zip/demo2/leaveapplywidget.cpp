#include "leaveapplywidget.h"
#include "ui_leaveapplywidget.h"
#include <QMessageBox>
#include <QSqlError>
#include <QDateTime>
#include <QDebug>
#include "dbmanager.h"

LeaveApplyWidget::LeaveApplyWidget(int staffId, const QString& staffName, QWidget *parent)
    : QWidget(parent),
      ui(new Ui::LeaveApplyWidget),
      dbManager(DBManager::instance()),
      m_staffId(staffId),
      m_staffName(staffName)
{
    ui->setupUi(this);

    // 使用命名连接打开数据库
    if (!dbManager.openDB("smart_upc.db", "leave_apply_conn")) {
        QMessageBox::critical(this, "错误", "数据库打开失败: " + dbManager.lastError());
        return;
    }

    connect(ui->pushButton_submit, &QPushButton::clicked, this, &LeaveApplyWidget::onSubmitApply);

    ui->dateEdit_start->setDate(QDate::currentDate());
    ui->dateEdit_end->setDate(QDate::currentDate().addDays(1));
    refreshTable();
}

LeaveApplyWidget::~LeaveApplyWidget()
{
    delete ui;
}

void LeaveApplyWidget::refreshTable()
{
    // 设置表格列数和表头
    ui->tableWidget->setColumnCount(6);
    ui->tableWidget->setHorizontalHeaderLabels({"员工姓名", "开始日期", "结束日期", "原因", "状态", "审批人"});
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);

    // 清空表格内容
    ui->tableWidget->clearContents();
    ui->tableWidget->setRowCount(0);

    // 使用命名连接执行查询
    QSqlQuery query(dbManager.getDatabase("leave_apply_conn"));
    query.prepare("SELECT id, start_date, end_date, reason, status, approver_name "
                 "FROM leaves "
                 "WHERE staff_id = :staff_id "
                 "ORDER BY id DESC");
    query.bindValue(":staff_id", m_staffId);

    if (query.exec()) {
        qDebug() << "查询成功，结果行数:" << query.size();

        while (query.next()) {
            int row = ui->tableWidget->rowCount();
            ui->tableWidget->insertRow(row);

            // 设置员工姓名（从成员变量获取，确保不为空）
            QTableWidgetItem* nameItem = new QTableWidgetItem(m_staffName);
            ui->tableWidget->setItem(row, 0, nameItem);

            // 设置其他列数据
            ui->tableWidget->setItem(row, 1, new QTableWidgetItem(query.value("start_date").toString()));
            ui->tableWidget->setItem(row, 2, new QTableWidgetItem(query.value("end_date").toString()));
            ui->tableWidget->setItem(row, 3, new QTableWidgetItem(query.value("reason").toString()));

            // 设置状态文本
            int status = query.value("status").toInt();
            QString statusText;
            switch (status) {
                case 0: statusText = "待审批"; break;
                case 1: statusText = "已批准"; break;
                case 2: statusText = "已拒绝"; break;
                default: statusText = "未知";
            }
            ui->tableWidget->setItem(row, 4, new QTableWidgetItem(statusText));

            // 设置审批人姓名
            QString approver = query.value("approver_name").toString();
            ui->tableWidget->setItem(row, 5, new QTableWidgetItem(approver.isEmpty() ? "未审批" : approver));
        }
    } else {
        QMessageBox::warning(this, "查询失败", "加载请假记录失败：" + query.lastError().text());
        qDebug() << "查询错误:" << query.lastError().text();
    }
}

void LeaveApplyWidget::onSubmitApply()
{
    QDate startDate = ui->dateEdit_start->date();
    QDate endDate = ui->dateEdit_end->date();
    QString reason = ui->lineEdit_reason->text().trimmed();

    // 输入验证
    if (startDate > endDate) {
        QMessageBox::warning(this, "输入错误", "开始日期不能晚于结束日期！");
        return;
    }

    if (startDate < QDate::currentDate()) {
        QMessageBox::warning(this, "输入错误", "开始日期不能早于当前日期！");
        return;
    }

    if (reason.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "请填写请假原因！");
        return;
    }

    // 使用命名连接执行插入
    QSqlQuery query(dbManager.getDatabase("leave_apply_conn"));
    query.prepare("INSERT INTO leaves (staff_id, staff_name, start_date, end_date, reason, "
                  "status, approver_name, create_time) "
                  "VALUES (:staff_id, :staff_name, :start, :end, :reason, "
                  ":status, :approver_name, :create_time)");

    query.bindValue(":staff_id", m_staffId);
    query.bindValue(":staff_name", m_staffName);
    query.bindValue(":start", startDate.toString("yyyy-MM-dd"));
    query.bindValue(":end", endDate.toString("yyyy-MM-dd"));
    query.bindValue(":reason", reason);
    query.bindValue(":status", 0); // 0: 待审批
    query.bindValue(":approver_name", ""); // 初始为空
    query.bindValue(":create_time", QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss"));

    if (query.exec()) {
        QMessageBox::information(this, "提交成功", "请假申请已提交，等待审批！");

        // 重置表单
        ui->dateEdit_start->setDate(QDate::currentDate());
        ui->dateEdit_end->setDate(QDate::currentDate().addDays(1));
        ui->lineEdit_reason->clear();

        // 刷新表格
        refreshTable();
    } else {
        QMessageBox::critical(this, "提交失败", "数据库操作失败：" + query.lastError().text());
        qDebug() << "插入错误:" << query.lastError().text();
    }
}
