#ifndef OWNERWINDOW_H
#define OWNERWINDOW_H

#include <QMainWindow>
#include <QStackedWidget>
#include <QLabel>
#include <QPushButton>
#include <QLineEdit>
#include <QTextEdit>
#include <QTableWidget>
#include "database.h"
#include "announcementlistwidget.h"

QT_BEGIN_NAMESPACE
namespace Ui { class OwnerWindow; }
QT_END_NAMESPACE

// 前向声明
class OwnerInfoWidget;       // 个人信息
class RepairProgressWidget;  // 维修进度
class ParkingInfoWidget;     // 停车信息
class RepairRequestWidget;   // 报修请求
class PaymentWidget;         // 费用缴纳
class AnnouncementListWidget; //公告查看
class RepairProgressWidget; //报修进度

class OwnerWindow : public QMainWindow
{
    Q_OBJECT

public:
    OwnerWindow(int userId, const QString& ownerName, QWidget *parent = nullptr);
    ~OwnerWindow();

private slots:
    void showOwnerInfo();
    void showRepairProgress();
    void showParkingInfo();
    void showRepairRequest();
    void showPayment();
    void onInfoUpdated();
    void showAnnouncements();

private:
    Ui::OwnerWindow *ui;
    int m_userID;
    database& db = database::instance();
    QStackedWidget *stackedWidget;
    OwnerInfoWidget *ownerInfoWidget;
    RepairProgressWidget *repairProgressWidget;
    ParkingInfoWidget *parkingInfoWidget;
    RepairRequestWidget *repairRequestWidget;
    PaymentWidget *paymentWidget;
    AnnouncementListWidget* announcementWidget;
    bool ensureDatabaseConnection();
    void setupMenus(); // 初始化菜单
    QString m_ownerName;
    bool checkInfoCompletion();
};
#endif // OWNERWINDOW_H

