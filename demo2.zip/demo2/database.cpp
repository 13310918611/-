#include "database.h"
#include <QSqlError>
#include <QSqlQuery>
#include <QDebug>
#include <QTimer>
#include <QCoreApplication>
#include <QThread>

database::database() : m_connectionName(QString()) // 初始化连接名为空
{
}

database::~database()
{
    if (m_db.isOpen()) {
        m_db.close(); // 先关闭连接
        if (!m_connectionName.isEmpty()) {
            // 确保所有使用该连接的查询已销毁
            QCoreApplication::processEvents(QEventLoop::AllEvents, 200);
            QSqlDatabase::removeDatabase(m_connectionName);
        }
    }
}

bool database::openDB(const QString& dbPath) {
    // 如果已经打开，先关闭旧连接
    if (m_db.isOpen()) {
        m_db.close();
        if (!m_connectionName.isEmpty()) {
            QSqlDatabase::removeDatabase(m_connectionName);
        }
    }

    static int connectionCounter = 0;
    m_connectionName = QString("db_conn_%1_%2").arg(quintptr(this), 0, 16).arg(++connectionCounter);

    m_db = QSqlDatabase::addDatabase("QSQLITE", m_connectionName);
    m_db.setDatabaseName(dbPath);

    if (!m_db.open()) {
        qCritical() << "Failed to open database:" << m_db.lastError().text();
        m_connectionName.clear(); // 打开失败时清空连接名
        return false;
    }

    // 创建所有表格
    QSqlQuery query(m_db);
    bool success = true;

    // 创建 account 表格
    if (!query.exec("CREATE TABLE IF NOT EXISTS account ("
                   "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                   "username TEXT UNIQUE, "
                   "password TEXT, "
                   "role INTEGER DEFAULT 0)")) {
        qCritical() << "Failed to create account table:" << query.lastError().text();
        success = false;
    }

    // 创建 leaves 表格
    if (success && !query.exec("CREATE TABLE IF NOT EXISTS leaves ("
                              "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                              "staff_id INTEGER, "
                              "start_date TEXT, "
                              "end_date TEXT, "
                              "reason TEXT, "
                              "status INTEGER DEFAULT 0, "
                              "approver_id INTEGER, "
                              "approve_time TEXT)")) {
        qCritical() << "Failed to create leaves table:" << query.lastError().text();
        success = false;
    }

    // 创建 attendance 表格
    if (success && !query.exec(
        "CREATE TABLE IF NOT EXISTS attendance ("
        "id INTEGER PRIMARY KEY NOT NULL, "
        "name TEXT, "
        "phone TEXT, "
        "today INTEGER, "
        "monthly INTEGER"
        ")"
    )) {
        qCritical() << "Failed to create attendance table:" << query.lastError().text();
        success = false;
    }

    // 创建 config 表格
    if (success && !query.exec(
        "CREATE TABLE IF NOT EXISTS config ("
        "key TEXT PRIMARY KEY,"
        "value TEXT"
        ")"
    )) {
        qCritical() << "Failed to create config table:" << query.lastError().text();
        success = false;
    }

    // 创建 announcements 表格
    if (success && !query.exec(
        "CREATE TABLE IF NOT EXISTS announcements ("
        "id INTEGER PRIMARY KEY,"
        "title TEXT NOT NULL,"
        "content TEXT NOT NULL,"
        "publish_time DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,"
        "publisher_name TEXT NOT NULL"
        ")"
    )) {
        qCritical() << "Failed to create announcements table:" << query.lastError().text();
        success = false;
    }

    // 创建 parking_log 表格
    if (success && !query.exec(
        "CREATE TABLE IF NOT EXISTS parking_log ("
        "id INTEGER PRIMARY KEY,"
        "parklot_id INTEGER NOT NULL,"
        "action_type INTEGER NOT NULL,"
        "action_time DATETIME DEFAULT CURRENT_TIMESTAMP,"
        "is_notified INTEGER DEFAULT 0"
        ")"
    )) {
        qCritical() << "Failed to create parking_log table:" << query.lastError().text();
        success = false;
    }

    // 创建 payment_records 表格
    if (success && !query.exec(
        "CREATE TABLE IF NOT EXISTS payment_records ("
        "id INTEGER PRIMARY KEY,"
        "user_id INTEGER NOT NULL,"
        "amount DECIMAL(10, 2) NOT NULL,"
        "reason TEXT NOT NULL,"
        "is_paid BOOLEAN DEFAULT 0,"
        "payment_date DATETIME,"
        "create_time DATETIME DEFAULT CURRENT_TIMESTAMP"
        ")"
    )) {
        qCritical() << "Failed to create payment_records table:" << query.lastError().text();
        success = false;
    }

    // 创建 task 表格
    if (success && !query.exec(
        "CREATE TABLE IF NOT EXISTS task ("
        "id INTEGER PRIMARY KEY,"
        "address TEXT,"
        "situation TEXT,"
        "finishedOrNot INTEGER,"
        "staffFix TEXT,"
        "rating INTEGER,"
        "feedback TEXT,"
        "feedback_time DATETIME"
        ")"
    )) {
        qCritical() << "Failed to create task table:" << query.lastError().text();
        success = false;
    }

    // 创建 users 表格（由于 parklot 表依赖该表，确保在 parklot 之前创建）
    if (success && !query.exec(
        "CREATE TABLE IF NOT EXISTS users ("
        "user_id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "username TEXT NOT NULL UNIQUE,"
        "password TEXT NOT NULL,"
        "role INTEGER NOT NULL,"
        "name TEXT,"
        "phone TEXT,"
        "create_time DATETIME DEFAULT CURRENT_TIMESTAMP"
        ")"
    )) {
        qCritical() << "Failed to create users table:" << query.lastError().text();
        success = false;
    }

    // 创建 parklot 表格
    if (success && !query.exec(
        "CREATE TABLE IF NOT EXISTS parklot ("
        "parklot_id TEXT PRIMARY KEY,"
        "status INTEGER NOT NULL DEFAULT 0,"
        "owner_id INTEGER,"
        "license_number TEXT,"
        "lease_start DATE,"
        "lease_end DATE,"
        "create_time DATETIME DEFAULT CURRENT_TIMESTAMP,"
        "FOREIGN KEY (owner_id) REFERENCES users(user_id)"
        ")"
    )) {
        qCritical() << "Failed to create parklot table:" << query.lastError().text();
        success = false;
    }

    // 创建 parking_application 表格
    if (success && !query.exec(
        "CREATE TABLE IF NOT EXISTS parking_application ("
        "application_id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "parklot_id TEXT NOT NULL,"
        "owner_id INTEGER NOT NULL,"
        "license_plate TEXT NOT NULL,"
        "apply_time DATETIME NOT NULL,"
        "status INTEGER NOT NULL DEFAULT 0,"
        "handler_id INTEGER,"
        "handle_time DATETIME,"
        "handle_comment TEXT,"
        "FOREIGN KEY (parklot_id) REFERENCES parklot(parklot_id),"
        "FOREIGN KEY (owner_id) REFERENCES users(user_id),"
        "FOREIGN KEY (handler_id) REFERENCES users(user_id)"
        ")"
    )) {
        qCritical() << "Failed to create parking_application table:" << query.lastError().text();
        success = false;
    }

    // 创建 owner_info 表格
    if (success && !query.exec(
        "CREATE TABLE IF NOT EXISTS owner_info ("
        "user_id INTEGER PRIMARY KEY, "
        "phone TEXT NOT NULL, "
        "license_plate TEXT NOT NULL, "
        "building TEXT NOT NULL, "
        "room TEXT NOT NULL, "
        "family_members TEXT, "
        "create_time DATETIME DEFAULT CURRENT_TIMESTAMP, "
        "update_time DATETIME)"
    )) {
        qCritical() << "Failed to create owner_info table:" << query.lastError().text();
        success = false;
    }

    // 创建 staff 表格
    if (success && !query.exec(
        "CREATE TABLE IF NOT EXISTS staff ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "name TEXT NOT NULL,"
        "role INTEGER NOT NULL,"
        "phone TEXT,"
        "status INTEGER)"
    )) {
        qCritical() << "Failed to create staff table:" << query.lastError().text();
        success = false;
    }

    if (!success) {
        m_db.close();
        QSqlDatabase::removeDatabase(m_connectionName);
        m_connectionName.clear();
    } else {
        qDebug() << "Database opened and initialized successfully:" << dbPath;
    }

    return success;
}

bool database::addUser(const QString& username, const QString& password, int role) {
    QSqlQuery query(m_db);
    query.prepare("INSERT INTO account (username, password, role) "
                 "VALUES (:username, :password, :role)");
    query.bindValue(":username", username);
    query.bindValue(":password", password);
    query.bindValue(":role", role);

    if (!query.exec()) {
        qCritical() << "Add user failed:" << query.lastError().text();
        return false;
    }
    return query.numRowsAffected() > 0; // 确认确实插入了行
}

// 返回bool并通过输出参数返回查询结果
bool database::getUserByUsername(const QString& username, QSqlQuery& outQuery) {
    outQuery = QSqlQuery(m_db);
    outQuery.prepare("SELECT id, username, password, role FROM account WHERE username = :username");
    outQuery.bindValue(":username", username);

    if (!outQuery.exec()) {
        qCritical() << "Query error:" << outQuery.lastError().text();
        return false;
    }

    //确保查询有结果
    return outQuery.next();
}

// 返回bool并通过输出参数返回查询结果
bool database::query(const QString& sql, QSqlQuery& outQuery) {
    outQuery = QSqlQuery(m_db);
    if (!outQuery.exec(sql)) {
        qCritical() << "Query failed:" << outQuery.lastError().text();
        return false;
    }
    return true;
}
