#include "dailycheckin.h"
#include <QMessageBox>
#include <QSqlError>
#include <QDebug>
#include <QVBoxLayout>
#include <QSettings>
#include <QDate>

DailyCheckIn::DailyCheckIn(const QString& staffName, QWidget *parent)
    : QWidget(parent), m_staffName(staffName), m_statusLabel(nullptr),
      m_monthlyLabel(nullptr), m_checkinBtn(nullptr), m_errorMsg(""),
      m_lastCheckedDate(QDate::currentDate())
{
    // 初始化UI组件
    m_statusLabel = new QLabel("加载中...", this);
    m_statusLabel->setStyleSheet("font-size: 18px; font-weight: bold;");

    m_monthlyLabel = new QLabel("", this);
    m_monthlyLabel->setStyleSheet("font-size: 14px; color: #555;");

    m_checkinBtn = new QPushButton("等待连接...", this);
    m_checkinBtn->setMinimumHeight(40);
    m_checkinBtn->setEnabled(false); // 初始禁用，刷新后再启用
    m_checkinBtn->setStyleSheet(
        "QPushButton {"
        "   background-color: #3498db;"
        "   color: white;"
        "   border-radius: 4px;"
        "   font-size: 16px;"
        "}"
        "QPushButton:disabled {"
        "   background-color: #bdc3c7;"
        "   color: #ecf0f1;"
        "}"
    );

    // 布局管理
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->addSpacing(50);
    mainLayout->addWidget(m_statusLabel, 0, Qt::AlignCenter);
    mainLayout->addSpacing(20);
    mainLayout->addWidget(m_monthlyLabel, 0, Qt::AlignCenter);
    mainLayout->addSpacing(40);
    mainLayout->addWidget(m_checkinBtn, 0, Qt::AlignCenter);
    mainLayout->addSpacing(50);
    setLayout(mainLayout);

    // 连接信号槽
    connect(m_checkinBtn, &QPushButton::clicked, this, &DailyCheckIn::onCheckInClicked);

    // 新增：设置日期检查定时器（每小时检查一次）
    m_dateCheckTimer = new QTimer(this);
    connect(m_dateCheckTimer, &QTimer::timeout, this, &DailyCheckIn::checkDateChanged);
    m_dateCheckTimer->start(60 * 60 * 1000); // 每小时触发一次

    // 初始刷新
    refreshTable();
}

DailyCheckIn::~DailyCheckIn()
{
    // 释放UI组件
    delete m_statusLabel;
    delete m_monthlyLabel;
    delete m_checkinBtn;
}

// 确保数据库连接有效
bool DailyCheckIn::ensureDatabaseConnected()
{
    if (database::instance().isOpen()) {
        return true; // 已连接
    }

    // 尝试重新打开数据库
    qDebug() << "[数据库连接] 连接断开，尝试重连...";
    if (database::instance().openDB("smart_upc.db")) {
        qDebug() << "[数据库连接] 重连成功";
        return true;
    } else {
        qDebug() << "[数据库连接] 重连失败：" << database::instance().lastError();
        return false;
    }
}

// 获取上次每日重置日期（与管理员界面保持一致）
QDate DailyCheckIn::getLastDailyResetDate()
{
    if (!ensureDatabaseConnected()) {
        return QDate();
    }

    QSqlQuery query(database::instance().getDatabase());
    if (query.exec("SELECT value FROM config WHERE key = 'last_daily_reset'")) {
        if (query.next()) {
            return QDate::fromString(query.value(0).toString(), Qt::ISODate);
        }
    }

    // 如果数据库中没有记录，使用QSettings
    QSettings settings;
    return settings.value("last_daily_reset", QDate::currentDate().addDays(-1)).toDate();
}

// 检查是否需要重置
bool DailyCheckIn::needsReset()
{
    QDate currentDate = QDate::currentDate();
    QDate lastResetDate = getLastDailyResetDate();

    return lastResetDate < currentDate;
}

// 检查日期变化
void DailyCheckIn::checkDateChanged()
{
    QDate currentDate = QDate::currentDate();

    if (m_lastCheckedDate != currentDate || needsReset()) {
        qDebug() << "[日期变化] 检测到日期变更，刷新打卡状态";
        m_lastCheckedDate = currentDate;
        refreshTable();
    }
}

// 刷新表格（增加日期检查）
void DailyCheckIn::refreshTable()
{
    // 1. 动态检查数据库连接
    if (!ensureDatabaseConnected()) {
        m_statusLabel->setText("数据库连接失败");
        m_statusLabel->setStyleSheet("font-size: 18px; font-weight: bold; color: #e74c3c;");
        m_monthlyLabel->setText("请稍后重试或切换界面");
        m_checkinBtn->setEnabled(false);
        m_checkinBtn->setText("连接失败");
        return;
    }

    // 2. 检查日期变化
    checkDateChanged();

    // 3. 检查打卡状态
    bool checkedIn = hasCheckedInToday();

    // 4. 更新状态显示
    if (checkedIn) {
        m_statusLabel->setText("今日状态：已打卡");
        m_statusLabel->setStyleSheet("font-size: 18px; font-weight: bold; color: #2ecc71;");
        m_checkinBtn->setEnabled(false);
        m_checkinBtn->setText("今日已打卡");
    } else {
        m_statusLabel->setText("今日状态：未打卡");
        m_statusLabel->setStyleSheet("font-size: 18px; font-weight: bold; color: #e74c3c;");
        m_checkinBtn->setEnabled(true);
        m_checkinBtn->setText("立即打卡");
    }

    // 5. 更新月度计数
    int monthlyCount = getMonthlyCheckInCount();
    m_monthlyLabel->setText(QString("本月出勤次数：%1").arg(monthlyCount));
}

// 检查今日是否已打卡
bool DailyCheckIn::hasCheckedInToday()
{
    m_errorMsg.clear();
    if (!ensureDatabaseConnected()) {
        m_errorMsg = "数据库连接失败";
        qDebug() << "[打卡检查] 错误：" << m_errorMsg;
        return false;
    }

    QSqlQuery query(database::instance().getDatabase());
    query.prepare("SELECT today FROM attendance WHERE name = :staff_name");
    query.bindValue(":staff_name", m_staffName);

    if (!query.exec()) {
        m_errorMsg = QString("查询执行失败: %1").arg(query.lastError().text());
        qDebug() << "[打卡检查] 错误：" << m_errorMsg;
        return false;
    }

    if (!query.next()) {
        m_errorMsg = QString("员工'%1'不存在，请联系管理员").arg(m_staffName);
        qDebug() << "[打卡检查] 错误：" << m_errorMsg;
        return false;
    }

    return query.value("today").toInt() == 0;
}

// 获取月度打卡次数
int DailyCheckIn::getMonthlyCheckInCount()
{
    m_errorMsg.clear();
    if (!ensureDatabaseConnected()) {
        m_errorMsg = "数据库连接失败";
        qDebug() << "[月度计数] 错误：" << m_errorMsg;
        return 0;
    }

    QSqlQuery query(database::instance().getDatabase());
    query.prepare("SELECT monthly FROM attendance WHERE name = :staff_name");
    query.bindValue(":staff_name", m_staffName);

    if (!query.exec()) {
        m_errorMsg = QString("查询月度次数失败: %1").arg(query.lastError().text());
        qDebug() << "[月度计数] 错误：" << m_errorMsg;
        return 0;
    }

    if (query.next()) {
        return query.value("monthly").toInt();
    } else {
        m_errorMsg = QString("员工'%1'月度记录不存在").arg(m_staffName);
        qDebug() << "[月度计数] 错误：" << m_errorMsg;
        return 0;
    }
}

// 执行打卡操作
bool DailyCheckIn::updateCheckInStatus()
{
    m_errorMsg.clear();
    if (!ensureDatabaseConnected()) {
        m_errorMsg = "数据库连接失败";
        qDebug() << "[打卡更新] 错误：" << m_errorMsg;
        return false;
    }

    QSqlDatabase db = database::instance().getDatabase();
    db.transaction();

    // 1. 检查员工是否存在
    QSqlQuery existsQuery(db);
    existsQuery.prepare("SELECT 1 FROM attendance WHERE name = :staff_name");
    existsQuery.bindValue(":staff_name", m_staffName);

    if (!existsQuery.exec() || !existsQuery.next()) {
        db.rollback();
        m_errorMsg = QString("员工'%1'不存在，请联系管理员").arg(m_staffName);
        qDebug() << "[打卡更新] 错误：" << m_errorMsg;
        return false;
    }

    // 2. 检查是否未打卡
    QSqlQuery checkQuery(db);
    checkQuery.prepare("SELECT today FROM attendance WHERE name = :staff_name");
    checkQuery.bindValue(":staff_name", m_staffName);

    if (!checkQuery.exec() || !checkQuery.next()) {
        db.rollback();
        m_errorMsg = QString("查询员工'%1'状态失败").arg(m_staffName);
        qDebug() << "[打卡更新] 错误：" << m_errorMsg;
        return false;
    }

    if (checkQuery.value("today").toInt() == 0) {
        db.rollback();
        m_errorMsg = "今日已打卡，请勿重复操作";
        return false;
    }

    // 3. 更新打卡状态
    QSqlQuery updateQuery(db);
    updateQuery.prepare(
        "UPDATE attendance SET today = 0, monthly = monthly + 1 "
        "WHERE name = :staff_name AND today = 1"
    );
    updateQuery.bindValue(":staff_name", m_staffName);

    if (!updateQuery.exec() || updateQuery.numRowsAffected() == 0) {
        db.rollback();
        m_errorMsg = QString("更新失败: %1").arg(updateQuery.lastError().text());
        return false;
    }

    db.commit();
    return true;
}

// 打卡按钮点击事件
void DailyCheckIn::onCheckInClicked()
{
    m_errorMsg.clear();

    if (updateCheckInStatus()) {
        QMessageBox::information(this, "成功", "打卡成功！");
        refreshTable();
        emit checkInCompleted();
    } else {
        QString errorMessage = m_errorMsg.isEmpty() ? "未知错误，请联系管理员" : m_errorMsg;
        QMessageBox::critical(this, "失败", errorMessage);
    }
}

// 强制刷新界面
void DailyCheckIn::forceRefresh()
{
    m_lastCheckedDate = QDate(); // 重置日期检查，强制刷新
    refreshTable();
}
