#include "databasehelper.h"

DatabaseHelper::DatabaseHelper() {
    // 初始化数据库驱动（SQLite）
    db = QSqlDatabase::addDatabase("QSQLITE");
}

DatabaseHelper& DatabaseHelper::instance() {
    static DatabaseHelper instance;
    return instance;
}

bool DatabaseHelper::openDatabase(const QString& dbName) {
    if (db.isOpen()) {
        if (db.databaseName() == dbName) {
            qInfo() << "数据库已连接：" << dbName;
            return true;
        }
        db.close();
    }

    db.setDatabaseName(dbName);
    if (!db.open()) {
        qCritical() << "数据库打开失败：" << db.lastError().text();
        return false;
    }

    qInfo() << "数据库已连接：" << dbName;
    return true;
}

bool DatabaseHelper::isDatabaseOpen() const {
    return db.isOpen();
}

bool DatabaseHelper::ensureDatabaseOpen() {
    if (!isDatabaseOpen()) {
        return openDatabase();
    }
    return true;
}

QSqlQuery DatabaseHelper::executeQuery(const QString& sql) {
    if (!ensureDatabaseOpen()) {
        qCritical() << "数据库未打开，无法执行查询：" << sql;
        return QSqlQuery();
    }

    QSqlQuery query(db);
    if (!query.exec(sql)) {
        qCritical() << "SQL执行失败：" << sql << "\n错误：" << query.lastError().text();
    }
    return query;
}

bool DatabaseHelper::executeUpdate(const QString& sql) {
    if (!ensureDatabaseOpen()) {
        qCritical() << "数据库未打开，无法执行更新：" << sql;
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(sql)) {
        qCritical() << "SQL更新失败：" << sql << "\n错误：" << query.lastError().text();
        return false;
    }
    return true;
}

QSqlQuery DatabaseHelper::executePreparedQuery(const QString& sql, const QVariantMap& bindValues) {
    if (!ensureDatabaseOpen()) {
        qCritical() << "数据库未打开，无法执行预准备查询：" << sql;
        return QSqlQuery();
    }

    QSqlQuery query(db);
    query.prepare(sql);

    // 绑定参数
    for (auto it = bindValues.begin(); it != bindValues.end(); ++it) {
        query.bindValue(it.key(), it.value());
    }

    if (!query.exec()) {
        qCritical() << "预准备SQL执行失败：" << sql << "\n错误：" << query.lastError().text();
    }
    return query;
}
