#ifndef REPAIRREQUESTWIDGET_H
#define REPAIRREQUESTWIDGET_H

#include <QWidget>
#include <QTextEdit>
#include <QLineEdit>
#include <QPushButton>
#include "database.h"
class OwnerInfoWidget; // 前向声明

class RepairRequestWidget : public QWidget
{
    Q_OBJECT

public:
    RepairRequestWidget(int userId, database& db, OwnerInfoWidget* ownerInfoWidget, QWidget *parent = nullptr);
    ~RepairRequestWidget();
    void refreshTable();
private slots:
    void onSubmit();
    void dropAddressUniqueConstraint();
private:
    QTextEdit *descEdit;
    QPushButton *submitBtn;
    int m_userId;
    database& db;
    OwnerInfoWidget* m_ownerInfoWidget;
};

#endif // REPAIRREQUESTWIDGET_H
