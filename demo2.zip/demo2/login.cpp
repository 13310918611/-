#include "login.h"
#include "ui_login.h"
#include <QMessageBox>
#include <QSqlQuery>
#include <QDebug>
#include <QSqlError>
#include "adminwindow.h"
#include "staffwindow.h"
#include "ownerwindow.h"

Login::Login(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Login),
    m_currentRole(-1),
    m_currentId(-1)
{
    ui->setupUi(this);

    // 初始化角色选择框
    ui->comboBox_role->addItems({"管理员", "工作人员", "业主"});
    ui->comboBox_role->setItemData(0, 0);
    ui->comboBox_role->setItemData(1, 1);
    ui->comboBox_role->setItemData(2, 2);

    // 数据库错误处理
    if (!db.openDB("smart_upc.db")) {
        QMessageBox::critical(this, "错误",
            QString("数据库打开失败: %1").arg(db.lastError()));
        qApp->exit(EXIT_FAILURE);  // 严重错误直接退出
    }

    // 连接信号槽
    connect(ui->pushButton, &QPushButton::clicked, this, &Login::onLoginClicked);
    connect(ui->pushButton_2, &QPushButton::clicked, this, &Login::onRegisterClicked);
    connect(ui->pushButton_3, &QPushButton::clicked, this, &Login::onExitClicked);
}

Login::~Login()
{
    delete ui;
}

int Login::getUserRole() const
{
    return m_currentRole;
}

int Login::getUserId() const
{
    return m_currentId;
}

bool Login::validateUser(const QString& username, const QString& password, int& outUserId, int& outRole) {
    QSqlQuery query;
    if (!db.getUserByUsername(username, query)) {
        return false;
    }

    if (query.isValid()) {  // 检查当前记录是否有效
        if (query.value("password").toString() == password) {
            outUserId = query.value("id").toInt();
            outRole = query.value("role").toInt();
            return true;
        }
    }
    return false;
}

QString Login::getUsername() const
{
    return m_currentUsername;
}

void Login::onLoginClicked()
{
    QString username = ui->lineEdit->text().trimmed();
    QString password = ui->lineEdit_2->text();

    if (username.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "提示", "请输入用户名和密码!");
        return;
    }

    int userId = -1;
    int role = -1;

    if (validateUser(username, password, userId, role)) {
        m_currentId = userId;
        m_currentRole = role;
        m_currentUsername = username; // 登录成功时保存用户名
        accept();
    } else {
        QMessageBox::warning(this, "登录失败", "用户名或密码错误，或用户不存在!");
    }
}

void Login::onRegisterClicked()
{
    QString username = ui->lineEdit->text().trimmed();
    QString password = ui->lineEdit_2->text();
    int role = ui->comboBox_role->currentData().toInt();

    if (username.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "提示", "请输入用户名和密码!");
        return;
    }

    // 数据库接口
    QSqlQuery query;
    if (db.getUserByUsername(username, query)) {
        QMessageBox::warning(this, "注册失败", "用户名已存在!");
        return;
    }

    if (db.addUser(username, password, role)) {
        QMessageBox::information(this, "注册成功",
            "用户注册成功，请使用新账号登录!");
        ui->lineEdit->clear();
        ui->lineEdit_2->clear();
    } else {
        QMessageBox::critical(this, "注册失败",
            QString("数据库错误: %1").arg(db.lastError()));
    }
}

int Login::getSelectedRole() const {
    return ui->comboBox_role->currentData().toInt();
}

void Login::onExitClicked()
{
    close();
}
