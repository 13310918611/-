#ifndef PARKINGINFOWIDGET_H
#define PARKINGINFOWIDGET_H

#include <QWidget>
#include <QTableWidget>
#include <QLineEdit>
#include <QComboBox>
#include <QPushButton>

class ParkingInfoWidget : public QWidget
{
    Q_OBJECT

public:
    explicit ParkingInfoWidget(int userId, QWidget *parent = nullptr);
    ~ParkingInfoWidget() override;

    void refreshTable();

private slots:
    void onSearch();
    void onModeChanged(int index);
    void onApplyParking(const QString &parklotId);
    void showEmptyTableMessage(int mode);
    void onCancelLease(const QString &parklotId);
private:
    void setupUI();
    void checkApplicationStatusChanges();
    QString getOwnerLicensePlate();
    QTableWidget *parkingTable;
    QPushButton *refreshBtn;
    QLineEdit *searchEdit;
    QComboBox *modeCombo;
    int m_userId;
    QSet<int> m_shownApplicationIds;
    bool isNotificationViewed(int appId, int actionType);
    void recordNotificationViewed(int appId, int actionType);
};

#endif // PARKINGINFOWIDGET_H
