#ifndef PARKLOTMANAGE_H
#define PARKLOTMANAGE_H

#include <QWidget>
#include <QTableWidget>
#include <QLineEdit>
#include <QComboBox>
#include <QPushButton>

class ParkLotManage : public QWidget
{
    Q_OBJECT

public:
    explicit ParkLotManage(QWidget *parent = nullptr);
    ~ParkLotManage() override;
    void refreshTable();
private slots:
    void onSearch();
    void onReset();
    void onAddParkLot();
    void onManageUnpublished();
    void onSetPublic();
    void onCancelPublic();
    void onManagePublicize();

private:
    void setupUI();

    QTableWidget *table;
    QLineEdit *searchEdit;
    QComboBox *statusCombo;
    QPushButton *btnSearch;
    QPushButton *btnReset;

    void checkCancelLeaseNotifications(); // 检查取消承租通知
    bool isStaffNotified(int logId); // 检查工作人员是否已查看
    void markStaffNotified(int logId); // 标记为已查看
    void onTabChanged(int index);
};

#endif // PARKLOTMANAGE_H
