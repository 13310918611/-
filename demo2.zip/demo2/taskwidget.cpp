#include "taskwidget.h"
#include "database.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QMessageBox>
#include <QHeaderView>
#include <QSqlQuery>
#include <QSqlError>
#include <QLabel>
#include <QDebug>

// 初始化静态成员
TaskWidget* TaskWidget::instance = nullptr;

TaskWidget* TaskWidget::getInstance(QWidget* parent) {
    if (instance == nullptr) {
        instance = new TaskWidget(parent);
    }
    return instance;
}

TaskWidget::TaskWidget(QWidget* parent) : QWidget(parent)
{
    table = new QTableWidget(this);
    table->setColumnCount(6);
    table->setHorizontalHeaderLabels({"业主地址", "情况概述", "报修时间", "处理状态", "处理员工", "报修单号"});
    table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    table->setSelectionBehavior(QAbstractItemView::SelectRows);
    table->setEditTriggers(QAbstractItemView::NoEditTriggers);

    searchEdit = new QLineEdit(this);
    searchEdit->setPlaceholderText("输入处理员工、业主地址或报修单号查询");

    statusCombo = new QComboBox(this);
    statusCombo->addItem("全部状态", -1);
    statusCombo->addItem("已处理", 0);
    statusCombo->addItem("处理中", 1);
    statusCombo->addItem("待处理", 2);

    btnSearch = new QPushButton("查询", this);
    btnReset = new QPushButton("重置", this);

    QHBoxLayout* searchLayout = new QHBoxLayout;
    searchLayout->addWidget(searchEdit);
    searchLayout->addWidget(statusCombo);
    searchLayout->addWidget(btnSearch);
    searchLayout->addWidget(btnReset);

    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    mainLayout->addLayout(searchLayout);
    mainLayout->addWidget(table);

    connect(btnSearch, &QPushButton::clicked, this, &TaskWidget::onSearch);
    connect(btnReset, &QPushButton::clicked, this, &TaskWidget::refreshTable);
    connect(searchEdit, &QLineEdit::returnPressed, this, &TaskWidget::onSearch);

    if (!database::instance().isOpen()) {
        QMessageBox::critical(this, "数据库错误", "无法连接到数据库: " + database::instance().lastError());
        return;
    }

    // 尝试清理可能存在的address唯一约束
    QSqlQuery query(database::instance().getDatabase());

    // 检查是否存在address唯一约束
    bool hasAddressConstraint = false;
    if (query.exec("PRAGMA index_list(task)")) {
        while (query.next()) {
            QString indexName = query.value("name").toString();
            if (indexName.contains("address") && indexName.contains("unique")) {
                hasAddressConstraint = true;
                // 尝试删除唯一约束
                if (query.exec(QString("DROP INDEX %1").arg(indexName))) {
                    qDebug() << "成功删除address唯一约束:" << indexName;
                } else {
                    qDebug() << "删除address唯一约束失败:" << query.lastError().text();
                }
                break;
            }
        }
    }

    if (!hasAddressConstraint) {
        qDebug() << "未发现address唯一约束";
    }

    refreshTable();
}

TaskWidget::~TaskWidget() = default;

void TaskWidget::refreshTable() {
    QSqlQuery cleanupQuery(database::instance().getDatabase());
    if (!cleanupQuery.exec("DELETE FROM task WHERE finishedOrNot NOT IN (0, 1,2)")) {
        qDebug() << "自动清理错误记录失败:" << cleanupQuery.lastError().text();
    }

    QSqlQuery query(database::instance().getDatabase());
    query.prepare("SELECT id, address, situation, reportTime, finishedOrNot, staffFix "
                 "FROM task WHERE finishedOrNot IN (0, 1,2) "
                 "ORDER BY finishedOrNot, reportTime DESC");

    if (!query.exec()) {
        QMessageBox::critical(this, "错误", "加载任务失败: " + query.lastError().text());
        return;
    }

    QList<QString> newTaskIds;

    while (query.next()) {
        QString taskId = query.value("id").toString();
        newTaskIds.append(taskId);

        int existingRow = -1;
        for (int i = 0; i < table->rowCount(); ++i) {
            if (table->item(i, 5)->text() == taskId) {
                existingRow = i;
                break;
            }
        }

        if (existingRow == -1) {
            int row = table->rowCount();
            table->insertRow(row);

            QString address = query.value("address").toString();
            QString situation = query.value("situation").toString();
            QString reportTime = query.value("reportTime").toString();
            int status = query.value("finishedOrNot").toInt();
            QString staff = query.value("staffFix").toString();

            table->setItem(row, 0, new QTableWidgetItem(address));
            table->setItem(row, 1, new QTableWidgetItem(situation));
            table->setItem(row, 2, new QTableWidgetItem(reportTime));

            QString statusText;
            switch (status) {
                case 0: statusText = "已处理"; break;
                case 1: statusText = "处理中"; break;
                case 2: statusText = "待处理"; break;
                default: statusText = "未知";
            }
            table->setItem(row, 3, new QTableWidgetItem(statusText));

            QWidget *cellWidget = new QWidget();
            QHBoxLayout *layout = new QHBoxLayout(cellWidget);
            layout->setContentsMargins(2, 2, 2, 2);
            layout->setSpacing(2);

            if (status == 2) {
                QComboBox *staffCombo = new QComboBox(cellWidget);
                staffCombo->setProperty("taskId", taskId);
                staffCombo->setMaximumWidth(120);
                staffCombo->setStyleSheet("text-overflow: ellipsis; white-space: nowrap;");

                QSqlQuery staffQuery(database::instance().getDatabase());
                staffQuery.prepare(
                    "SELECT s.id, s.name FROM staff s "
                    "JOIN attendance a ON s.id = a.id "
                    "WHERE s.status = 1 AND a.today = 0 AND s.role = 1 "
                    "ORDER BY s.name"
                );

                if (staffQuery.exec()) {
                    staffCombo->addItem("-- 请选择委派员工 --", "");
                    staffCombo->setItemData(0, Qt::ItemIsEnabled, Qt::UserRole - 1);

                    while (staffQuery.next()) {
                        QString name = staffQuery.value("name").toString();
                        if (name.length() > 6) {
                            name = name.left(6) + "...";
                        }
                        staffCombo->addItem(name, staffQuery.value("id").toString());
                    }

                    if (staffCombo->count() > 1) {
                        staffCombo->setCurrentIndex(0);
                        connect(staffCombo, QOverload<int>::of(&QComboBox::currentIndexChanged),
                                this, &TaskWidget::onStaffSelected);
                    } else {
                        staffCombo->clear();
                        staffCombo->addItem("无可用员工");
                        staffCombo->setEnabled(false);
                    }
                } else {
                    staffCombo->addItem("加载失败");
                    staffCombo->setEnabled(false);
                    qDebug() << "员工查询失败:" << staffQuery.lastError().text();
                }

                layout->addWidget(staffCombo);
            } else {
                QLabel *label = new QLabel(staff.isEmpty() ? "未分配" : staff, cellWidget);
                label->setStyleSheet("color: #000;");
                layout->addWidget(label);
            }

            table->setItem(row, 5, new QTableWidgetItem(taskId));
            table->setCellWidget(row, 4, cellWidget);
        } else {
            QString address = query.value("address").toString();
            QString situation = query.value("situation").toString();
            QString reportTime = query.value("reportTime").toString();
            int status = query.value("finishedOrNot").toInt();
            QString staff = query.value("staffFix").toString();

            table->item(existingRow, 0)->setText(address);
            table->item(existingRow, 1)->setText(situation);
            table->item(existingRow, 2)->setText(reportTime);

            QString statusText;
            switch (status) {
                case 0: statusText = "已处理"; break;
                case 1: statusText = "处理中"; break;
                case 2: statusText = "待处理"; break;
                default: statusText = "未知";
            }
            table->item(existingRow, 3)->setText(statusText);

            QWidget *cellWidget = table->cellWidget(existingRow, 4);
            if (cellWidget) {
                QLayout *layout = cellWidget->layout();
                if (layout) {
                    QLayoutItem *item = layout->itemAt(0);
                    if (item) {
                        QWidget *widget = item->widget();
                        if (widget) {
                            if (status == 2) {
                                QComboBox *staffCombo = qobject_cast<QComboBox*>(widget);
                                if (staffCombo) {
                                    // 保留现有员工选择
                                }
                            } else {
                                QLabel *label = qobject_cast<QLabel*>(widget);
                                if (label) {
                                    label->setText(staff.isEmpty() ? "未分配" : staff);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    for (int i = table->rowCount() - 1; i >= 0; --i) {
        QString taskId = table->item(i, 5)->text();
        if (!newTaskIds.contains(taskId)) {
            table->removeRow(i);
        }
    }

    currentTaskIds = newTaskIds;
    table->resizeRowsToContents();
}

void TaskWidget::onStaffSelected(int index) {
    QComboBox* combo = qobject_cast<QComboBox*>(sender());
    if (!combo || index < 0) return;

    QString taskId = combo->property("taskId").toString();
    QString staffId = combo->itemData(index).toString();
    QString staffName = combo->itemText(index);

    if (taskId.isEmpty()) {
        QMessageBox::warning(this, "警告", "无效的任务ID");
        return;
    }

    QMessageBox::StandardButton reply = QMessageBox::question(this, "确认委派",
                                  QString("确定将任务委派给 %1 吗?").arg(staffName),
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        QSqlDatabase db = database::instance().getDatabase();
        db.transaction();

        QSqlQuery taskQuery(db);
        taskQuery.prepare("UPDATE task SET staffFix = ?, finishedOrNot = 1 WHERE id = ?");
        taskQuery.addBindValue(staffName);
        taskQuery.addBindValue(taskId);

        QSqlQuery attendanceQuery(db);
        attendanceQuery.prepare("UPDATE attendance SET today = 0 WHERE id = :staffId");
        attendanceQuery.bindValue(":staffId", staffId);

        bool taskSuccess = taskQuery.exec();
        bool attendanceSuccess = attendanceQuery.exec();

        if (taskSuccess && attendanceSuccess) {
            db.commit();

            // 立即更新表格显示
            for (int i = 0; i < table->rowCount(); ++i) {
                if (table->item(i, 5)->text() == taskId) {
                    QWidget *cellWidget = new QWidget();
                    QHBoxLayout *layout = new QHBoxLayout(cellWidget);
                    layout->setContentsMargins(2, 2, 2, 2);
                    QLabel *label = new QLabel(staffName, cellWidget);
                    label->setStyleSheet("color: #000;");
                    layout->addWidget(label);
                    table->setCellWidget(i, 4, cellWidget);
                    break;
                }
            }

            refreshTable();
            QMessageBox::information(this, "成功", QString("已委派给: %1").arg(staffName));
        } else {
            db.rollback();
            QString errorMsg;
            if (!taskSuccess) {
                errorMsg = "任务更新失败: " + taskQuery.lastError().text();
            }
            if (!attendanceSuccess) {
                errorMsg += "\n员工状态更新失败: " + attendanceQuery.lastError().text();
            }
            QMessageBox::critical(this, "错误", errorMsg);
        }
    }

    combo->setCurrentIndex(-1);
}

void TaskWidget::onSearch()
{
    QString keyword = searchEdit->text().trimmed();
    int status = statusCombo->currentData().toInt();

    QSqlQuery query(database::instance().getDatabase());
    query.prepare("SELECT * FROM task WHERE "
                  "(:keyword IS NULL OR "
                  " (address LIKE :keyword OR "
                  "  staffFix LIKE :keyword OR "
                  "  id = :exactId)) AND "
                  "(:status = -1 OR finishedOrNot = :status) "
                  "ORDER BY finishedOrNot, reportTime DESC");

    if (keyword.isEmpty()) {
        query.bindValue(":keyword", QVariant(QVariant::String));
        query.bindValue(":exactId", QVariant(QVariant::String));
    } else {
        bool isNumeric;
        int possibleId = keyword.toInt(&isNumeric);

        if (isNumeric) {
            query.bindValue(":keyword", "%" + keyword + "%");
            query.bindValue(":exactId", possibleId);
        } else {
            query.bindValue(":keyword", "%" + keyword + "%");
            query.bindValue(":exactId", QVariant(QVariant::String));
        }
    }

    query.bindValue(":status", status);

    if (!query.exec()) {
        QMessageBox::critical(this, "错误", "查询失败: " + query.lastError().text());
        return;
    }

    QList<QString> newTaskIds;

    while (query.next()) {
        QString taskId = query.value("id").toString();
        newTaskIds.append(taskId);

        int existingRow = -1;
        for (int i = 0; i < table->rowCount(); ++i) {
            if (table->item(i, 5)->text() == taskId) {
                existingRow = i;
                break;
            }
        }

        if (existingRow == -1) {
            int row = table->rowCount();
            table->insertRow(row);

            QString address = query.value("address").toString();
            QString situation = query.value("situation").toString();
            QString reportTime = query.value("reportTime").toString();
            int status = query.value("finishedOrNot").toInt();
            QString staff = query.value("staffFix").toString();

            table->setItem(row, 0, new QTableWidgetItem(address));
            table->setItem(row, 1, new QTableWidgetItem(situation));
            table->setItem(row, 2, new QTableWidgetItem(reportTime));

            QString statusText;
            switch (status) {
                case 0: statusText = "已处理"; break;
                case 1: statusText = "处理中"; break;
                case 2: statusText = "待处理"; break;
                default: statusText = "未知";
            }
            table->setItem(row, 3, new QTableWidgetItem(statusText));

            QWidget *cellWidget = new QWidget();
            QHBoxLayout *layout = new QHBoxLayout(cellWidget);
            layout->setContentsMargins(2, 2, 2, 2);
            layout->setSpacing(2);

            if (status == 2) {
                QComboBox *staffCombo = new QComboBox(cellWidget);
                staffCombo->setProperty("taskId", taskId);
                staffCombo->setMaximumWidth(120);
                staffCombo->setStyleSheet("text-overflow: ellipsis; white-space: nowrap;");

                QSqlQuery staffQuery(database::instance().getDatabase());
                staffQuery.prepare(
                    "SELECT s.id, s.name FROM staff s "
                    "JOIN attendance a ON s.id = a.id "
                    "WHERE s.status = 1 AND a.today = 0 AND s.role = 1 "
                    "ORDER BY s.name"
                );

                if (staffQuery.exec()) {
                    staffCombo->addItem("-- 请选择委派员工 --", "");
                    staffCombo->setItemData(0, Qt::ItemIsEnabled, Qt::UserRole - 1);

                    while (staffQuery.next()) {
                        QString name = staffQuery.value("name").toString();
                        if (name.length() > 6) {
                            name = name.left(6) + "...";
                        }
                        staffCombo->addItem(name, staffQuery.value("id").toString());
                    }

                    if (staffCombo->count() > 1) {
                        staffCombo->setCurrentIndex(0);
                        connect(staffCombo, QOverload<int>::of(&QComboBox::currentIndexChanged),
                                this, &TaskWidget::onStaffSelected);
                    } else {
                        staffCombo->clear();
                        staffCombo->addItem("无可用员工");
                        staffCombo->setEnabled(false);
                    }
                } else {
                    staffCombo->addItem("加载失败");
                    staffCombo->setEnabled(false);
                    qDebug() << "员工查询失败:" << staffQuery.lastError().text();
                }

                layout->addWidget(staffCombo);
            } else {
                QLabel *label = new QLabel(staff.isEmpty() ? "未分配" : staff, cellWidget);
                label->setStyleSheet("color: #000;");
                layout->addWidget(label);
            }

            table->setItem(row, 5, new QTableWidgetItem(taskId));
            table->setCellWidget(row, 4, cellWidget);
        } else {
            QString address = query.value("address").toString();
            QString situation = query.value("situation").toString();
            QString reportTime = query.value("reportTime").toString();
            int status = query.value("finishedOrNot").toInt();
            QString staff = query.value("staffFix").toString();

            table->item(existingRow, 0)->setText(address);
            table->item(existingRow, 1)->setText(situation);
            table->item(existingRow, 2)->setText(reportTime);

            QString statusText;
            switch (status) {
                case 0: statusText = "已处理"; break;
                case 1: statusText = "处理中"; break;
                case 2: statusText = "待处理"; break;
                default: statusText = "未知";
            }
            table->item(existingRow, 3)->setText(statusText);

            QWidget *cellWidget = table->cellWidget(existingRow, 4);
            if (cellWidget) {
                QLayout *layout = cellWidget->layout();
                if (layout) {
                    QLayoutItem *item = layout->itemAt(0);
                    if (item) {
                        QWidget *widget = item->widget();
                        if (widget) {
                            if (status == 2) {
                                QComboBox *staffCombo = qobject_cast<QComboBox*>(widget);
                                if (staffCombo) {
                                    // 保留现有员工选择
                                }
                            } else {
                                QLabel *label = qobject_cast<QLabel*>(widget);
                                if (label) {
                                    label->setText(staff.isEmpty() ? "未分配" : staff);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    for (int i = table->rowCount() - 1; i >= 0; --i) {
        QString taskId = table->item(i, 5)->text();
        if (!newTaskIds.contains(taskId)) {
            table->removeRow(i);
        }
    }

    currentTaskIds = newTaskIds;
    table->resizeRowsToContents();
}

void TaskWidget::onReset()
{
    searchEdit->clear();
    statusCombo->setCurrentIndex(0);
    refreshTable();
}
