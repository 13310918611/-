
#ifndef DATABASEACCESS_H
#define DATABASEACCESS_H

#include <QObject>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QTimer>
#include <QMap>
#include <QVariant>
#include <QFile>
#include <QDir>
#include <QStandardPaths>
#include <QMessageBox>
#include <QDebug>

class DatabaseAccess : public QObject
{
    Q_OBJECT
private:
    explicit DatabaseAccess(QObject *parent = nullptr);
    ~DatabaseAccess() override;

    // 禁止拷贝和赋值
    DatabaseAccess(const DatabaseAccess&) = delete;
    DatabaseAccess& operator=(const DatabaseAccess&) = delete;

    QString m_dbPath;
    bool m_isConnected;
    int m_connectionAttempts;
    QTimer *m_connectionTimer;

    static DatabaseAccess *m_instance;

public:
    QSqlDatabase m_db;
    enum class ConnectionStatus {
        Connected,
        Disconnected,
        Error,
        FileNotFound,
        FileNotWritable,
        DriverNotFound
    };
    bool testConnection();
    static DatabaseAccess *instance();

    // 初始化数据库
    ConnectionStatus initialize(const QString &dbName = "smart_upc.db",
                               const QString &preferredPath = "");

    // 检查连接状态
    bool isConnected() const;
    ConnectionStatus connectionStatus() const;
    QString lastError() const;
    QString currentDbPath() const;

    // 执行SQL查询
    bool executeQuery(const QString &queryStr, QSqlQuery &result, QString &errorMsg);
    bool executePreparedQuery(const QString &queryStr,
                             const QMap<QString, QVariant> &bindValues,
                             QSqlQuery &result, QString &errorMsg);

    // 检查表是否存在
    bool tableExists(const QString &tableName, QString &errorMsg);

    // 创建必要的表结构
    bool createTables(QString &errorMsg);
    bool openDatabase(const QString &dbPath);
    void closeDatabase();

signals:
    void connectionStatusChanged(ConnectionStatus status);

private slots:
    void checkConnection();
    bool attemptReconnect();

private:
    QString findSuitablePath(const QString &dbName, const QString &preferredPath);
    bool validateDatabaseStructure(QString &errorMsg);
};

#endif // DATABASEACCESS_H
