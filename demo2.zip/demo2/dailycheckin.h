#ifndef DAILYCHECKIN_H
#define DAILYCHECKIN_H

#include <QWidget>
#include <QLabel>
#include <QPushButton>
#include <QTimer>
#include <QDate>
#include "database.h"

class DailyCheckIn : public QWidget {
    Q_OBJECT

public:
    explicit DailyCheckIn(const QString& staffName, QWidget *parent = nullptr);
    ~DailyCheckIn();

    // 强制刷新界面
    void forceRefresh();
    void refreshTable();
signals:
    void checkInCompleted();

private slots:
    void onCheckInClicked();
    void checkDateChanged();


private:
    QString m_staffName;
    QLabel *m_statusLabel;
    QLabel *m_monthlyLabel;
    QPushButton *m_checkinBtn;
    QString m_errorMsg;
    QDate m_lastCheckedDate;
    QTimer *m_dateCheckTimer;

    bool ensureDatabaseConnected();
    bool hasCheckedInToday();
    int getMonthlyCheckInCount();
    bool updateCheckInStatus();
    QDate getLastDailyResetDate();
    bool needsReset();
};

#endif // DAILYCHECKIN_H
