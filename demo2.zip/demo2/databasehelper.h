#ifndef DATABASEHELPER_H
#define DATABASEHELPER_H

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QVariantMap>

class DatabaseHelper {
public:
    // 单例模式：全局唯一实例
    static DatabaseHelper& instance();

    // 打开数据库连接
    bool openDatabase(const QString& dbName = "smart_upc.db");

    // 检查数据库是否已打开
    bool isDatabaseOpen() const;

    // 在执行查询前确保数据库已打开
    bool ensureDatabaseOpen();

    // 执行查询SQL，返回结果集
    QSqlQuery executeQuery(const QString& sql);

    // 执行更新SQL（插入/更新/删除）
    bool executeUpdate(const QString& sql);

    // 执行预准备查询（带参数绑定）
    QSqlQuery executePreparedQuery(const QString& sql, const QVariantMap& bindValues);

private:
    // 私有构造函数，禁止外部实例化
    DatabaseHelper();
    ~DatabaseHelper() = default;

    // 禁止拷贝
    DatabaseHelper(const DatabaseHelper&) = delete;
    DatabaseHelper& operator=(const DatabaseHelper&) = delete;

    QSqlDatabase db;
};

#endif // DATABASEHELPER_H
