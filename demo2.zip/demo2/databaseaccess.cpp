
#include "databaseaccess.h"
#include <QCoreApplication>

DatabaseAccess *DatabaseAccess::m_instance = nullptr;

DatabaseAccess::DatabaseAccess(QObject *parent) : QObject(parent),
    m_isConnected(false),
    m_connectionAttempts(0),
    m_connectionTimer(nullptr)
{
    // 创建连接检查定时器
    m_connectionTimer = new QTimer(this);
    connect(m_connectionTimer, &QTimer::timeout, this, &DatabaseAccess::checkConnection);
    m_connectionTimer->start(5000); // 每5秒检查一次连接
}

DatabaseAccess::~DatabaseAccess()
{
    if (m_db.isOpen()) {
        m_db.close();
    }
}

DatabaseAccess *DatabaseAccess::instance()
{
    if (!m_instance) {
        m_instance = new DatabaseAccess();
    }
    return m_instance;
}

QString DatabaseAccess::findSuitablePath(const QString &dbName, const QString &preferredPath)
{
    QStringList potentialPaths;

    // 1. 优先使用指定路径
    if (!preferredPath.isEmpty()) {
        potentialPaths.append(QDir(preferredPath).filePath(dbName));
    }

    // 2. 应用程序目录
    potentialPaths.append(QDir(QCoreApplication::applicationDirPath()).filePath(dbName));

    // 3. 用户文档目录
    potentialPaths.append(QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation)
                         + "/" + dbName);

    // 4. 临时目录
    potentialPaths.append(QDir(QDir::tempPath()).filePath(dbName));

    // 检查每个路径的可写性
    for (const QString &path : potentialPaths) {
        QFile file(path);
        QDir dir = QFileInfo(path).absoluteDir();

        // 检查目录是否存在且可写
        if (!dir.exists()) {
            if (dir.mkpath(dir.absolutePath())) {
                qDebug() << "Created directory:" << dir.absolutePath();
            } else {
                qDebug() << "Cannot create directory:" << dir.absolutePath();
                continue;
            }
        }

        // 检查是否可以创建文件
        if (file.open(QIODevice::WriteOnly | QIODevice::Append)) {
            file.close();
            qDebug() << "Suitable path found:" << path;
            return path;
        }
    }

    // 如果都失败，返回最后一个路径
    return potentialPaths.last();
}

DatabaseAccess::ConnectionStatus DatabaseAccess::initialize(const QString &dbName, const QString &preferredPath)
{
    // 关闭现有连接
    if (m_db.isOpen()) {
        m_db.close();
    }

    // 重置状态
    m_isConnected = false;
    m_connectionAttempts = 0;

    // 查找合适的数据库路径
    m_dbPath = findSuitablePath(dbName, preferredPath);
    qDebug() << "Initializing database at path:" << m_dbPath;

    // 检查SQLite驱动是否可用
    if (!QSqlDatabase::isDriverAvailable("QSQLITE")) {
        qCritical() << "SQLite driver not available";
        emit connectionStatusChanged(ConnectionStatus::DriverNotFound);
        return ConnectionStatus::DriverNotFound;
    }

    // 检查文件是否存在
    QFile dbFile(m_dbPath);
    bool fileExists = dbFile.exists();

    // 尝试打开数据库
    if (!openDatabase(m_dbPath)) {
        ConnectionStatus status = fileExists ? ConnectionStatus::Error : ConnectionStatus::FileNotFound;
        emit connectionStatusChanged(status);
        return status;
    }

    // 验证数据库结构
    QString errorMsg;
    if (!validateDatabaseStructure(errorMsg)) {
        qCritical() << "Database structure validation failed:" << errorMsg;

        // 尝试创建表结构
        if (!createTables(errorMsg)) {
            qCritical() << "Failed to create database tables:" << errorMsg;
            emit connectionStatusChanged(ConnectionStatus::Error);
            return ConnectionStatus::Error;
        }

        qDebug() << "Database tables created successfully";
    }

    m_isConnected = true;
    emit connectionStatusChanged(ConnectionStatus::Connected);
    return ConnectionStatus::Connected;
}

bool DatabaseAccess::openDatabase(const QString &dbPath)
{
    // 移除现有连接（如果存在）
    if (QSqlDatabase::contains("SmartUPCConnection")) {
        QSqlDatabase::removeDatabase("SmartUPCConnection");
    }

    // 创建新连接
    m_db = QSqlDatabase::addDatabase("QSQLITE", "SmartUPCConnection");
    m_db.setDatabaseName(dbPath);

    // 尝试打开
    if (!m_db.open()) {
        qCritical() << "Failed to open database:" << m_db.lastError().text();
        return false;
    }

    qDebug() << "Database opened successfully:" << dbPath;
    return true;
}

bool DatabaseAccess::isConnected() const
{
    return m_isConnected && m_db.isOpen();
}

DatabaseAccess::ConnectionStatus DatabaseAccess::connectionStatus() const
{
    if (!m_isConnected) {
        return ConnectionStatus::Disconnected;
    }

    if (!m_db.isOpen()) {
        return ConnectionStatus::Disconnected;
    }

    // 执行简单查询测试连接
    QSqlQuery query(m_db);
    if (!query.exec("SELECT 1")) {
        return ConnectionStatus::Error;
    }

    return ConnectionStatus::Connected;
}

QString DatabaseAccess::lastError() const
{
    return m_db.lastError().text();
}

QString DatabaseAccess::currentDbPath() const
{
    return m_dbPath;
}

bool DatabaseAccess::executeQuery(const QString &queryStr, QSqlQuery &result, QString &errorMsg)
{
    if (!isConnected()) {
        // 尝试重连
        if (!attemptReconnect()) {
            errorMsg = "Database connection lost and reconnection failed";
            qCritical() << errorMsg;
            return false;
        }
    }

    result = QSqlQuery(m_db);

    // 执行查询
    if (!result.exec(queryStr)) {
        errorMsg = "Query execution failed: " + result.lastError().text();
        qCritical() << errorMsg << "Query:" << queryStr;

        // 标记连接可能已断开
        if (result.lastError().type() == QSqlError::ConnectionError) {
            m_isConnected = false;
            emit connectionStatusChanged(ConnectionStatus::Disconnected);
        }

        return false;
    }

    return true;
}

bool DatabaseAccess::executePreparedQuery(const QString &queryStr,
                                         const QMap<QString, QVariant> &bindValues,
                                         QSqlQuery &result, QString &errorMsg)
{
    if (!isConnected()) {
        // 尝试重连
        if (!attemptReconnect()) {
            errorMsg = "Database connection lost and reconnection failed";
            qCritical() << errorMsg;
            return false;
        }
    }

    result = QSqlQuery(m_db);

    // 准备查询
    if (!result.prepare(queryStr)) {
        errorMsg = "Query preparation failed: " + result.lastError().text();
        qCritical() << errorMsg << "Query:" << queryStr;
        return false;
    }

    // 绑定参数
    QMapIterator<QString, QVariant> it(bindValues);
    while (it.hasNext()) {
        it.next();
        result.bindValue(it.key(), it.value());
    }

    // 执行查询
    if (!result.exec()) {
        errorMsg = "Prepared query execution failed: " + result.lastError().text();
        qCritical() << errorMsg << "Query:" << queryStr;

        // 构建参数列表用于调试
        QString bindParams;
        it.toFront();
        while (it.hasNext()) {
            it.next();
            bindParams += QString("%1=%2 ").arg(it.key()).arg(it.value().toString());
        }
        qDebug() << "Bind parameters:" << bindParams;

        // 标记连接可能已断开
        if (result.lastError().type() == QSqlError::ConnectionError) {
            m_isConnected = false;
            emit connectionStatusChanged(ConnectionStatus::Disconnected);
        }

        return false;
    }

    return true;
}

bool DatabaseAccess::tableExists(const QString &tableName, QString &errorMsg)
{
    QSqlQuery query(m_db);
    if (!query.exec("SELECT name FROM sqlite_master WHERE type='table' AND name='" + tableName + "'")) {
        errorMsg = "Failed to check table existence: " + query.lastError().text();
        qCritical() << errorMsg;
        return false;
    }

    return query.next();
}

bool DatabaseAccess::validateDatabaseStructure(QString &errorMsg)
{
    // 检查表是否存在
    QStringList requiredTables = {
        "users", "parklot", "parking_application"
    };

    for (const QString &table : requiredTables) {
        if (!tableExists(table, errorMsg)) {
            return false;
        }
    }

    return true;
}

bool DatabaseAccess::createTables(QString &errorMsg)
{
    QSqlQuery query(m_db);
    QSqlDatabase::database("SmartUPCConnection").transaction();

    // 创建车位表
    if (!query.exec(
        "CREATE TABLE IF NOT EXISTS parklot ("
        "parklot_id TEXT PRIMARY KEY,"
        "status INTEGER NOT NULL DEFAULT 0,"
        "owner_id INTEGER,"
        "license_number TEXT,"
        "lease_start DATE,"
        "lease_end DATE,"
        "create_time DATETIME DEFAULT CURRENT_TIMESTAMP,"
        "FOREIGN KEY (owner_id) REFERENCES users(user_id)"
        ")"
    )) {
        errorMsg = "Failed to create parklot table: " + query.lastError().text();
        qCritical() << errorMsg;
        QSqlDatabase::database("SmartUPCConnection").rollback();
        return false;
    }

    // 创建申请记录表
    if (!query.exec(
        "CREATE TABLE IF NOT EXISTS parking_application ("
        "application_id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "parklot_id TEXT NOT NULL,"
        "owner_id INTEGER NOT NULL,"
        "license_plate TEXT NOT NULL,"
        "apply_time DATETIME NOT NULL,"
        "status INTEGER NOT NULL DEFAULT 0,"
        "handler_id INTEGER,"
        "handle_time DATETIME,"
        "handle_comment TEXT,"
        "FOREIGN KEY (parklot_id) REFERENCES parklot(parklot_id),"
        "FOREIGN KEY (owner_id) REFERENCES users(user_id),"
        "FOREIGN KEY (handler_id) REFERENCES users(user_id)"
        ")"
    )) {
        errorMsg = "Failed to create parking_application table: " + query.lastError().text();
        qCritical() << errorMsg;
        QSqlDatabase::database("SmartUPCConnection").rollback();
        return false;
    }

    // 创建数据库初始化标记表（空表）
    if (!tableExists("__database_initialized", errorMsg)) {
        if (!query.exec("CREATE TABLE __database_initialized (dummy INTEGER)")) {
            errorMsg = "Failed to create initialization marker: " + query.lastError().text();
            qCritical() << errorMsg;
            QSqlDatabase::database("SmartUPCConnection").rollback();
            return false;
        }

        qDebug() << "Database initialized without sample data";
    }

    QSqlDatabase::database("SmartUPCConnection").commit();
    return true;
}

void DatabaseAccess::checkConnection()
{
    if (!isConnected()) {
        qWarning() << "Database connection check failed, attempting to reconnect...";
        attemptReconnect();
    }
}

bool DatabaseAccess::attemptReconnect()
{
    if (m_connectionAttempts >= 3) {
        qCritical() << "Too many connection attempts, giving up";
        emit connectionStatusChanged(ConnectionStatus::Disconnected);
        return false;
    }

    m_connectionAttempts++;

    // 关闭现有连接
    if (m_db.isOpen()) {
        m_db.close();
    }

    // 尝试重新打开
    if (openDatabase(m_dbPath)) {
        m_isConnected = true;
        m_connectionAttempts = 0;
        emit connectionStatusChanged(ConnectionStatus::Connected);
        qDebug() << "Reconnection successful";
        return true;
    }

    qCritical() << "Reconnection failed, attempt" << m_connectionAttempts;
    emit connectionStatusChanged(ConnectionStatus::Disconnected);
    return false;
}
bool DatabaseAccess::testConnection()
{
    if (!isConnected()) {
        if (!attemptReconnect()) {
            return false;
        }
    }

    // 执行简单的SELECT 1查询测试连接
    QSqlQuery query;
    QString errorMsg;

    if (!executeQuery("SELECT 1", query, errorMsg)) {
        qCritical() << "Database connection test failed:" << errorMsg;
        return false;
    }

    return true;
}
void DatabaseAccess::closeDatabase()
{
    if (m_db.isOpen()) {
        m_db.close();
        qDebug() << "数据库连接已关闭";
    }
}
