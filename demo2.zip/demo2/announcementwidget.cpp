#include "announcementwidget.h"
#include "database.h"
#include <QMessageBox>
#include <QSqlError>
#include <QDateTime>
#include <QDebug>
#include <QVBoxLayout>

// 构造函数接收发布者姓名
AnnouncementWidget::AnnouncementWidget(const QString& publisherName, QWidget *parent)
    : QWidget(parent), m_publisherName(publisherName)
{
    // UI初始化
    m_titleEdit = new QLineEdit(this);
    m_titleEdit->setPlaceholderText("请输入公告标题");
    m_titleEdit->setMinimumHeight(30);

    m_contentEdit = new QTextEdit(this);
    m_contentEdit->setPlaceholderText("请输入公告内容");

    m_publishBtn = new QPushButton("发布公告", this);
    m_publishBtn->setMinimumHeight(35);
    m_publishBtn->setStyleSheet("background-color: #2ecc71; color: white; border-radius: 4px;");

    // 布局
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->addWidget(m_titleEdit);
    mainLayout->addWidget(m_contentEdit);
    mainLayout->addWidget(m_publishBtn);
    mainLayout->setContentsMargins(20, 20, 20, 20);
    mainLayout->setSpacing(15);
    setLayout(mainLayout);

    connect(m_publishBtn, &QPushButton::clicked, this, &AnnouncementWidget::onPublishClicked);
}

void AnnouncementWidget::onPublishClicked()
{
    QString title = m_titleEdit->text().trimmed();
    QString content = m_contentEdit->toPlainText().trimmed();

    if (title.isEmpty() || content.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "标题和内容不能为空！");
        return;
    }

    // 插入公告（存储发布者姓名）
    QSqlQuery query(database::instance().getDatabase());
    query.prepare(
        "INSERT INTO announcements (title, content, publish_time, publisher_name) "
        "VALUES (:title, :content, :time, :publisher_name)"
    );
    query.bindValue(":title", title);
    query.bindValue(":content", content);
    query.bindValue(":time", QDateTime::currentDateTime().toString(Qt::ISODate));
    query.bindValue(":publisher_name", m_publisherName);  // 绑定发布者姓名

    if (!query.exec()) {
        QMessageBox::critical(this, "发布失败", "数据库错误：" + query.lastError().text());
        qDebug() << "公告发布失败：" << query.lastError().text();
        return;
    }

    QMessageBox::information(this, "成功", "公告发布成功！");
    m_titleEdit->clear();
    m_contentEdit->clear();
}
