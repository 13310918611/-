#ifndef OWNERMANAGE_H
#define OWNERMANAGE_H

#include <QWidget>
#include <QTableWidget>
#include <QLineEdit>
#include <QPushButton>
#include "ownerinfodatabase.h"

namespace Ui {
class OwnerManage;
}

class OwnerManage : public QWidget
{
    Q_OBJECT

public:
    explicit OwnerManage(QWidget *parent = nullptr);
    ~OwnerManage();
    void refreshTable();

private slots:
    void onSearchClicked();   // 搜索按钮点击槽函数

private:
    Ui::OwnerManage *ui;
    QTableWidget *tableWidget; // 表格控件，用于展示业主信息
    QLineEdit *searchEdit;     // 搜索输入框
    QPushButton *searchBtn;    // 搜索按钮
    OwnerInfoDatabase *db;     // 数据库操作实例

    void setupUI(); // 初始化界面布局
};

#endif // OWNERMANAGE_H
