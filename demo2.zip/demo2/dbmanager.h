#ifndef DBMANAGER_H
#define DBMANAGER_H

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QString>
#include <QDebug>
#include <QMutex>

class DBManager {
public:
    static DBManager& instance();
    QSqlDatabase getDatabase();
    bool isOpen();
    QString lastError();
    bool openDB(const QString& dbName);
    QSqlDatabase getDatabase(const QString& connectionName);
    bool openDB(const QString& dbName, const QString& connectionName);

private:
    DBManager();
    ~DBManager();
    DBManager(const DBManager&) = delete;
    DBManager& operator=(const DBManager&) = delete;

    QSqlDatabase db;
    QMutex mutex; // 线程安全锁
};

#endif // DBMANAGER_H
