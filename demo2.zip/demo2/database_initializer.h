#ifndef DATABASE_INITIALIZER_H
#define DATABASE_INITIALIZER_H

#include <QString>

class DatabaseInitializer {
public:
    static bool initialize(const QString& dbPath);
};

#endif // DATABASE_INITIALIZER_H
