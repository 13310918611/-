#include "chargemanage.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlError>
#include <QSqlDriver>
#include <QSqlDatabase>
#include <QHeaderView>

ChargeManage::ChargeManage(QWidget *parent) : QWidget(parent)
{
    // 初始化数据库连接（复用业主信息数据库，确保路径正确）
    db = OwnerInfoDatabase::instance();
    if (!db->openDatabase("smart_upc.db")) { // 明确指定数据库路径（与业主查询一致）
        QMessageBox::critical(this, "错误", "数据库连接失败：" + db->lastError());
        return;
    }

    // UI组件初始化
    ownerComboBox = new QComboBox(this);
    amountEdit = new QLineEdit(this);
    amountEdit->setPlaceholderText("请输入金额（元）");
    reasonEdit = new QTextEdit(this);
    reasonEdit->setPlaceholderText("请输入缴费原因");
    reasonEdit->setMaximumHeight(80);
    sendBtn = new QPushButton("发送缴费通知", this);
    recordTable = new QTableWidget(this);
    recordTable->setColumnCount(5);
    recordTable->setHorizontalHeaderLabels({"业主姓名", "金额", "原因", "状态", "创建时间"});
    recordTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    // 布局
    QFormLayout* formLayout = new QFormLayout;
    formLayout->addRow("选择业主：", ownerComboBox);
    formLayout->addRow("缴费金额：", amountEdit);
    formLayout->addRow("缴费原因：", reasonEdit);

    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    mainLayout->addLayout(formLayout);
    mainLayout->addWidget(sendBtn);
    mainLayout->addWidget(recordTable);

    // 信号连接
    connect(sendBtn, &QPushButton::clicked, this, &ChargeManage::onSendChargeClicked);

    // 初始化数据
    loadOwners();
    refreshTable();
}

ChargeManage::~ChargeManage() = default;

// 加载业主列表到下拉框（复用业主查询的JOIN逻辑）
void ChargeManage::loadOwners()
{
    ownerComboBox->clear();
    ownerComboBox->addItem("全部业主", -1); // 全部业主选项（值为-1）

    // 查询逻辑：JOIN owner_info和account，获取有效业主（与ownermanage一致）
    QSqlQuery query(db->m_db); // 使用数据库连接
    QString sql = R"(
        SELECT a.id, a.username
        FROM owner_info o
        JOIN account a ON o.user_id = a.id
    )";

    if (!query.exec(sql)) {
        QMessageBox::critical(this, "查询失败", "业主列表获取失败：" + query.lastError().text());
        return;
    }

    while (query.next()) {
        int userId = query.value("id").toInt();
        QString username = query.value("username").toString();
        ownerComboBox->addItem(username, userId); // 下拉框显示姓名，值存user_id
    }
}

// 刷新缴费记录表格
void ChargeManage::refreshTable()
{
    recordTable->setRowCount(0);

    QSqlQuery query(db->m_db);
    QString sql = R"(
        SELECT a.username, pr.amount, pr.reason,
               CASE WHEN pr.is_paid = 1 THEN '已缴费' ELSE '未缴费' END AS status,
               pr.create_time
        FROM payment_records pr
        JOIN account a ON pr.user_id = a.id
        ORDER BY pr.create_time DESC
    )";

    if (!query.exec(sql)) {
        QMessageBox::critical(this, "查询失败", "缴费记录获取失败：" + query.lastError().text());
        return;
    }

    int row = 0;
    while (query.next()) {
        recordTable->insertRow(row);
        recordTable->setItem(row, 0, new QTableWidgetItem(query.value("username").toString()));
        recordTable->setItem(row, 1, new QTableWidgetItem(query.value("amount").toString()));
        recordTable->setItem(row, 2, new QTableWidgetItem(query.value("reason").toString()));
        recordTable->setItem(row, 3, new QTableWidgetItem(query.value("status").toString()));
        recordTable->setItem(row, 4, new QTableWidgetItem(query.value("create_time").toString()));
        recordTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
        row++;
    }
}

// 发送缴费通知
void ChargeManage::onSendChargeClicked()
{
    // 输入验证
    bool isAmountValid = false;
    double amount = amountEdit->text().toDouble(&isAmountValid);
    if (!isAmountValid || amount <= 0) {
        QMessageBox::warning(this, "输入错误", "请输入有效的金额（正数）");
        return;
    }

    QString reason = reasonEdit->toPlainText().trimmed();
    if (reason.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "请填写缴费原因");
        return;
    }

    int selectedUserId = ownerComboBox->currentData().toInt();

    // 检查SQLite驱动是否可用
    if (!QSqlDatabase::isDriverAvailable("QSQLITE")) {
        QString availableDrivers = QSqlDatabase::drivers().join(", ");
        QMessageBox::critical(this, "驱动错误",
            "SQLite驱动不可用！\n"
            "可用驱动：" + availableDrivers + "\n\n"
            "请确保：\n"
            "1. .pro文件已添加 QT += sql\n"
            "2. qsqlite.dll已复制到可执行文件目录\n"
            "3. Qt安装包含SQLite组件");
        return;
    }

    // 尝试重新初始化数据库连接
    if (!db->m_db.isOpen() || !db->m_db.isValid()) {
        qDebug() << "数据库连接已关闭或无效，尝试重新初始化...";

        // 关闭现有连接
        if (QSqlDatabase::contains("mainConnection")) {
            QSqlDatabase::removeDatabase("mainConnection");
        }

        // 创建新连接
        QSqlDatabase newDb = QSqlDatabase::addDatabase("QSQLITE", "mainConnection");
        newDb.setDatabaseName("smart_upc.db");

        if (!newDb.open()) {
            QMessageBox::critical(this, "数据库错误",
                "无法打开数据库：" + newDb.lastError().text() + "\n\n"
                "请确保：\n"
                "1. 数据库文件存在且可写\n"
                "2. 没有其他程序占用该文件\n"
                "3. 具有访问该文件的权限");
            return;
        }

        // 更新数据库连接
        db->m_db = newDb;
        qDebug() << "数据库连接已重新初始化";
    }

    QSqlDatabase dbConnection = db->m_db;

    // 检查事务支持
    if (dbConnection.driver()->hasFeature(QSqlDriver::Transactions)) {
        if (!dbConnection.transaction()) {
            dbConnection.rollback();
            if (!dbConnection.transaction()) {
                QMessageBox::critical(this, "事务错误", "无法启动数据库事务：" + dbConnection.lastError().text());
                return;
            }
            dbConnection.rollback();
        } else {
            dbConnection.rollback();
        }
    }

    QSqlQuery query(dbConnection);

    // 开启事务
    if (!dbConnection.transaction()) {
        QString errorMsg = dbConnection.lastError().text();
        QMessageBox::critical(this, "事务失败", "数据库事务开启失败: " + errorMsg);
        return;
    }

    bool success = true;
    if (selectedUserId == -1) { // 全部业主
        QSqlQuery userIdQuery(dbConnection);
        if (!userIdQuery.exec("SELECT DISTINCT user_id FROM owner_info")) {
            success = false;
            QMessageBox::critical(this, "查询失败", "业主ID获取失败：" + userIdQuery.lastError().text());
        } else {
            while (userIdQuery.next()) {
                int userId = userIdQuery.value("user_id").toInt();
                query.prepare("INSERT INTO payment_records "
                              "(user_id, amount, reason, is_paid) "
                              "VALUES (:user_id, :amount, :reason, 0)");
                query.bindValue(":user_id", userId);
                query.bindValue(":amount", amount);
                query.bindValue(":reason", reason);
                if (!query.exec()) {
                    success = false;
                    QMessageBox::critical(this, "插入失败", "向业主" + QString::number(userId) + "发送失败：" + query.lastError().text());
                    break;
                }
            }
        }
    } else { // 单个业主
        query.prepare("INSERT INTO payment_records "
                      "(user_id, amount, reason, is_paid) "
                      "VALUES (:user_id, :amount, :reason, 0)");
        query.bindValue(":user_id", selectedUserId);
        query.bindValue(":amount", amount);
        query.bindValue(":reason", reason);
        if (!query.exec()) {
            success = false;
            QMessageBox::critical(this, "插入失败", "发送失败：" + query.lastError().text());
        }
    }

    // 提交/回滚事务
    if (success) {
        if (!dbConnection.commit()) {
            QMessageBox::critical(this, "提交失败", "事务提交失败: " + dbConnection.lastError().text());
        } else {
            QMessageBox::information(this, "成功", "缴费通知已发送");
            amountEdit->clear();
            reasonEdit->clear();
            refreshTable();
        }
    } else {
        if (!dbConnection.rollback()) {
            QMessageBox::critical(this, "回滚失败", "事务回滚失败: " + dbConnection.lastError().text());
        }
    }
}
