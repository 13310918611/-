#ifndef DATABASE_H
#define DATABASE_H

#include <QObject>
#include <QSqlDatabase>
#include<QString>
#include <QSqlQuery>
#include <QSqlError>

class database
{
public:
    database();
    ~database();
    static database& instance() {
        static database instance;
        return instance;
    }
    bool openDB(const QString& dbPath);
    bool isOpen() const { return m_db.isOpen(); } //
    bool addUser(const QString& username, const QString& password, int role);
    bool getUserByUsername(const QString& username, QSqlQuery& outQuery);
    bool query(const QString& sql, QSqlQuery& outQuery);
    QString lastError() const { return m_db.lastError().text(); } //
    QSqlQuery query(const QString& sql);
    QSqlDatabase& getDatabase() { return m_db; }
    database(const database&) = delete;
    void operator=(const database&) = delete;
private:
    QSqlDatabase m_db;
    QString m_connectionName;
};

#endif // DATABASE_H
