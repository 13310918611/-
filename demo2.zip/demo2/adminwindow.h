#pragma once
#include<QStackedWidget>
#include <QMainWindow>
#include <QStatusBar>

QT_BEGIN_NAMESPACE
namespace Ui {
class AdminWindow;
}
QT_END_NAMESPACE

class StaffManageWidget;
class LeaveApproveWidget;
class AttendanceWidget;
class TaskWidget;
class AnnouncementWidget;
class AnnouncementListWidget;

class AdminWindow : public QMainWindow
{
    Q_OBJECT

public:
    AdminWindow(int userId, const QString& adminName, QWidget *parent = nullptr);
    ~AdminWindow();
    AttendanceWidget* getAttendanceWidget();
private slots:
    void showStaffManage();
    void showLeaveApprove();
    void showAttendance();
    void showTask();
    void showAnnouncementManage();
    void showAnnouncementList();

private:
    void setupMenus();
    int m_userID;
    Ui::AdminWindow* ui;
    QStackedWidget* stackedWidget;
    StaffManageWidget* staffWidget;
    LeaveApproveWidget* leaveWidget;
    AttendanceWidget* attendanceWidget;
    TaskWidget* taskWidget;
    AnnouncementWidget *announcementWidget;
    AnnouncementListWidget* announcementListWidget;
    QString m_adminName;
};


