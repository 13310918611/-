#include "ownermanage.h"
#include "ui_ownermanage.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QMessageBox>
#include <QSqlQuery>

OwnerManage::OwnerManage(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::OwnerManage)
{
    ui->setupUi(this);
    db = OwnerInfoDatabase::instance(); // 获取数据库单例

    if (!db->openDatabase("smart_upc.db")) {
        QMessageBox::critical(this, "错误", "数据库打开失败：" + db->lastError());
        return;
    }

    // 初始化界面
    setupUI();

    // 首次加载数据
    refreshTable();
}

OwnerManage::~OwnerManage()
{
    delete ui;
}

void OwnerManage::setupUI()
{
    // 初始化表格控件
    tableWidget = new QTableWidget(this);
    tableWidget->setColumnCount(6); // 业主姓名、联系电话、车牌号、所在幢号、房间号、家庭成员
    tableWidget->setHorizontalHeaderLabels({
        tr("业主姓名"),
        tr("联系电话"),
        tr("车牌号"),
        tr("所在幢号"),
        tr("房间号"),
        tr("家庭成员")
    });
    tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers); // 只读模式

    // 初始化搜索控件
    searchEdit = new QLineEdit(this);
    searchEdit->setPlaceholderText(tr("输入业主姓名查询"));
    searchBtn = new QPushButton(tr("查询"), this);
    connect(searchBtn, &QPushButton::clicked, this, &OwnerManage::onSearchClicked);

    // 布局管理
    QHBoxLayout *searchLayout = new QHBoxLayout;
    searchLayout->addWidget(searchEdit);
    searchLayout->addWidget(searchBtn);

    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->addLayout(searchLayout);
    mainLayout->addWidget(tableWidget);

    setLayout(mainLayout);
}

void OwnerManage::onSearchClicked()
{

    refreshTable();
}

void OwnerManage::refreshTable()
{
    tableWidget->setRowCount(0); // 清空原有数据

    QString searchKeyword = searchEdit->text().trimmed();
    QSqlQuery query(db->m_db); // 使用数据库连接执行查询

    // 构造查询语句，通过 JOIN 关联 account 表获取业主姓名
    QString sql = R"(
        SELECT a.username, o.phone, o.license_plate, o.building, o.room, o.family_members
        FROM owner_info o
        JOIN account a ON o.user_id = a.id
    )";

    // 如果有搜索关键词，添加 WHERE 条件
    if (!searchKeyword.isEmpty()) {
        sql += QString(" WHERE a.username LIKE '%%1%'").arg(searchKeyword);
    }

    // 执行查询
    if (!query.exec(sql)) {
        QMessageBox::critical(this, tr("查询失败"),
                              tr("SQL执行错误：%1").arg(query.lastError().text()));
        return;
    }

    // 填充表格数据
    int row = 0;
    while (query.next()) {
        tableWidget->insertRow(row);

        // 逐个字段读取并填充到表格
        tableWidget->setItem(row, 0, new QTableWidgetItem(query.value("username").toString()));
        tableWidget->setItem(row, 1, new QTableWidgetItem(query.value("phone").toString()));
        tableWidget->setItem(row, 2, new QTableWidgetItem(query.value("license_plate").toString()));
        tableWidget->setItem(row, 3, new QTableWidgetItem(query.value("building").toString()));
        tableWidget->setItem(row, 4, new QTableWidgetItem(query.value("room").toString()));
        tableWidget->setItem(row, 5, new QTableWidgetItem(query.value("family_members").toString()));

        row++;
    }

    // 如果无数据，提示用户
    if (row == 0) {
        QMessageBox::information(this, tr("提示"),
                                 tr("未找到匹配的业主信息"));
    }
}
