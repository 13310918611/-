
#ifndef PARKDATABASEHELPER_H
#define PARKDATABASEHELPER_H

#include <QObject>
#include <QSqlDatabase>
#include <QSqlQuery>

class ParkDatabaseHelper : public QObject
{
    Q_OBJECT
private:
    explicit ParkDatabaseHelper(QObject *parent = nullptr);
    static ParkDatabaseHelper* m_instance;
    QSqlDatabase m_db;
    QString m_dbName;
public:
    bool executePreparedQuery(const QString &sql,
                             const QMap<QString, QVariant> &bindValues,
                             QSqlQuery &query,
                             QString &errorMsg);
    static ParkDatabaseHelper* instance();
    bool openDB(const QString &dbName = "smart_upc.db");
    bool isConnected() const;
    QString lastError() const;
    QSqlDatabase getDatabase();
    bool executeQuery(const QString &sql, QSqlQuery &query, QString &errorMsg);
};

#endif // PARKDATABASEHELPER_H
