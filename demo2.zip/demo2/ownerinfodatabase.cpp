#include "ownerinfodatabase.h"

OwnerInfoDatabase* OwnerInfoDatabase::instance()
{
    static OwnerInfoDatabase instance;
    return &instance;
}

OwnerInfoDatabase::OwnerInfoDatabase(QObject *parent) : QObject(parent)
{
    m_db = QSqlDatabase::addDatabase("QSQLITE");
}

OwnerInfoDatabase::~OwnerInfoDatabase()
{
    if (m_db.isOpen())
        m_db.close();
}

bool OwnerInfoDatabase::openDatabase(const QString &dbPath)
{
    if (m_db.isOpen())
        return true;

    m_db.setDatabaseName(dbPath);
    if (!m_db.open()) {
        m_lastError = m_db.lastError().text();
        qCritical() << "数据库连接失败:" << m_lastError;
        return false;
    }

    // 创建必要的表（如果不存在）
    QSqlQuery query(m_db);
    if (!query.exec("CREATE TABLE IF NOT EXISTS owner_info ("
                    "user_id INTEGER PRIMARY KEY, "
                    "phone TEXT NOT NULL, "
                    "license_plate TEXT NOT NULL, "
                    "building TEXT NOT NULL, "
                    "room TEXT NOT NULL, "
                    "family_members TEXT, "
                    "create_time DATETIME DEFAULT CURRENT_TIMESTAMP, "
                    "update_time DATETIME)")) {
        m_lastError = query.lastError().text();
        qCritical() << "创建表失败:" << m_lastError;
        return false;
    }

    return true;
}

bool OwnerInfoDatabase::isDatabaseOpen() const
{
    return m_db.isOpen();
}

QString OwnerInfoDatabase::lastError() const
{
    return m_lastError;
}

bool OwnerInfoDatabase::saveOwnerInfo(int userId, const QString &phone, const QString &license,
                                    const QString &building, const QString &room, const QString &family)
{
    if (!isDatabaseOpen() && !openDatabase())
        return false;

    QSqlQuery query(m_db);
    bool exists = false;

    // 检查记录是否存在
    query.prepare("SELECT COUNT(*) FROM owner_info WHERE user_id = :userId");
    query.bindValue(":userId", userId);
    if (query.exec() && query.next()) {
        exists = query.value(0).toInt() > 0;
    } else {
        m_lastError = query.lastError().text();
        qCritical() << "检查业主信息失败:" << m_lastError;
        return false;
    }

    // 插入或更新
    if (exists) {
        query.prepare("UPDATE owner_info SET phone = :phone, license_plate = :license, "
                     "building = :building, room = :room, family_members = :family, "
                     "update_time = CURRENT_TIMESTAMP WHERE user_id = :userId");
    } else {
        query.prepare("INSERT INTO owner_info (user_id, phone, license_plate, "
                     "building, room, family_members, create_time) "
                     "VALUES (:userId, :phone, :license, :building, :room, :family, CURRENT_TIMESTAMP)");
    }

    query.bindValue(":userId", userId);
    query.bindValue(":phone", phone);
    query.bindValue(":license", license);
    query.bindValue(":building", building);
    query.bindValue(":room", room);
    query.bindValue(":family", family);

    if (!query.exec()) {
        m_lastError = query.lastError().text();
        qCritical() << "保存业主信息失败:" << m_lastError;
        return false;
    }

    return true;
}

bool OwnerInfoDatabase::getOwnerInfo(int userId, QString &phone, QString &license,
                                   QString &building, QString &room, QString &family)
{
    if (!isDatabaseOpen() && !openDatabase())
        return false;

    QSqlQuery query(m_db);
    query.prepare("SELECT phone, license_plate, building, room, family_members "
                 "FROM owner_info WHERE user_id = :userId");
    query.bindValue(":userId", userId);

    if (query.exec() && query.next()) {
        phone = query.value("phone").toString();
        license = query.value("license_plate").toString();
        building = query.value("building").toString();
        room = query.value("room").toString();
        family = query.value("family_members").toString();
        return true;
    }

    m_lastError = query.lastError().text();
    qDebug() << "获取业主信息失败或记录不存在:" << m_lastError;
    return false;
}

bool OwnerInfoDatabase::isOwnerInfoComplete(int userId)
{
    QString phone, license, building, room, family;
    if (getOwnerInfo(userId, phone, license, building, room, family)) {
        return !phone.isEmpty() && !license.isEmpty() && !building.isEmpty() && !room.isEmpty();
    }
    return false;
}
