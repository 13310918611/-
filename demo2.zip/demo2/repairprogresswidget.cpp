#include "repairprogresswidget.h"
#include <QVBoxLayout>
#include <QSqlQuery>
#include <QHeaderView>
#include <QMessageBox>
#include <QPushButton>
#include <QHBoxLayout>
#include <QLabel>
#include <QDialogButtonBox>
#include "ownerinfowidget.h"

RepairProgressWidget::RepairProgressWidget(int userId, database& db, OwnerInfoWidget* ownerInfoWidget, QWidget *parent)
    : QWidget(parent), m_userId(userId), db(db), m_ownerInfoWidget(ownerInfoWidget)
{
    progressTable = new QTableWidget(this);
    progressTable->setColumnCount(5);  // 报修ID、故障描述、提交时间、当前状态、操作
    progressTable->setHorizontalHeaderLabels({"报修ID", "故障描述", "提交时间", "当前状态", "操作"});
    progressTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    progressTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    // 添加手动刷新按钮
    QPushButton* refreshBtn = new QPushButton("刷新状态", this);
    connect(refreshBtn, &QPushButton::clicked, this, &RepairProgressWidget::refreshTable);

    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->addWidget(refreshBtn);  // 手动刷新按钮
    layout->addWidget(progressTable);
    setLayout(layout);

    refreshTable();  // 初始加载
}

RepairProgressWidget::~RepairProgressWidget() = default;

void RepairProgressWidget::refreshTable()
{
    progressTable->clearContents();
    progressTable->setRowCount(0);

    // 获取业主地址
    QString address = m_ownerInfoWidget->building().trimmed() + "幢" + m_ownerInfoWidget->room().trimmed() + "号";
    qDebug() << "查询地址:" << address;

    if (address.isEmpty()) {
        QMessageBox::critical(this, "错误", "请完善业主信息（楼栋和房间号）！");
        return;
    }

    // 构造查询SQL
    QString escapedAddress = address.replace("'", "''");
    QString sql = QString("SELECT id, situation, reportTime, finishedOrNot, rating, feedback "
                         "FROM task WHERE address = '%1'").arg(escapedAddress);
    qDebug() << "执行SQL:" << sql;

    QSqlQuery query;
    if (!db.query(sql, query)) {
        QMessageBox::critical(this, "错误", "查询失败：" + query.lastError().text());
        return;
    }

    if (!query.first()) {
        //QMessageBox::information(this, "提示", "无该地址的报修记录！");
        return;
    }
    query.seek(-1);

    int row = 0;
    while (query.next()) {
        int taskId = query.value("id").toInt();

        // 通过字段名获取状态值
        int status = query.value("finishedOrNot").toInt();
        int rating = query.value("rating").toInt();

        qDebug() << "任务ID:" << taskId << "正确状态值:" << status;

        // 设置表格内容
        progressTable->insertRow(row);
        progressTable->setItem(row, 0, new QTableWidgetItem(QString::number(taskId)));
        progressTable->setItem(row, 1, new QTableWidgetItem(query.value("situation").toString()));
        progressTable->setItem(row, 2, new QTableWidgetItem(query.value("reportTime").toString()));

        // 状态文本映射
        QString statusText;
        switch (status) {
            case 0: statusText = "已完成"; break;
            case 1: statusText = "维修中"; break;
            case 2: statusText = "未维修"; break;
            default: statusText = "未知状态";
        }
        progressTable->setItem(row, 3, new QTableWidgetItem(statusText));

        // 操作列
        QWidget *operWidget = new QWidget(this);
        QHBoxLayout *operLayout = new QHBoxLayout(operWidget);
        operLayout->setContentsMargins(2, 2, 2, 2);

        if (status == 0) {
            status == 0 ? (rating == 0 ?
                [&](){
                    QPushButton *evalBtn = new QPushButton("评价", operWidget);
                    evalBtn->setProperty("taskId", taskId);
                    connect(evalBtn, &QPushButton::clicked, this, &RepairProgressWidget::onFeedbackClicked);
                    operLayout->addWidget(evalBtn);
                }() :
                [&](){
                    operLayout->addWidget(new QLabel(QString("已评价（%1星）").arg(rating), operWidget));
                }()) :
            operLayout->addWidget(new QLabel("-", operWidget));

        operWidget->setLayout(operLayout);
        progressTable->setCellWidget(row, 4, operWidget);

        row++;
        }
    }
}

void RepairProgressWidget::onFeedbackClicked()
{
    QPushButton *btn = qobject_cast<QPushButton*>(sender());
    if (!btn) return;

    int taskId = btn->property("taskId").toInt();
    showFeedbackDialog(taskId);
}

void RepairProgressWidget::showFeedbackDialog(int taskId)
{
    QDialog dialog(this);
    dialog.setWindowTitle("报修评价 - 任务ID: " + QString::number(taskId));
    dialog.setMinimumSize(400, 300);

    QVBoxLayout *layout = new QVBoxLayout(&dialog);

    // 评分选择
    QLabel *ratingLabel = new QLabel("请选择评分:", &dialog);
    QComboBox *ratingCombo = new QComboBox(&dialog);
    ratingCombo->addItems({"5星 - 非常满意", "4星 - 满意", "3星 - 一般", "2星 - 不满意", "1星 - 非常不满意"});

    // 评价内容
    QLabel *feedbackLabel = new QLabel("评价内容:", &dialog);
    QTextEdit *feedbackText = new QTextEdit(&dialog);

    QHBoxLayout *ratingLayout = new QHBoxLayout;
    ratingLayout->addWidget(ratingLabel);
    ratingLayout->addWidget(ratingCombo);

    layout->addLayout(ratingLayout);
    layout->addWidget(feedbackLabel);
    layout->addWidget(feedbackText);

    // 按钮区域
    QDialogButtonBox *buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, &dialog);
    connect(buttonBox, &QDialogButtonBox::accepted, &dialog, &QDialog::accept);
    connect(buttonBox, &QDialogButtonBox::rejected, &dialog, &QDialog::reject);

    layout->addWidget(buttonBox);

    if (dialog.exec() == QDialog::Accepted) {
        int rating = 5 - ratingCombo->currentIndex();  // 0→5星，对应1-5
        QString feedback = feedbackText->toPlainText().trimmed();

        if (feedback.isEmpty()) {
            QMessageBox::warning(this, "提示", "评价内容不能为空！");
            return;
        }

        // 使用字符串拼接替代参数化查询
        QString escapedFeedback = feedback.replace("'", "''"); // 转义单引号
        QString sql = QString("UPDATE task SET rating = %1, feedback = '%2', feedback_time = CURRENT_TIMESTAMP "
                             "WHERE id = %3")
                        .arg(rating)
                        .arg(escapedFeedback)
                        .arg(taskId);

        QSqlQuery query;
        if (db.query(sql, query)) { // 调用现有database::query方法
            QMessageBox::information(this, "成功", "评价提交成功！");
            refreshTable();  // 刷新表格
        } else {
            QMessageBox::critical(this, "失败", "评价提交失败：" + query.lastError().text());
        }
    }
}
