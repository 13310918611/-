#ifndef OWNERINFODATABASE_H
#define OWNERINFODATABASE_H

#include <QObject>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>

class OwnerInfoDatabase : public QObject
{
    Q_OBJECT
public:
    enum ErrorType {
        NoError,
        ConnectionError,
        QueryError,
        DataError
    };

    static OwnerInfoDatabase* instance();
    bool openDatabase(const QString& dbPath = "smart_upc.db");
    bool isDatabaseOpen() const;
    QString lastError() const;

    // 业主信息操作
    bool saveOwnerInfo(int userId, const QString& phone, const QString& license,
                      const QString& building, const QString& room, const QString& family);
    bool getOwnerInfo(int userId, QString& phone, QString& license,
                     QString& building, QString& room, QString& family);
    bool isOwnerInfoComplete(int userId);
    QSqlDatabase m_db;

private:
    explicit OwnerInfoDatabase(QObject *parent = nullptr);
    ~OwnerInfoDatabase();
    Q_DISABLE_COPY(OwnerInfoDatabase)

    QString m_lastError;
};

#endif // OWNERINFODATABASE_H
