#include "dbmanager.h"
#include <QSqlError>

DBManager& DBManager::instance() {
    static DBManager instance;
    return instance;
}

DBManager::DBManager() {
    // 私有构造函数
}

DBManager::~DBManager() {
    // 关闭所有数据库连接
    QStringList connections = QSqlDatabase::connectionNames();
    foreach (const QString &connection, connections) {
        QSqlDatabase::database(connection).close();
    }
}

QSqlDatabase DBManager::getDatabase() {
    return db;
}

QSqlDatabase DBManager::getDatabase(const QString& connectionName) {
    QMutexLocker locker(&mutex);
    if (QSqlDatabase::contains(connectionName)) {
        return QSqlDatabase::database(connectionName);
    }
    return QSqlDatabase(); // 返回无效数据库
}

bool DBManager::isOpen() {
    return db.isOpen();
}

QString DBManager::lastError() {
    return db.lastError().text();
}

bool DBManager::openDB(const QString& dbName) {
    QMutexLocker locker(&mutex);
    if (db.isOpen()) return true;

    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(dbName);

    if (!db.open()) {
        qDebug() << "DBManager: Failed to open database:" << db.lastError().text();
        return false;
    }

    qDebug() << "DBManager: Database opened successfully:" << dbName;
    return true;
}

bool DBManager::openDB(const QString& dbName, const QString& connectionName) {
    QMutexLocker locker(&mutex);

    // 检查连接是否已存在
    if (QSqlDatabase::contains(connectionName)) {
        QSqlDatabase existingDb = QSqlDatabase::database(connectionName);
        if (existingDb.isOpen()) {
            qDebug() << "DBManager: Reusing existing connection:" << connectionName;
            return true;
        }
        // 关闭已存在但未打开的连接
        existingDb.close();
    }

    // 创建新连接
    QSqlDatabase newDb = QSqlDatabase::addDatabase("QSQLITE", connectionName);
    newDb.setDatabaseName(dbName);

    if (!newDb.open()) {
        qDebug() << "DBManager: Failed to open database with connection:" << connectionName
                 << "Error:" << newDb.lastError().text();
        return false;
    }

    qDebug() << "DBManager: Database opened successfully with connection:" << connectionName;
    return true;
}
