#include "adminwindow.h"
#include "ui_adminwindow.h"
#include "staffmanagewidget.h"
#include "leaveapprovewidget.h"
#include "attendancewidget.h"
#include "taskwidget.h"
#include "announcementwidget.h"
#include "announcementlistwidget.h"
#include <QMainWindow>
#include <QMenuBar>
#include <QMenu>
#include <QAction>
#include <QStackedWidget>
#include <QStatusBar>

AdminWindow::AdminWindow(int userId, const QString& adminName, QWidget *parent) :
    QMainWindow(parent), m_userID(userId), m_adminName(adminName),
    ui(new Ui::AdminWindow)
{
    ui->setupUi(this);
    stackedWidget = new QStackedWidget(this);
    staffWidget = new StaffManageWidget(m_adminName, this);
    leaveWidget = new LeaveApproveWidget(m_adminName, this);
    attendanceWidget = new AttendanceWidget(this);
    taskWidget = new TaskWidget(this);
    announcementWidget = new AnnouncementWidget(m_adminName, this);
    announcementListWidget = new AnnouncementListWidget(this);

    stackedWidget->addWidget(staffWidget);
    stackedWidget->addWidget(leaveWidget);
    stackedWidget->addWidget(attendanceWidget);
    stackedWidget->addWidget(taskWidget);
    stackedWidget->addWidget(announcementWidget);
    stackedWidget->addWidget(announcementListWidget);

    // 设置标题 + 欢迎信息
    setWindowTitle(QString("管理员系统 - 欢迎你：%1").arg(m_adminName));

    ui->centralwidget->deleteLater();
    setCentralWidget(stackedWidget);
    setupMenus();
    stackedWidget->setCurrentWidget(staffWidget);
}

AdminWindow::~AdminWindow()
{
    delete ui;
}
void AdminWindow::setupMenus(){
    QMenuBar*menuBar=ui->menubar;
    menuBar->clear();
    QMenu* StaffManage=menuBar->addMenu("物业人员管理");
    QMenu* Leave=menuBar->addMenu("请销假审批");
    QMenu* Attendance=menuBar->addMenu("出勤记录管理");
    QMenu* Task=menuBar->addMenu("报修委派");
    QMenu* Announcement = menuBar->addMenu("公告管理");
    QAction *staffAction = StaffManage->addAction("物业人员管理");
    QAction *leaveAction = Leave->addAction("请销假审批");
    QAction *attendAction = Attendance->addAction("出勤记录管理");
    QAction *taskAction = Task->addAction("报修委派");
    QAction *announceAction = Announcement->addAction("发布公告");
    QAction *announceListAction = Announcement->addAction("查看公告列表");
    connect(staffAction, &QAction::triggered, this, &AdminWindow::showStaffManage);
    connect(leaveAction, &QAction::triggered, this, &AdminWindow::showLeaveApprove);
    connect(attendAction, &QAction::triggered, this, &AdminWindow::showAttendance);
    connect(taskAction, &QAction::triggered, this, &AdminWindow::showTask);
    connect(announceAction, &QAction::triggered, this, &AdminWindow::showAnnouncementManage);
    connect(announceListAction, &QAction::triggered, this, &AdminWindow::showAnnouncementList);
}

void AdminWindow::showStaffManage() {
    stackedWidget->setCurrentWidget(staffWidget);
    staffWidget->refreshTable(); //此处报错则在对应的.h头文件中，在public中声明void refreshTable();
}
void AdminWindow::showLeaveApprove() {
    stackedWidget->setCurrentWidget(leaveWidget);
    leaveWidget->refreshTable();
}
void AdminWindow::showAttendance() {
    stackedWidget->setCurrentWidget(attendanceWidget);
    attendanceWidget->refreshTable();
}
void AdminWindow::showTask() {
    stackedWidget->setCurrentWidget(taskWidget);
    taskWidget->refreshTable();
}
void AdminWindow::showAnnouncementManage()
{
    stackedWidget->setCurrentWidget(announcementWidget);
}

void AdminWindow::showAnnouncementList()
{
    stackedWidget->setCurrentWidget(announcementListWidget);
    announcementListWidget->refreshAnnouncements();
}

AttendanceWidget* AdminWindow::getAttendanceWidget()
{
    return attendanceWidget;
}
