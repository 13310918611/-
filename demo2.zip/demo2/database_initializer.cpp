#include "database_initializer.h"
#include "databaseaccess.h"
#include "ownerinfodatabase.h"
#include "database.h"
#include <QSqlQuery>
#include <QDebug>

bool DatabaseInitializer::initialize(const QString& dbPath) {
    bool success = true;

    // 调用 DatabaseAccess 的初始化函数
    DatabaseAccess *dbAccess = DatabaseAccess::instance();
    DatabaseAccess::ConnectionStatus status = dbAccess->initialize();
    if (status != DatabaseAccess::ConnectionStatus::Connected) {
        qDebug() << "DatabaseAccess initialization failed:" << static_cast<int>(status);
        success = false;
    }

    // 调用 OwnerInfoDatabase 的初始化函数
    OwnerInfoDatabase *ownerInfoDB = OwnerInfoDatabase::instance();
    if (!ownerInfoDB->openDatabase(dbPath)) {
        qDebug() << "OwnerInfoDatabase initialization failed:" << ownerInfoDB->lastError();
        success = false;
    }

    // 调用 database 的初始化函数
    if (!database::instance().openDB(dbPath)) {
        qDebug() << "database initialization failed";
        success = false;
    }

    // 创建新表格
    QSqlDatabase db = QSqlDatabase::database();
    if (success && db.isOpen()) {
        QSqlQuery query(db);

        // 创建 announcements 表格
        if (!query.exec(
            "CREATE TABLE IF NOT EXISTS announcements ("
            "id INTEGER PRIMARY KEY,"
            "title TEXT NOT NULL,"
            "content TEXT NOT NULL,"
            "publish_time DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,"
            "publisher_name TEXT NOT NULL"
            ")"
        )) {
            qCritical() << "Failed to create announcements table:" << query.lastError().text();
            success = false;
        }

        // 创建 parking_log 表格
        if (success && !query.exec(
            "CREATE TABLE IF NOT EXISTS parking_log ("
            "id INTEGER PRIMARY KEY,"
            "parklot_id INTEGER NOT NULL,"
            "action_type INTEGER NOT NULL,"
            "action_time DATETIME DEFAULT CURRENT_TIMESTAMP,"
            "is_notified INTEGER DEFAULT 0"
            ")"
        )) {
            qCritical() << "Failed to create parking_log table:" << query.lastError().text();
            success = false;
        }

        // 创建 payment_records 表格
        if (success && !query.exec(
            "CREATE TABLE IF NOT EXISTS payment_records ("
            "id INTEGER PRIMARY KEY,"
            "user_id INTEGER NOT NULL,"
            "amount DECIMAL(10, 2) NOT NULL,"
            "reason TEXT NOT NULL,"
            "is_paid BOOLEAN DEFAULT 0,"
            "payment_date DATETIME,"
            "create_time DATETIME DEFAULT CURRENT_TIMESTAMP"
            ")"
        )) {
            qCritical() << "Failed to create payment_records table:" << query.lastError().text();
            success = false;
        }

        // 创建 task 表格
        if (success && !query.exec(
            "CREATE TABLE IF NOT EXISTS task ("
            "id INTEGER PRIMARY KEY,"
            "address TEXT,"
            "situation TEXT,"
            "finishedOrNot INTEGER,"
            "staffFix TEXT,"
            "rating INTEGER,"
            "feedback TEXT,"
            "feedback_time DATETIME"
            ")"
        )) {
            qCritical() << "Failed to create task table:" << query.lastError().text();
            success = false;
        }
    }

    return success;
}
