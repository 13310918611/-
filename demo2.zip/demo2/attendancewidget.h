#ifndef ATTENDANCEWIDGET_H
#define ATTENDANCEWIDGET_H

#include <QWidget>
#include <QTableWidget>
#include <QPushButton>
#include <QLineEdit>
#include <QComboBox>
#include <QDate>
#include <QTimer>
#include <QSqlQuery>
#include "database.h"

namespace Ui {
class AttendanceWidget;
}

class AttendanceWidget : public QWidget
{
    Q_OBJECT

public:
    explicit AttendanceWidget(QWidget *parent = nullptr);
    ~AttendanceWidget();
    void refreshTable();
    void forceRefresh();
    void refreshTableWithDate(const QDate& date);

private slots:
    void onSearch();
    void onReset();
    void setupDailyResetTimer();
    void checkAndResetAttendance();
    void ensureConfigTableExists();

private:
    void populateTable(QSqlQuery& query);
    void setupUI();
    void setupConnections();
    bool executeQuery(const QString& sql, QSqlQuery& query);
    bool executePreparedQuery(const QString& sql, const QMap<QString, QVariant>& bindValues, QSqlQuery& query);
    bool performDailyReset();
    bool performMonthlyReset();
    Ui::AttendanceWidget *ui;
    QTableWidget* table;
    QLineEdit* searchEdit;
    QComboBox* statusCombo;
    QPushButton* btnSearch;
    QPushButton* btnReset;
    database db;
    QDate getLastDailyResetDate();
    void setLastDailyResetDate(const QDate& date);
    QDate getLastMonthlyResetDate();
    void setLastMonthlyResetDate(const QDate& date);
};

#endif // ATTENDANCEWIDGET_H
