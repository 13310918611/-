#include "ownerwindow.h"
#include "ui_ownerwindow.h"
#include "parkinginfowidget.h"
#include "ownerinfowidget.h"
#include "repairprogresswidget.h"
#include "repairrequestwidget.h"
#include "paymentwidget.h"
#include <QMainWindow>
#include <QMenuBar>
#include <QMenu>
#include <QAction>
#include <QStackedWidget>
#include <QStatusBar>
#include <QMessageBox>
#include "databaseaccess.h"

OwnerWindow::OwnerWindow(int userId, const QString& ownerName, QWidget *parent) :
    QMainWindow(parent), m_userID(userId), m_ownerName(ownerName),
    ui(new Ui::OwnerWindow)
{
    paymentWidget = new PaymentWidget(m_userID, this); // 传入业主ID
    ui->setupUi(this);
    setWindowTitle("业主中心");
    resize(800, 600);

    // 使用单例数据库连接
    DatabaseAccess *dbAccess = DatabaseAccess::instance();
    if (!dbAccess->isConnected()) {
        DatabaseAccess::ConnectionStatus status = dbAccess->initialize();
        if (status != DatabaseAccess::ConnectionStatus::Connected) {
            QMessageBox::critical(this, "数据库错误", "无法连接到数据库，请检查数据库文件和权限。");
            return;
        }
    }

    // 初始化栈式窗口和子界面
    stackedWidget = new QStackedWidget(this);
    ownerInfoWidget = new OwnerInfoWidget(m_userID, m_ownerName, this);
    repairProgressWidget = new RepairProgressWidget(m_userID, db, ownerInfoWidget, this);
    parkingInfoWidget = new ParkingInfoWidget(m_userID, this);
    repairRequestWidget = new RepairRequestWidget(m_userID, db, ownerInfoWidget, this);
    paymentWidget = new PaymentWidget(m_userID, this);
    announcementWidget = new AnnouncementListWidget(this);

    // 将子界面添加到栈式窗口
    stackedWidget->addWidget(ownerInfoWidget);
    stackedWidget->addWidget(repairProgressWidget);
    stackedWidget->addWidget(parkingInfoWidget);
    stackedWidget->addWidget(repairRequestWidget);
    stackedWidget->addWidget(paymentWidget);
    stackedWidget->addWidget(announcementWidget);

    setWindowTitle(QString("业主中心 - 欢迎你：%1").arg(m_ownerName));

    // 设置中心部件
    ui->centralwidget->deleteLater();  // 删除默认centralWidget
    setCentralWidget(stackedWidget);

    // 初始化菜单
    setupMenus();

    // 连接信号槽
    connect(ownerInfoWidget, &OwnerInfoWidget::infoUpdated, this, &OwnerWindow::onInfoUpdated);

    // 检查是否需要强制填写信息
     if (!checkInfoCompletion()) {
        stackedWidget->setCurrentWidget(ownerInfoWidget);
        statusBar()->showMessage("请先完善个人信息", 5000);
    } else {
        // 默认显示个人信息界面
        stackedWidget->setCurrentWidget(ownerInfoWidget);
    }
}

OwnerWindow::~OwnerWindow()
{
    delete ui;
}

void OwnerWindow::setupMenus()
{
    QMenuBar* menuBar = ui->menubar;
    menuBar->clear();  // 清空默认菜单

    // 添加各功能菜单
    QMenu* infoMenu = menuBar->addMenu("个人信息");
    QMenu* parkingMenu = menuBar->addMenu("停车信息");
    QMenu* repairMenu = menuBar->addMenu("报修服务");
    QMenu* paymentMenu = menuBar->addMenu("费用缴纳");
    QMenu* announcementMenu = menuBar->addMenu("公告");

    // 添加菜单动作
    QAction* infoAction = infoMenu->addAction("查看个人信息");
    QAction* parkingAction = parkingMenu->addAction("查看/承租车位");
    QAction* repairRequestAction = repairMenu->addAction("提交报修请求");
    QAction* repairProgressAction = repairMenu->addAction("查看维修进度");
    QAction* paymentAction = paymentMenu->addAction("费用查询与缴纳");
    QAction* announcementAction = announcementMenu->addAction("查看公告");

    // 绑定动作到槽函数
    connect(infoAction, &QAction::triggered, this, &OwnerWindow::showOwnerInfo);
    connect(parkingAction, &QAction::triggered, this, &OwnerWindow::showParkingInfo);
    connect(repairRequestAction, &QAction::triggered, this, &OwnerWindow::showRepairRequest);
    connect(repairProgressAction, &QAction::triggered, this, &OwnerWindow::showRepairProgress);
    connect(paymentAction, &QAction::triggered, this, &OwnerWindow::showPayment);
    connect(announcementAction, &QAction::triggered, this, &OwnerWindow::showAnnouncements);

    menuBar->update();
    menuBar->repaint();
}

bool OwnerWindow::ensureDatabaseConnection()
{
    DatabaseAccess *dbAccess = DatabaseAccess::instance();
    if (!dbAccess->isConnected()) {
        return dbAccess->initialize() == DatabaseAccess::ConnectionStatus::Connected;
    }
    return true;
}

// 检查信息是否已完善
bool OwnerWindow::checkInfoCompletion()
{
    return ownerInfoWidget->isInfoComplete();
}

void OwnerWindow::showOwnerInfo()
{
    if (ensureDatabaseConnection()) {
        stackedWidget->setCurrentWidget(ownerInfoWidget);
    } else {
        QMessageBox::critical(this, "数据库错误", "无法连接到数据库，请检查数据库文件和权限。");
    }
}

void OwnerWindow::showRepairProgress()
{
    if (!checkInfoCompletion()) {
        QMessageBox::information(this, "请完善信息", "请先完善个人信息！");
        stackedWidget->setCurrentWidget(ownerInfoWidget);
        return;
    }

    if (ensureDatabaseConnection()) {
        stackedWidget->setCurrentWidget(repairProgressWidget);
        repairProgressWidget->refreshTable();  // 刷新维修进度数据
    } else {
        QMessageBox::critical(this, "数据库错误", "无法连接到数据库，请检查文件和权限。");
    }
}

void OwnerWindow::showParkingInfo()
{
    if (!checkInfoCompletion()) {
        QMessageBox::information(this, "请完善信息", "请先完善个人信息！");
        stackedWidget->setCurrentWidget(ownerInfoWidget);
        return;
    }

    if (ensureDatabaseConnection()) {
        stackedWidget->setCurrentWidget(parkingInfoWidget);
        parkingInfoWidget->refreshTable();
    } else {
        QMessageBox::critical(this, "数据库错误", "无法连接到数据库，请检查数据库文件和权限。");
    }
}

void OwnerWindow::showRepairRequest()
{
    if (!checkInfoCompletion()) {
        QMessageBox::information(this, "请完善信息", "请先完善个人信息！");
        stackedWidget->setCurrentWidget(ownerInfoWidget);
        return;
    }

    if (ensureDatabaseConnection()) {
        stackedWidget->setCurrentWidget(repairRequestWidget);
        repairRequestWidget->refreshTable();  // 刷新报修请求表单
    } else {
        QMessageBox::critical(this, "数据库错误", "无法连接到数据库，请检查文件和权限。");
    }
}

void OwnerWindow::showPayment()
{
    if (!checkInfoCompletion()) {
        QMessageBox::information(this, "请完善信息", "请先完善个人信息！");
        stackedWidget->setCurrentWidget(ownerInfoWidget);
        return;
    }

    if (ensureDatabaseConnection()) {
        stackedWidget->setCurrentWidget(paymentWidget);
        paymentWidget->refreshTable();  // 刷新费用数据
    } else {
        QMessageBox::critical(this, "数据库错误", "无法连接到数据库，请检查文件和权限。");
    }
}

void OwnerWindow::showAnnouncements()
{
    stackedWidget->setCurrentWidget(announcementWidget);
    announcementWidget->refreshAnnouncements(); // 刷新列表
}

void OwnerWindow::onInfoUpdated()
{
    statusBar()->showMessage("个人信息已更新", 3000);
}
