#ifndef LEAVEAPPLYWIDGET_H
#define LEAVEAPPLYWIDGET_H

#include <QWidget>
#include <QSqlDatabase>
#include <QSqlQuery>
#include "dbmanager.h"

namespace Ui {
class LeaveApplyWidget;
}

class LeaveApplyWidget : public QWidget
{
    Q_OBJECT

public:
    explicit LeaveApplyWidget(int staffId, const QString& staffName, QWidget *parent = nullptr);
    ~LeaveApplyWidget();
    void refreshTable();
private slots:
    void onSubmitApply();

private:
    DBManager& dbManager;
    Ui::LeaveApplyWidget *ui;
    void initDB();
    int m_staffId;
    QString m_staffName;
};

#endif // LEAVEAPPLYWIDGET_H
