#include "paymentwidget.h"
#include <QVBoxLayout>
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlError>
#include <QPushButton>
#include <QHeaderView>

PaymentWidget::PaymentWidget(int userId, QWidget *parent) : QWidget(parent), m_userId(userId)
{
    // 初始化数据库连接
    db = OwnerInfoDatabase::instance();
    if (!db->openDatabase("smart_upc.db")) {
        QMessageBox::critical(this, "错误", "数据库连接失败：" + db->lastError());
        return;
    }

    // UI组件初始化
    tabWidget = new QTabWidget(this);
    unpaidTable = new QTableWidget(this);
    paidTable = new QTableWidget(this);

    // 未缴费表格（含“缴费”按钮）
    unpaidTable->setColumnCount(4);
    unpaidTable->setHorizontalHeaderLabels({"金额", "原因", "创建时间", "操作"});
    unpaidTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    // 已缴费表格
    paidTable->setColumnCount(3);
    paidTable->setHorizontalHeaderLabels({"金额", "原因", "缴费时间"});
    paidTable->setEditTriggers(QAbstractItemView::NoEditTriggers);

    tabWidget->addTab(unpaidTable, "未缴费");
    tabWidget->addTab(paidTable, "已缴费");
    tabWidget->setMinimumHeight(400);

    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    mainLayout->addWidget(tabWidget);

    // 刷新数据
    refreshTable();
}

PaymentWidget::~PaymentWidget() = default;

// 刷新表格数据（仅显示当前业主的记录）
void PaymentWidget::refreshTable()
{
    // 清空表格
    unpaidTable->setRowCount(0);
    paidTable->setRowCount(0);

    // 查询未缴费记录
    QSqlQuery unpaidQuery(db->m_db);
    unpaidQuery.prepare(R"(
        SELECT id, amount, reason, create_time
        FROM payment_records
        WHERE user_id = :user_id AND is_paid = 0
        ORDER BY create_time DESC
    )");
    unpaidQuery.bindValue(":user_id", m_userId);
    if (!unpaidQuery.exec()) {
        QMessageBox::critical(this, "查询失败", "未缴费记录获取失败：" + unpaidQuery.lastError().text());
    } else {
        int row = 0;
        while (unpaidQuery.next()) {
            unpaidTable->insertRow(row);
            // 金额
            unpaidTable->setItem(row, 0, new QTableWidgetItem(unpaidQuery.value("amount").toString()));
            // 原因
            unpaidTable->setItem(row, 1, new QTableWidgetItem(unpaidQuery.value("reason").toString()));
            // 创建时间
            unpaidTable->setItem(row, 2, new QTableWidgetItem(unpaidQuery.value("create_time").toString()));
            // 缴费按钮
            QPushButton* payBtn = new QPushButton("缴费", this);
            payBtn->setProperty("recordId", unpaidQuery.value("id").toInt()); // 绑定记录ID
            connect(payBtn, &QPushButton::clicked, this, &PaymentWidget::onPayClicked);
            unpaidTable->setCellWidget(row, 3, payBtn);
            row++;
        }
    }

    // 查询已缴费记录
    QSqlQuery paidQuery(db->m_db);
    paidQuery.prepare(R"(
        SELECT amount, reason, payment_date
        FROM payment_records
        WHERE user_id = :user_id AND is_paid = 1
        ORDER BY payment_date DESC
    )");
    paidQuery.bindValue(":user_id", m_userId);
    if (!paidQuery.exec()) {
        QMessageBox::critical(this, "查询失败", "已缴费记录获取失败：" + paidQuery.lastError().text());
    } else {
        int row = 0;
        while (paidQuery.next()) {
            paidTable->insertRow(row);
            paidTable->setItem(row, 0, new QTableWidgetItem(paidQuery.value("amount").toString()));
            paidTable->setItem(row, 1, new QTableWidgetItem(paidQuery.value("reason").toString()));
            paidTable->setItem(row, 2, new QTableWidgetItem(paidQuery.value("payment_date").toString()));
            row++;
        }
    }

    // 自适应列宽
    unpaidTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    paidTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
}

// 处理缴费操作
void PaymentWidget::onPayClicked()
{
    QPushButton* btn = qobject_cast<QPushButton*>(sender());
    if (!btn) return;

    int recordId = btn->property("recordId").toInt();
    QSqlQuery query(db->m_db);

    // 更新记录为“已缴费”，并设置当前时间为缴费时间
    query.prepare(R"(
        UPDATE payment_records
        SET is_paid = 1, payment_date = CURRENT_TIMESTAMP
        WHERE id = :id AND user_id = :user_id
    )");
    query.bindValue(":id", recordId);
    query.bindValue(":user_id", m_userId);

    if (query.exec() && query.numRowsAffected() > 0) {
        QMessageBox::information(this, "成功", "缴费成功");
        refreshTable(); // 刷新表格
    } else {
        QMessageBox::critical(this, "失败", "缴费失败：" + query.lastError().text());
    }
}
