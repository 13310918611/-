#ifndef TASKWIDGET_H
#define TASKWIDGET_H

#include <QWidget>
#include <QTableWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QComboBox>
#include <QSqlDatabase>
#include <QList>

class TaskWidget : public QWidget
{
    Q_OBJECT
private:
    static TaskWidget* instance;
    ~TaskWidget();
    TaskWidget(const TaskWidget&) = delete;
    TaskWidget& operator=(const TaskWidget&) = delete;

    QTableWidget* table;
    QLineEdit* searchEdit;
    QComboBox* statusCombo;
    QPushButton* btnSearch;
    QPushButton* btnReset;

    QList<QString> currentTaskIds;

public:
    explicit TaskWidget(QWidget* parent = nullptr);
    static TaskWidget* getInstance(QWidget* parent = nullptr);
    void refreshTable();

private slots:
    void onSearch();
    void onStaffSelected(int index);
    void onReset();
};

#endif // TASKWIDGET_H
